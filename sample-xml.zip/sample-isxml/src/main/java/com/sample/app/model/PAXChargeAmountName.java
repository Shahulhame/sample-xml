
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PAX-ChargeAmount-Name.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PAX-ChargeAmount-Name">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="GrossBilled"/>
 *     &lt;enumeration value="GrossAccepted"/>
 *     &lt;enumeration value="GrossDifference"/>
 *     &lt;enumeration value="GrossCredited"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PAX-ChargeAmount-Name", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum PAXChargeAmountName {

    @XmlEnumValue("GrossBilled")
    GROSS_BILLED("GrossBilled"),
    @XmlEnumValue("GrossAccepted")
    GROSS_ACCEPTED("GrossAccepted"),
    @XmlEnumValue("GrossDifference")
    GROSS_DIFFERENCE("GrossDifference"),
    @XmlEnumValue("GrossCredited")
    GROSS_CREDITED("GrossCredited");
    private final String value;

    PAXChargeAmountName(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PAXChargeAmountName fromValue(String v) {
        for (PAXChargeAmountName c: PAXChargeAmountName.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
