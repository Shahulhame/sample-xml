
package com.sample.app.model;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;simpleContent>
 *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
 *       &lt;attribute name="Name" use="required" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}ListingAmountAfterSC-Name" />
 *     &lt;/extension>
 *   &lt;/simpleContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "value"
})
@XmlRootElement(name = "ProvisionalFormBAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class ProvisionalFormBAmount {

    @XmlValue
    protected BigDecimal value;
    @XmlAttribute(name = "Name", required = true)
    protected ListingAmountAfterSCName name;

    /**
     * Base used for numbers of type decimal(18,3)
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setValue(BigDecimal value) {
        this.value = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link ListingAmountAfterSCName }
     *     
     */
    public ListingAmountAfterSCName getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListingAmountAfterSCName }
     *     
     */
    public void setName(ListingAmountAfterSCName value) {
        this.name = value;
    }

}
