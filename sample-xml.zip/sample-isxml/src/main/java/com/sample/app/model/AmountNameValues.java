
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Amount-Name-Values.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="Amount-Name-Values">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN30Base">
 *     &lt;enumeration value="Outstanding"/>
 *     &lt;enumeration value="Deposit"/>
 *     &lt;enumeration value="Installment"/>
 *     &lt;enumeration value="Security"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "Amount-Name-Values", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum AmountNameValues {

    @XmlEnumValue("Outstanding")
    OUTSTANDING("Outstanding"),
    @XmlEnumValue("Deposit")
    DEPOSIT("Deposit"),
    @XmlEnumValue("Installment")
    INSTALLMENT("Installment"),
    @XmlEnumValue("Security")
    SECURITY("Security");
    private final String value;

    AmountNameValues(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AmountNameValues fromValue(String v) {
        for (AmountNameValues c: AmountNameValues.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
