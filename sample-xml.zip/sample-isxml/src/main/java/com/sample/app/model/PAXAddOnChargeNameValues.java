
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PAX-AddOnChargeName-Values.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PAX-AddOnChargeName-Values">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN30Base">
 *     &lt;enumeration value="ISCAllowed"/>
 *     &lt;enumeration value="OtherCommissionAllowed"/>
 *     &lt;enumeration value="UATPAllowed"/>
 *     &lt;enumeration value="HandlingFeeAllowed"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PAX-AddOnChargeName-Values", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum PAXAddOnChargeNameValues {

    @XmlEnumValue("ISCAllowed")
    ISC_ALLOWED("ISCAllowed"),
    @XmlEnumValue("OtherCommissionAllowed")
    OTHER_COMMISSION_ALLOWED("OtherCommissionAllowed"),
    @XmlEnumValue("UATPAllowed")
    UATP_ALLOWED("UATPAllowed"),
    @XmlEnumValue("HandlingFeeAllowed")
    HANDLING_FEE_ALLOWED("HandlingFeeAllowed");
    private final String value;

    PAXAddOnChargeNameValues(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PAXAddOnChargeNameValues fromValue(String v) {
        for (PAXAddOnChargeNameValues c: PAXAddOnChargeNameValues.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
