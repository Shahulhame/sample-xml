
package com.sample.app.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}StandNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}StandType" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OnStandDateTime" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OffStandDateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "standNo",
    "standType",
    "onStandDateTime",
    "offStandDateTime"
})
@XmlRootElement(name = "ParkingDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class ParkingDetails {

    @XmlElement(name = "StandNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String standNo;
    @XmlElement(name = "StandType", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String standType;
    @XmlElement(name = "OnStandDateTime", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String onStandDateTime;
    @XmlElement(name = "OffStandDateTime", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String offStandDateTime;

    /**
     * Gets the value of the standNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStandNo() {
        return standNo;
    }

    /**
     * Sets the value of the standNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStandNo(String value) {
        this.standNo = value;
    }

    /**
     * Gets the value of the standType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStandType() {
        return standType;
    }

    /**
     * Sets the value of the standType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStandType(String value) {
        this.standType = value;
    }

    /**
     * Gets the value of the onStandDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOnStandDateTime() {
        return onStandDateTime;
    }

    /**
     * Sets the value of the onStandDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOnStandDateTime(String value) {
        this.onStandDateTime = value;
    }

    /**
     * Gets the value of the offStandDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOffStandDateTime() {
        return offStandDateTime;
    }

    /**
     * Sets the value of the offStandDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOffStandDateTime(String value) {
        this.offStandDateTime = value;
    }

}
