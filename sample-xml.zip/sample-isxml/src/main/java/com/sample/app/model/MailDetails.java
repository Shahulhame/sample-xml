
package com.sample.app.model;

import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}MailNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}MailCategory" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}MailClass" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}NumberofBags" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ContainerNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}BagNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ConsignmentNo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "mailNo",
    "mailCategory",
    "mailClass",
    "numberofBags",
    "containerNo",
    "bagNo",
    "consignmentNo"
})
@XmlRootElement(name = "MailDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class MailDetails {

    @XmlElement(name = "MailNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String mailNo;
    @XmlElement(name = "MailCategory", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String mailCategory;
    @XmlElement(name = "MailClass", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String mailClass;
    @XmlElement(name = "NumberofBags", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger numberofBags;
    @XmlElement(name = "ContainerNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String containerNo;
    @XmlElement(name = "BagNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String bagNo;
    @XmlElement(name = "ConsignmentNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String consignmentNo;

    /**
     * Gets the value of the mailNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailNo() {
        return mailNo;
    }

    /**
     * Sets the value of the mailNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailNo(String value) {
        this.mailNo = value;
    }

    /**
     * Type of mail category as per UPU Standard S41; UPU Code 115
     * 
     *               Possible values are:
     *               A - Airmail or Priority mail
     *               B - S.A.L. mail / Non-priority mail
     *               C - Surface mail / Non-priority mail
     * D - Priority mail sent by surface transportation (optional code)
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailCategory() {
        return mailCategory;
    }

    /**
     * Sets the value of the mailCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailCategory(String value) {
        this.mailCategory = value;
    }

    /**
     * Type of mail class as per UPU Standard S41; UPU Code 116
     * 
     *               Possible values are:
     *               T - Empty receptacles
     *               U  - Letters (LC/AO)
     *               C - Parcels (CP)
     *               E - EMS
     * J - Reserved (NOT to be used)
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailClass() {
        return mailClass;
    }

    /**
     * Sets the value of the mailClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailClass(String value) {
        this.mailClass = value;
    }

    /**
     * Gets the value of the numberofBags property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNumberofBags() {
        return numberofBags;
    }

    /**
     * Sets the value of the numberofBags property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNumberofBags(BigInteger value) {
        this.numberofBags = value;
    }

    /**
     * Gets the value of the containerNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContainerNo() {
        return containerNo;
    }

    /**
     * Sets the value of the containerNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContainerNo(String value) {
        this.containerNo = value;
    }

    /**
     * Gets the value of the bagNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBagNo() {
        return bagNo;
    }

    /**
     * Sets the value of the bagNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBagNo(String value) {
        this.bagNo = value;
    }

    /**
     * Gets the value of the consignmentNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignmentNo() {
        return consignmentNo;
    }

    /**
     * Sets the value of the consignmentNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignmentNo(String value) {
        this.consignmentNo = value;
    }

}
