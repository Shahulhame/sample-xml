package com.sample.app.repository;
/*package com.sgl.smartpra.batch.iata.invoice.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.batch.iata.invoice.app.entity.InboundFileLog;


@Repository
public interface InboundFileLogRepository extends JpaRepository<InboundFileLog , Integer> {

}


*/