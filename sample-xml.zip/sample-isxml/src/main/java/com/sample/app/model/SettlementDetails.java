
package com.sample.app.model;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SettlementCurrencyCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}LocalCurrencyCode" minOccurs="0"/>
 *         &lt;element name="ExchangeRate" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D115Base" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DailyRate" minOccurs="0"/>
 *         &lt;element name="Amount" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
 *                 &lt;attribute name="Name" use="required" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}Amount-Name" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CallDayName" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DueDateFlag" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DueDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DaysOverdue" minOccurs="0"/>
 *         &lt;element name="PartialPayments" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
 *                 &lt;attribute name="Number" use="required" type="{http://www.IATA.com/IATAAviationStandardDataTypes}PosInt03Base" />
 *                 &lt;attribute name="Date" use="required" type="{http://www.IATA.com/IATAAviationStandardDataTypes}DTBase" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ClearancePeriod" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}InterestRate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SuspendedAirline" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}InvoiceRefNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}FareClass" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "settlementCurrencyCode",
    "localCurrencyCode",
    "exchangeRate",
    "dailyRate",
    "amount",
    "callDayName",
    "dueDateFlag",
    "dueDate",
    "daysOverdue",
    "partialPayments",
    "clearancePeriod",
    "interestRate",
    "suspendedAirline",
    "invoiceRefNumber",
    "fareClass"
})
@XmlRootElement(name = "SettlementDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class SettlementDetails {

    @XmlElement(name = "SettlementCurrencyCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String settlementCurrencyCode;
    @XmlElement(name = "LocalCurrencyCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String localCurrencyCode;
    @XmlElement(name = "ExchangeRate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal exchangeRate;
    @XmlElement(name = "DailyRate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal dailyRate;
    @XmlElement(name = "Amount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected SettlementDetails.Amount amount;
    @XmlElement(name = "CallDayName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String callDayName;
    @XmlElement(name = "DueDateFlag", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String dueDateFlag;
    @XmlElement(name = "DueDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String dueDate;
    @XmlElement(name = "DaysOverdue", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger daysOverdue;
    @XmlElement(name = "PartialPayments", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected SettlementDetails.PartialPayments partialPayments;
    @XmlElement(name = "ClearancePeriod", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String clearancePeriod;
    @XmlElement(name = "InterestRate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal interestRate;
    @XmlElement(name = "SuspendedAirline", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String suspendedAirline;
    @XmlElement(name = "InvoiceRefNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String invoiceRefNumber;
    @XmlElement(name = "FareClass", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String fareClass;

    /**
     * Gets the value of the settlementCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSettlementCurrencyCode() {
        return settlementCurrencyCode;
    }

    /**
     * Sets the value of the settlementCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSettlementCurrencyCode(String value) {
        this.settlementCurrencyCode = value;
    }

    /**
     * Gets the value of the localCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalCurrencyCode() {
        return localCurrencyCode;
    }

    /**
     * Sets the value of the localCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalCurrencyCode(String value) {
        this.localCurrencyCode = value;
    }

    /**
     * Gets the value of the exchangeRate property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getExchangeRate() {
        return exchangeRate;
    }

    /**
     * Sets the value of the exchangeRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setExchangeRate(BigDecimal value) {
        this.exchangeRate = value;
    }

    /**
     * Gets the value of the dailyRate property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDailyRate() {
        return dailyRate;
    }

    /**
     * Sets the value of the dailyRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDailyRate(BigDecimal value) {
        this.dailyRate = value;
    }

    /**
     * Gets the value of the amount property.
     * 
     * @return
     *     possible object is
     *     {@link SettlementDetails.Amount }
     *     
     */
    public SettlementDetails.Amount getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link SettlementDetails.Amount }
     *     
     */
    public void setAmount(SettlementDetails.Amount value) {
        this.amount = value;
    }

    /**
     * Gets the value of the callDayName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallDayName() {
        return callDayName;
    }

    /**
     * Sets the value of the callDayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallDayName(String value) {
        this.callDayName = value;
    }

    /**
     * Gets the value of the dueDateFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDueDateFlag() {
        return dueDateFlag;
    }

    /**
     * Sets the value of the dueDateFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDueDateFlag(String value) {
        this.dueDateFlag = value;
    }

    /**
     * Gets the value of the dueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDueDate() {
        return dueDate;
    }

    /**
     * Sets the value of the dueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDueDate(String value) {
        this.dueDate = value;
    }

    /**
     * Gets the value of the daysOverdue property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDaysOverdue() {
        return daysOverdue;
    }

    /**
     * Sets the value of the daysOverdue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDaysOverdue(BigInteger value) {
        this.daysOverdue = value;
    }

    /**
     * Gets the value of the partialPayments property.
     * 
     * @return
     *     possible object is
     *     {@link SettlementDetails.PartialPayments }
     *     
     */
    public SettlementDetails.PartialPayments getPartialPayments() {
        return partialPayments;
    }

    /**
     * Sets the value of the partialPayments property.
     * 
     * @param value
     *     allowed object is
     *     {@link SettlementDetails.PartialPayments }
     *     
     */
    public void setPartialPayments(SettlementDetails.PartialPayments value) {
        this.partialPayments = value;
    }

    /**
     * Gets the value of the clearancePeriod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClearancePeriod() {
        return clearancePeriod;
    }

    /**
     * Sets the value of the clearancePeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClearancePeriod(String value) {
        this.clearancePeriod = value;
    }

    /**
     * Gets the value of the interestRate property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInterestRate() {
        return interestRate;
    }

    /**
     * Sets the value of the interestRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInterestRate(BigDecimal value) {
        this.interestRate = value;
    }

    /**
     * Gets the value of the suspendedAirline property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuspendedAirline() {
        return suspendedAirline;
    }

    /**
     * Sets the value of the suspendedAirline property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuspendedAirline(String value) {
        this.suspendedAirline = value;
    }

    /**
     * Gets the value of the invoiceRefNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvoiceRefNumber() {
        return invoiceRefNumber;
    }

    /**
     * Sets the value of the invoiceRefNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvoiceRefNumber(String value) {
        this.invoiceRefNumber = value;
    }

    /**
     * Gets the value of the fareClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFareClass() {
        return fareClass;
    }

    /**
     * Sets the value of the fareClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFareClass(String value) {
        this.fareClass = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
     *       &lt;attribute name="Name" use="required" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}Amount-Name" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class Amount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "Name", required = true)
        protected String name;

        /**
         * Base used for numbers of type decimal(18,3)
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setName(String value) {
            this.name = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
     *       &lt;attribute name="Number" use="required" type="{http://www.IATA.com/IATAAviationStandardDataTypes}PosInt03Base" />
     *       &lt;attribute name="Date" use="required" type="{http://www.IATA.com/IATAAviationStandardDataTypes}DTBase" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class PartialPayments {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "Number", required = true)
        protected BigInteger number;
        @XmlAttribute(name = "Date", required = true)
        protected String date;

        /**
         * Base used for numbers of type decimal(18,3)
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the number property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getNumber() {
            return number;
        }

        /**
         * Sets the value of the number property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setNumber(BigInteger value) {
            this.number = value;
        }

        /**
         * Gets the value of the date property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDate() {
            return date;
        }

        /**
         * Sets the value of the date property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDate(String value) {
            this.date = value;
        }

    }

}
