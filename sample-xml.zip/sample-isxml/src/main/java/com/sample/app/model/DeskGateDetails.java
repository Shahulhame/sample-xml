
package com.sample.app.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DeskID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DeskLocationName" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DeskType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "deskID",
    "deskLocationName",
    "deskType"
})
@XmlRootElement(name = "Desk-GateDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class DeskGateDetails {

    @XmlElement(name = "DeskID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String deskID;
    @XmlElement(name = "DeskLocationName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String deskLocationName;
    @XmlElement(name = "DeskType", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String deskType;

    /**
     * Gets the value of the deskID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeskID() {
        return deskID;
    }

    /**
     * Sets the value of the deskID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeskID(String value) {
        this.deskID = value;
    }

    /**
     * Gets the value of the deskLocationName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeskLocationName() {
        return deskLocationName;
    }

    /**
     * Sets the value of the deskLocationName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeskLocationName(String value) {
        this.deskLocationName = value;
    }

    /**
     * Gets the value of the deskType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeskType() {
        return deskType;
    }

    /**
     * Sets the value of the deskType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeskType(String value) {
        this.deskType = value;
    }

}
