
package com.sample.app.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OrganizationID"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OrganizationDesignator" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}LocationID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OrganizationName1" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OrganizationName2" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxRegistrationID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AdditionalTaxRegistrationID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CompanyRegistrationID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ContactName" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ContactDetails" maxOccurs="10" minOccurs="0"/>
 *         &lt;element name="Address" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddressLine1"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddressLine2" minOccurs="0"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddressLine3" minOccurs="0"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CityName" minOccurs="0"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SubdivisionCode" minOccurs="0"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SubdivisionName" minOccurs="0"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CountryCode"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CountryCode_ICAO" minOccurs="0"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CountryName" minOccurs="0"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PostalCode" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OrganizationData" maxOccurs="20" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "organizationID",
    "organizationDesignator",
    "locationID",
    "organizationName1",
    "organizationName2",
    "taxRegistrationID",
    "additionalTaxRegistrationID",
    "companyRegistrationID",
    "contactName",
    "contactDetails",
    "address",
    "organizationData"
})
@XmlRootElement(name = "BuyerOrganization", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class BuyerOrganization {

    @XmlElement(name = "OrganizationID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String organizationID;
    @XmlElement(name = "OrganizationDesignator", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String organizationDesignator;
    @XmlElement(name = "LocationID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String locationID;
    @XmlElement(name = "OrganizationName1", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String organizationName1;
    @XmlElement(name = "OrganizationName2", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String organizationName2;
    @XmlElement(name = "TaxRegistrationID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String taxRegistrationID;
    @XmlElement(name = "AdditionalTaxRegistrationID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String additionalTaxRegistrationID;
    @XmlElement(name = "CompanyRegistrationID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String companyRegistrationID;
    @XmlElement(name = "ContactName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String contactName;
    @XmlElement(name = "ContactDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<ContactDetails> contactDetails;
    @XmlElement(name = "Address", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BuyerOrganization.Address address;
    @XmlElement(name = "OrganizationData", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<OrganizationData> organizationData;

    /**
     * Gets the value of the organizationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganizationID() {
        return organizationID;
    }

    /**
     * Sets the value of the organizationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganizationID(String value) {
        this.organizationID = value;
    }

    /**
     * Gets the value of the organizationDesignator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganizationDesignator() {
        return organizationDesignator;
    }

    /**
     * Sets the value of the organizationDesignator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganizationDesignator(String value) {
        this.organizationDesignator = value;
    }

    /**
     * Gets the value of the locationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationID() {
        return locationID;
    }

    /**
     * Sets the value of the locationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationID(String value) {
        this.locationID = value;
    }

    /**
     * Gets the value of the organizationName1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganizationName1() {
        return organizationName1;
    }

    /**
     * Sets the value of the organizationName1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganizationName1(String value) {
        this.organizationName1 = value;
    }

    /**
     * Gets the value of the organizationName2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganizationName2() {
        return organizationName2;
    }

    /**
     * Sets the value of the organizationName2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganizationName2(String value) {
        this.organizationName2 = value;
    }

    /**
     * Gets the value of the taxRegistrationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxRegistrationID() {
        return taxRegistrationID;
    }

    /**
     * Sets the value of the taxRegistrationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxRegistrationID(String value) {
        this.taxRegistrationID = value;
    }

    /**
     * Gets the value of the additionalTaxRegistrationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalTaxRegistrationID() {
        return additionalTaxRegistrationID;
    }

    /**
     * Sets the value of the additionalTaxRegistrationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalTaxRegistrationID(String value) {
        this.additionalTaxRegistrationID = value;
    }

    /**
     * Gets the value of the companyRegistrationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompanyRegistrationID() {
        return companyRegistrationID;
    }

    /**
     * Sets the value of the companyRegistrationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompanyRegistrationID(String value) {
        this.companyRegistrationID = value;
    }

    /**
     * Gets the value of the contactName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * Sets the value of the contactName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactName(String value) {
        this.contactName = value;
    }

    /**
     * Gets the value of the contactDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the contactDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContactDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ContactDetails }
     * 
     * 
     */
    public List<ContactDetails> getContactDetails() {
        if (contactDetails == null) {
            contactDetails = new ArrayList<ContactDetails>();
        }
        return this.contactDetails;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link BuyerOrganization.Address }
     *     
     */
    public BuyerOrganization.Address getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link BuyerOrganization.Address }
     *     
     */
    public void setAddress(BuyerOrganization.Address value) {
        this.address = value;
    }

    /**
     * Gets the value of the organizationData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the organizationData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOrganizationData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OrganizationData }
     * 
     * 
     */
    public List<OrganizationData> getOrganizationData() {
        if (organizationData == null) {
            organizationData = new ArrayList<OrganizationData>();
        }
        return this.organizationData;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddressLine1"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddressLine2" minOccurs="0"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddressLine3" minOccurs="0"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CityName" minOccurs="0"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SubdivisionCode" minOccurs="0"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SubdivisionName" minOccurs="0"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CountryCode"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CountryCode_ICAO" minOccurs="0"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CountryName" minOccurs="0"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PostalCode" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "addressLine1",
        "addressLine2",
        "addressLine3",
        "cityName",
        "subdivisionCode",
        "subdivisionName",
        "countryCode",
        "countryCodeICAO",
        "countryName",
        "postalCode"
    })
    public static class Address {

        @XmlElement(name = "AddressLine1", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
        protected String addressLine1;
        @XmlElement(name = "AddressLine2", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
        protected String addressLine2;
        @XmlElement(name = "AddressLine3", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
        protected String addressLine3;
        @XmlElement(name = "CityName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
        protected String cityName;
        @XmlElement(name = "SubdivisionCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
        protected String subdivisionCode;
        @XmlElement(name = "SubdivisionName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
        protected String subdivisionName;
        @XmlElement(name = "CountryCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
        protected String countryCode;
        @XmlElement(name = "CountryCode_ICAO", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
        protected String countryCodeICAO;
        @XmlElement(name = "CountryName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
        protected String countryName;
        @XmlElement(name = "PostalCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
        protected String postalCode;

        /**
         * Gets the value of the addressLine1 property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAddressLine1() {
            return addressLine1;
        }

        /**
         * Sets the value of the addressLine1 property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAddressLine1(String value) {
            this.addressLine1 = value;
        }

        /**
         * Gets the value of the addressLine2 property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAddressLine2() {
            return addressLine2;
        }

        /**
         * Sets the value of the addressLine2 property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAddressLine2(String value) {
            this.addressLine2 = value;
        }

        /**
         * Gets the value of the addressLine3 property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAddressLine3() {
            return addressLine3;
        }

        /**
         * Sets the value of the addressLine3 property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAddressLine3(String value) {
            this.addressLine3 = value;
        }

        /**
         * Gets the value of the cityName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCityName() {
            return cityName;
        }

        /**
         * Sets the value of the cityName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCityName(String value) {
            this.cityName = value;
        }

        /**
         * Gets the value of the subdivisionCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSubdivisionCode() {
            return subdivisionCode;
        }

        /**
         * Sets the value of the subdivisionCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSubdivisionCode(String value) {
            this.subdivisionCode = value;
        }

        /**
         * Gets the value of the subdivisionName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSubdivisionName() {
            return subdivisionName;
        }

        /**
         * Sets the value of the subdivisionName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSubdivisionName(String value) {
            this.subdivisionName = value;
        }

        /**
         * Gets the value of the countryCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCountryCode() {
            return countryCode;
        }

        /**
         * Sets the value of the countryCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCountryCode(String value) {
            this.countryCode = value;
        }

        /**
         * Gets the value of the countryCodeICAO property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCountryCodeICAO() {
            return countryCodeICAO;
        }

        /**
         * Sets the value of the countryCodeICAO property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCountryCodeICAO(String value) {
            this.countryCodeICAO = value;
        }

        /**
         * Gets the value of the countryName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCountryName() {
            return countryName;
        }

        /**
         * Sets the value of the countryName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCountryName(String value) {
            this.countryName = value;
        }

        /**
         * Gets the value of the postalCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPostalCode() {
            return postalCode;
        }

        /**
         * Sets the value of the postalCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPostalCode(String value) {
            this.postalCode = value;
        }

    }

}
