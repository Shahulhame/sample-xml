
package com.sample.app.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GrossTotalOfUniverse" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base"/>
 *         &lt;element name="GrossTotalOfUAF" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base"/>
 *         &lt;element name="UniverseAdjustedGrossAmount" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base"/>
 *         &lt;element name="GrossTotalOfSample" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base"/>
 *         &lt;element name="GrossTotalOfUAFSampleCoupon" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base"/>
 *         &lt;element name="SampleAdjustedGrossAmount" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SamplingConstant"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ListingAmountAfterSC" maxOccurs="7"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}NetAmountDueInListingCurrency"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}NetAmountDueInBillingCurrency"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisionalFormBAmount" maxOccurs="7" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TotalFormBAmount"/>
 *         &lt;element name="NetBilledCreditedAmount" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base"/>
 *         &lt;element name="ProvisionalInvoiceDetails" maxOccurs="unbounded" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisionalInvoiceNumber"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisionalInvoiceDate"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisionalBillingPeriodNo"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisionalInvoiceListingCurrency"/>
 *                   &lt;element name="ProvisionalInvoiceListingAmount" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisionalListingToBillingRate"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisionalInvoiceBillingAmount"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "grossTotalOfUniverse",
    "grossTotalOfUAF",
    "universeAdjustedGrossAmount",
    "grossTotalOfSample",
    "grossTotalOfUAFSampleCoupon",
    "sampleAdjustedGrossAmount",
    "samplingConstant",
    "listingAmountAfterSC",
    "netAmountDueInListingCurrency",
    "netAmountDueInBillingCurrency",
    "provisionalFormBAmount",
    "totalFormBAmount",
    "netBilledCreditedAmount",
    "provisionalInvoiceDetails"
})
@XmlRootElement(name = "SamplingFormEDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class SamplingFormEDetails {

    @XmlElement(name = "GrossTotalOfUniverse", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigDecimal grossTotalOfUniverse;
    @XmlElement(name = "GrossTotalOfUAF", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigDecimal grossTotalOfUAF;
    @XmlElement(name = "UniverseAdjustedGrossAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigDecimal universeAdjustedGrossAmount;
    @XmlElement(name = "GrossTotalOfSample", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigDecimal grossTotalOfSample;
    @XmlElement(name = "GrossTotalOfUAFSampleCoupon", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigDecimal grossTotalOfUAFSampleCoupon;
    @XmlElement(name = "SampleAdjustedGrossAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigDecimal sampleAdjustedGrossAmount;
    @XmlElement(name = "SamplingConstant", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigDecimal samplingConstant;
    @XmlElement(name = "ListingAmountAfterSC", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected List<ListingAmountAfterSC> listingAmountAfterSC;
    @XmlElement(name = "NetAmountDueInListingCurrency", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigDecimal netAmountDueInListingCurrency;
    @XmlElement(name = "NetAmountDueInBillingCurrency", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigDecimal netAmountDueInBillingCurrency;
    @XmlElement(name = "ProvisionalFormBAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<ProvisionalFormBAmount> provisionalFormBAmount;
    @XmlElement(name = "TotalFormBAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigDecimal totalFormBAmount;
    @XmlElement(name = "NetBilledCreditedAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigDecimal netBilledCreditedAmount;
    @XmlElement(name = "ProvisionalInvoiceDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<SamplingFormEDetails.ProvisionalInvoiceDetails> provisionalInvoiceDetails;

    /**
     * Gets the value of the grossTotalOfUniverse property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGrossTotalOfUniverse() {
        return grossTotalOfUniverse;
    }

    /**
     * Sets the value of the grossTotalOfUniverse property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGrossTotalOfUniverse(BigDecimal value) {
        this.grossTotalOfUniverse = value;
    }

    /**
     * Gets the value of the grossTotalOfUAF property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGrossTotalOfUAF() {
        return grossTotalOfUAF;
    }

    /**
     * Sets the value of the grossTotalOfUAF property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGrossTotalOfUAF(BigDecimal value) {
        this.grossTotalOfUAF = value;
    }

    /**
     * Gets the value of the universeAdjustedGrossAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getUniverseAdjustedGrossAmount() {
        return universeAdjustedGrossAmount;
    }

    /**
     * Sets the value of the universeAdjustedGrossAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setUniverseAdjustedGrossAmount(BigDecimal value) {
        this.universeAdjustedGrossAmount = value;
    }

    /**
     * Gets the value of the grossTotalOfSample property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGrossTotalOfSample() {
        return grossTotalOfSample;
    }

    /**
     * Sets the value of the grossTotalOfSample property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGrossTotalOfSample(BigDecimal value) {
        this.grossTotalOfSample = value;
    }

    /**
     * Gets the value of the grossTotalOfUAFSampleCoupon property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGrossTotalOfUAFSampleCoupon() {
        return grossTotalOfUAFSampleCoupon;
    }

    /**
     * Sets the value of the grossTotalOfUAFSampleCoupon property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGrossTotalOfUAFSampleCoupon(BigDecimal value) {
        this.grossTotalOfUAFSampleCoupon = value;
    }

    /**
     * Gets the value of the sampleAdjustedGrossAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSampleAdjustedGrossAmount() {
        return sampleAdjustedGrossAmount;
    }

    /**
     * Sets the value of the sampleAdjustedGrossAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSampleAdjustedGrossAmount(BigDecimal value) {
        this.sampleAdjustedGrossAmount = value;
    }

    /**
     * Gets the value of the samplingConstant property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSamplingConstant() {
        return samplingConstant;
    }

    /**
     * Sets the value of the samplingConstant property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSamplingConstant(BigDecimal value) {
        this.samplingConstant = value;
    }

    /**
     * Gets the value of the listingAmountAfterSC property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the listingAmountAfterSC property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getListingAmountAfterSC().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ListingAmountAfterSC }
     * 
     * 
     */
    public List<ListingAmountAfterSC> getListingAmountAfterSC() {
        if (listingAmountAfterSC == null) {
            listingAmountAfterSC = new ArrayList<ListingAmountAfterSC>();
        }
        return this.listingAmountAfterSC;
    }

    /**
     * Gets the value of the netAmountDueInListingCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getNetAmountDueInListingCurrency() {
        return netAmountDueInListingCurrency;
    }

    /**
     * Sets the value of the netAmountDueInListingCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setNetAmountDueInListingCurrency(BigDecimal value) {
        this.netAmountDueInListingCurrency = value;
    }

    /**
     * Gets the value of the netAmountDueInBillingCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getNetAmountDueInBillingCurrency() {
        return netAmountDueInBillingCurrency;
    }

    /**
     * Sets the value of the netAmountDueInBillingCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setNetAmountDueInBillingCurrency(BigDecimal value) {
        this.netAmountDueInBillingCurrency = value;
    }

    /**
     * Gets the value of the provisionalFormBAmount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the provisionalFormBAmount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProvisionalFormBAmount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProvisionalFormBAmount }
     * 
     * 
     */
    public List<ProvisionalFormBAmount> getProvisionalFormBAmount() {
        if (provisionalFormBAmount == null) {
            provisionalFormBAmount = new ArrayList<ProvisionalFormBAmount>();
        }
        return this.provisionalFormBAmount;
    }

    /**
     * Gets the value of the totalFormBAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalFormBAmount() {
        return totalFormBAmount;
    }

    /**
     * Sets the value of the totalFormBAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalFormBAmount(BigDecimal value) {
        this.totalFormBAmount = value;
    }

    /**
     * Gets the value of the netBilledCreditedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getNetBilledCreditedAmount() {
        return netBilledCreditedAmount;
    }

    /**
     * Sets the value of the netBilledCreditedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setNetBilledCreditedAmount(BigDecimal value) {
        this.netBilledCreditedAmount = value;
    }

    /**
     * Gets the value of the provisionalInvoiceDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the provisionalInvoiceDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProvisionalInvoiceDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SamplingFormEDetails.ProvisionalInvoiceDetails }
     * 
     * 
     */
    public List<SamplingFormEDetails.ProvisionalInvoiceDetails> getProvisionalInvoiceDetails() {
        if (provisionalInvoiceDetails == null) {
            provisionalInvoiceDetails = new ArrayList<SamplingFormEDetails.ProvisionalInvoiceDetails>();
        }
        return this.provisionalInvoiceDetails;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisionalInvoiceNumber"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisionalInvoiceDate"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisionalBillingPeriodNo"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisionalInvoiceListingCurrency"/>
     *         &lt;element name="ProvisionalInvoiceListingAmount" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisionalListingToBillingRate"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisionalInvoiceBillingAmount"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "provisionalInvoiceNumber",
        "provisionalInvoiceDate",
        "provisionalBillingPeriodNo",
        "provisionalInvoiceListingCurrency",
        "provisionalInvoiceListingAmount",
        "provisionalListingToBillingRate",
        "provisionalInvoiceBillingAmount"
    })
    public static class ProvisionalInvoiceDetails {

        @XmlElement(name = "ProvisionalInvoiceNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
        protected String provisionalInvoiceNumber;
        @XmlElement(name = "ProvisionalInvoiceDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
        protected String provisionalInvoiceDate;
        @XmlElement(name = "ProvisionalBillingPeriodNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
        protected BigInteger provisionalBillingPeriodNo;
        @XmlElement(name = "ProvisionalInvoiceListingCurrency", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
        protected String provisionalInvoiceListingCurrency;
        @XmlElement(name = "ProvisionalInvoiceListingAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
        protected BigDecimal provisionalInvoiceListingAmount;
        @XmlElement(name = "ProvisionalListingToBillingRate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
        protected BigDecimal provisionalListingToBillingRate;
        @XmlElement(name = "ProvisionalInvoiceBillingAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
        protected BigDecimal provisionalInvoiceBillingAmount;

        /**
         * Gets the value of the provisionalInvoiceNumber property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getProvisionalInvoiceNumber() {
            return provisionalInvoiceNumber;
        }

        /**
         * Sets the value of the provisionalInvoiceNumber property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setProvisionalInvoiceNumber(String value) {
            this.provisionalInvoiceNumber = value;
        }

        /**
         * Gets the value of the provisionalInvoiceDate property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getProvisionalInvoiceDate() {
            return provisionalInvoiceDate;
        }

        /**
         * Sets the value of the provisionalInvoiceDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setProvisionalInvoiceDate(String value) {
            this.provisionalInvoiceDate = value;
        }

        /**
         * Gets the value of the provisionalBillingPeriodNo property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getProvisionalBillingPeriodNo() {
            return provisionalBillingPeriodNo;
        }

        /**
         * Sets the value of the provisionalBillingPeriodNo property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setProvisionalBillingPeriodNo(BigInteger value) {
            this.provisionalBillingPeriodNo = value;
        }

        /**
         * Gets the value of the provisionalInvoiceListingCurrency property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getProvisionalInvoiceListingCurrency() {
            return provisionalInvoiceListingCurrency;
        }

        /**
         * Sets the value of the provisionalInvoiceListingCurrency property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setProvisionalInvoiceListingCurrency(String value) {
            this.provisionalInvoiceListingCurrency = value;
        }

        /**
         * Gets the value of the provisionalInvoiceListingAmount property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getProvisionalInvoiceListingAmount() {
            return provisionalInvoiceListingAmount;
        }

        /**
         * Sets the value of the provisionalInvoiceListingAmount property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setProvisionalInvoiceListingAmount(BigDecimal value) {
            this.provisionalInvoiceListingAmount = value;
        }

        /**
         * Gets the value of the provisionalListingToBillingRate property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getProvisionalListingToBillingRate() {
            return provisionalListingToBillingRate;
        }

        /**
         * Sets the value of the provisionalListingToBillingRate property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setProvisionalListingToBillingRate(BigDecimal value) {
            this.provisionalListingToBillingRate = value;
        }

        /**
         * Indicates the amount in Currency of Billing as defined in the Invoice Header record with two decimal places. Should be equal to ProvisionalInvoiceListingAmount / ProvisionalListingtoBillingRate
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getProvisionalInvoiceBillingAmount() {
            return provisionalInvoiceBillingAmount;
        }

        /**
         * Sets the value of the provisionalInvoiceBillingAmount property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setProvisionalInvoiceBillingAmount(BigDecimal value) {
            this.provisionalInvoiceBillingAmount = value;
        }

    }

}
