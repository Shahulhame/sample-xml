
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ChargeAmount-Name.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ChargeAmount-Name">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="GrossBilled"/>
 *     &lt;enumeration value="GrossAccepted"/>
 *     &lt;enumeration value="GrossDifference"/>
 *     &lt;enumeration value="WeightBilled"/>
 *     &lt;enumeration value="WeightAccepted"/>
 *     &lt;enumeration value="WeightDifference"/>
 *     &lt;enumeration value="ValuationBilled"/>
 *     &lt;enumeration value="ValuationAccepted"/>
 *     &lt;enumeration value="ValuationDifference"/>
 *     &lt;enumeration value="GrossCredited"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ChargeAmount-Name", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum ChargeAmountName {

    @XmlEnumValue("GrossBilled")
    GROSS_BILLED("GrossBilled"),
    @XmlEnumValue("GrossAccepted")
    GROSS_ACCEPTED("GrossAccepted"),
    @XmlEnumValue("GrossDifference")
    GROSS_DIFFERENCE("GrossDifference"),
    @XmlEnumValue("WeightBilled")
    WEIGHT_BILLED("WeightBilled"),
    @XmlEnumValue("WeightAccepted")
    WEIGHT_ACCEPTED("WeightAccepted"),
    @XmlEnumValue("WeightDifference")
    WEIGHT_DIFFERENCE("WeightDifference"),
    @XmlEnumValue("ValuationBilled")
    VALUATION_BILLED("ValuationBilled"),
    @XmlEnumValue("ValuationAccepted")
    VALUATION_ACCEPTED("ValuationAccepted"),
    @XmlEnumValue("ValuationDifference")
    VALUATION_DIFFERENCE("ValuationDifference"),
    @XmlEnumValue("GrossCredited")
    GROSS_CREDITED("GrossCredited");
    private final String value;

    ChargeAmountName(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ChargeAmountName fromValue(String v) {
        for (ChargeAmountName c: ChargeAmountName.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
