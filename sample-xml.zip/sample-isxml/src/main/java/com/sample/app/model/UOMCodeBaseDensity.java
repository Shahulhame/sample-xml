
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UOMCodeBaseDensity.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="UOMCodeBaseDensity">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN03Base">
 *     &lt;enumeration value="KGV"/>
 *     &lt;enumeration value="L92"/>
 *     &lt;enumeration value="L93"/>
 *     &lt;enumeration value="LGH"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "UOMCodeBaseDensity", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum UOMCodeBaseDensity {

    KGV("KGV"),
    @XmlEnumValue("L92")
    L_92("L92"),
    @XmlEnumValue("L93")
    L_93("L93"),
    LGH("LGH");
    private final String value;

    UOMCodeBaseDensity(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static UOMCodeBaseDensity fromValue(String v) {
        for (UOMCodeBaseDensity c: UOMCodeBaseDensity.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
