
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for HandlingFeeType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="HandlingFeeType">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}A01Base">
 *     &lt;enumeration value="A"/>
 *     &lt;enumeration value="C"/>
 *     &lt;enumeration value="S"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "HandlingFeeType", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum HandlingFeeType {

    A,
    C,
    S;

    public String value() {
        return name();
    }

    public static HandlingFeeType fromValue(String v) {
        return valueOf(v);
    }

}
