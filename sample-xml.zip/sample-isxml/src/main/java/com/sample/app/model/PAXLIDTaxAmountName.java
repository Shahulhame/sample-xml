
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PAX-LID-TaxAmount-Name.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PAX-LID-TaxAmount-Name">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="Billed"/>
 *     &lt;enumeration value="Accepted"/>
 *     &lt;enumeration value="Difference"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PAX-LID-TaxAmount-Name", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum PAXLIDTaxAmountName {

    @XmlEnumValue("Billed")
    BILLED("Billed"),
    @XmlEnumValue("Accepted")
    ACCEPTED("Accepted"),
    @XmlEnumValue("Difference")
    DIFFERENCE("Difference");
    private final String value;

    PAXLIDTaxAmountName(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PAXLIDTaxAmountName fromValue(String v) {
        for (PAXLIDTaxAmountName c: PAXLIDTaxAmountName.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
