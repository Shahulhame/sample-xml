
package com.sample.app.model;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}MeterID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}MeterLocationName" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}StartReading" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}StartDateTime" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}StartEstimate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}EndReading" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}EndDateTime" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}EndEstimate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ConsumedUnits" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Temperature" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Density" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "meterID",
    "meterLocationName",
    "startReading",
    "startDateTime",
    "startEstimate",
    "endReading",
    "endDateTime",
    "endEstimate",
    "consumedUnits",
    "temperature",
    "density"
})
@XmlRootElement(name = "ConsumptionDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class ConsumptionDetails {

    @XmlElement(name = "MeterID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String meterID;
    @XmlElement(name = "MeterLocationName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String meterLocationName;
    @XmlElement(name = "StartReading", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal startReading;
    @XmlElement(name = "StartDateTime", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String startDateTime;
    @XmlElement(name = "StartEstimate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String startEstimate;
    @XmlElement(name = "EndReading", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal endReading;
    @XmlElement(name = "EndDateTime", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String endDateTime;
    @XmlElement(name = "EndEstimate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String endEstimate;
    @XmlElement(name = "ConsumedUnits", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected ConsumedUnits consumedUnits;
    @XmlElement(name = "Temperature", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected Temperature temperature;
    @XmlElement(name = "Density", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected Density density;

    /**
     * Gets the value of the meterID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMeterID() {
        return meterID;
    }

    /**
     * Sets the value of the meterID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMeterID(String value) {
        this.meterID = value;
    }

    /**
     * Gets the value of the meterLocationName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMeterLocationName() {
        return meterLocationName;
    }

    /**
     * Sets the value of the meterLocationName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMeterLocationName(String value) {
        this.meterLocationName = value;
    }

    /**
     * Gets the value of the startReading property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getStartReading() {
        return startReading;
    }

    /**
     * Sets the value of the startReading property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setStartReading(BigDecimal value) {
        this.startReading = value;
    }

    /**
     * Gets the value of the startDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartDateTime() {
        return startDateTime;
    }

    /**
     * Sets the value of the startDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartDateTime(String value) {
        this.startDateTime = value;
    }

    /**
     * Gets the value of the startEstimate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartEstimate() {
        return startEstimate;
    }

    /**
     * Sets the value of the startEstimate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartEstimate(String value) {
        this.startEstimate = value;
    }

    /**
     * Gets the value of the endReading property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getEndReading() {
        return endReading;
    }

    /**
     * Sets the value of the endReading property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setEndReading(BigDecimal value) {
        this.endReading = value;
    }

    /**
     * Gets the value of the endDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndDateTime() {
        return endDateTime;
    }

    /**
     * Sets the value of the endDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndDateTime(String value) {
        this.endDateTime = value;
    }

    /**
     * Gets the value of the endEstimate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndEstimate() {
        return endEstimate;
    }

    /**
     * Sets the value of the endEstimate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndEstimate(String value) {
        this.endEstimate = value;
    }

    /**
     * Gets the value of the consumedUnits property.
     * 
     * @return
     *     possible object is
     *     {@link ConsumedUnits }
     *     
     */
    public ConsumedUnits getConsumedUnits() {
        return consumedUnits;
    }

    /**
     * Sets the value of the consumedUnits property.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsumedUnits }
     *     
     */
    public void setConsumedUnits(ConsumedUnits value) {
        this.consumedUnits = value;
    }

    /**
     * Gets the value of the temperature property.
     * 
     * @return
     *     possible object is
     *     {@link Temperature }
     *     
     */
    public Temperature getTemperature() {
        return temperature;
    }

    /**
     * Sets the value of the temperature property.
     * 
     * @param value
     *     allowed object is
     *     {@link Temperature }
     *     
     */
    public void setTemperature(Temperature value) {
        this.temperature = value;
    }

    /**
     * Gets the value of the density property.
     * 
     * @return
     *     possible object is
     *     {@link Density }
     *     
     */
    public Density getDensity() {
        return density;
    }

    /**
     * Sets the value of the density property.
     * 
     * @param value
     *     allowed object is
     *     {@link Density }
     *     
     */
    public void setDensity(Density value) {
        this.density = value;
    }

}
