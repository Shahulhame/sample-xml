
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MinimumQuantityFlag.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="MinimumQuantityFlag">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}A01Base">
 *     &lt;enumeration value="Y"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "MinimumQuantityFlag", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum MinimumQuantityFlag {

    Y;

    public String value() {
        return name();
    }

    public static MinimumQuantityFlag fromValue(String v) {
        return valueOf(v);
    }

}
