
package com.sample.app.model;

import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="InvoiceNumber" type="{http://www.IATA.com/IATAAviationStandardDataTypes}AN10Base"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AuthorityToBillFlag"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CorrespondenceRefNumber"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "invoiceNumber",
    "authorityToBillFlag",
    "correspondenceRefNumber"
})
@XmlRootElement(name = "CorrespondenceDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class CorrespondenceDetails {

    @XmlElement(name = "InvoiceNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String invoiceNumber;
    @XmlElement(name = "AuthorityToBillFlag", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    @XmlSchemaType(name = "string")
    protected BooleanFlag authorityToBillFlag;
    @XmlElement(name = "CorrespondenceRefNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigInteger correspondenceRefNumber;

    /**
     * Gets the value of the invoiceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    /**
     * Sets the value of the invoiceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvoiceNumber(String value) {
        this.invoiceNumber = value;
    }

    /**
     * Gets the value of the authorityToBillFlag property.
     * 
     * @return
     *     possible object is
     *     {@link BooleanFlag }
     *     
     */
    public BooleanFlag getAuthorityToBillFlag() {
        return authorityToBillFlag;
    }

    /**
     * Sets the value of the authorityToBillFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link BooleanFlag }
     *     
     */
    public void setAuthorityToBillFlag(BooleanFlag value) {
        this.authorityToBillFlag = value;
    }

    /**
     * Gets the value of the correspondenceRefNumber property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCorrespondenceRefNumber() {
        return correspondenceRefNumber;
    }

    /**
     * Sets the value of the correspondenceRefNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCorrespondenceRefNumber(BigInteger value) {
        this.correspondenceRefNumber = value;
    }

}
