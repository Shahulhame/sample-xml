
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PAX-LID-AddOnChargeName-Values.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PAX-LID-AddOnChargeName-Values">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN30Base">
 *     &lt;enumeration value="ISCAllowed"/>
 *     &lt;enumeration value="ISCAccepted"/>
 *     &lt;enumeration value="ISCDifference"/>
 *     &lt;enumeration value="OtherCommissionAllowed"/>
 *     &lt;enumeration value="OtherCommissionAccepted"/>
 *     &lt;enumeration value="OtherCommissionDifference"/>
 *     &lt;enumeration value="UATPAllowed"/>
 *     &lt;enumeration value="UATPAccepted"/>
 *     &lt;enumeration value="UATPDifference"/>
 *     &lt;enumeration value="HandlingFeeAllowed"/>
 *     &lt;enumeration value="HandlingFeeAccepted"/>
 *     &lt;enumeration value="HandlingFeeDifference"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PAX-LID-AddOnChargeName-Values", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum PAXLIDAddOnChargeNameValues {

    @XmlEnumValue("ISCAllowed")
    ISC_ALLOWED("ISCAllowed"),
    @XmlEnumValue("ISCAccepted")
    ISC_ACCEPTED("ISCAccepted"),
    @XmlEnumValue("ISCDifference")
    ISC_DIFFERENCE("ISCDifference"),
    @XmlEnumValue("OtherCommissionAllowed")
    OTHER_COMMISSION_ALLOWED("OtherCommissionAllowed"),
    @XmlEnumValue("OtherCommissionAccepted")
    OTHER_COMMISSION_ACCEPTED("OtherCommissionAccepted"),
    @XmlEnumValue("OtherCommissionDifference")
    OTHER_COMMISSION_DIFFERENCE("OtherCommissionDifference"),
    @XmlEnumValue("UATPAllowed")
    UATP_ALLOWED("UATPAllowed"),
    @XmlEnumValue("UATPAccepted")
    UATP_ACCEPTED("UATPAccepted"),
    @XmlEnumValue("UATPDifference")
    UATP_DIFFERENCE("UATPDifference"),
    @XmlEnumValue("HandlingFeeAllowed")
    HANDLING_FEE_ALLOWED("HandlingFeeAllowed"),
    @XmlEnumValue("HandlingFeeAccepted")
    HANDLING_FEE_ACCEPTED("HandlingFeeAccepted"),
    @XmlEnumValue("HandlingFeeDifference")
    HANDLING_FEE_DIFFERENCE("HandlingFeeDifference");
    private final String value;

    PAXLIDAddOnChargeNameValues(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PAXLIDAddOnChargeNameValues fromValue(String v) {
        for (PAXLIDAddOnChargeNameValues c: PAXLIDAddOnChargeNameValues.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
