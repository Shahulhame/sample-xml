
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartShipmentIndicator.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PartShipmentIndicator">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}A01Base">
 *     &lt;enumeration value="P"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PartShipmentIndicator", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum PartShipmentIndicator {

    P;

    public String value() {
        return name();
    }

    public static PartShipmentIndicator fromValue(String v) {
        return valueOf(v);
    }

}
