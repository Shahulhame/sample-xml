
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OrganizationData-Name-Values.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="OrganizationData-Name-Values">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN30Base">
 *     &lt;enumeration value="CompanyGroup"/>
 *     &lt;enumeration value="UnitPrice"/>
 *     &lt;enumeration value="CurrencyCode"/>
 *     &lt;enumeration value="FromCurrencyCode"/>
 *     &lt;enumeration value="ToCurrencyCode"/>
 *     &lt;enumeration value="ExchangeRate"/>
 *     &lt;enumeration value="ExchangeRateDate"/>
 *     &lt;enumeration value="RequestorID"/>
 *     &lt;enumeration value="CompanyRegisteredIn"/>
 *     &lt;enumeration value="TaxRegisteredIn"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "OrganizationData-Name-Values", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum OrganizationDataNameValues {

    @XmlEnumValue("CompanyGroup")
    COMPANY_GROUP("CompanyGroup"),
    @XmlEnumValue("UnitPrice")
    UNIT_PRICE("UnitPrice"),
    @XmlEnumValue("CurrencyCode")
    CURRENCY_CODE("CurrencyCode"),
    @XmlEnumValue("FromCurrencyCode")
    FROM_CURRENCY_CODE("FromCurrencyCode"),
    @XmlEnumValue("ToCurrencyCode")
    TO_CURRENCY_CODE("ToCurrencyCode"),
    @XmlEnumValue("ExchangeRate")
    EXCHANGE_RATE("ExchangeRate"),
    @XmlEnumValue("ExchangeRateDate")
    EXCHANGE_RATE_DATE("ExchangeRateDate"),
    @XmlEnumValue("RequestorID")
    REQUESTOR_ID("RequestorID"),
    @XmlEnumValue("CompanyRegisteredIn")
    COMPANY_REGISTERED_IN("CompanyRegisteredIn"),
    @XmlEnumValue("TaxRegisteredIn")
    TAX_REGISTERED_IN("TaxRegisteredIn");
    private final String value;

    OrganizationDataNameValues(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static OrganizationDataNameValues fromValue(String v) {
        for (OrganizationDataNameValues c: OrganizationDataNameValues.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
