
package com.sample.app.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxLabel" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxIdentifier" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxableAmount" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxPercent" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxAmount" maxOccurs="3"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxText" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "taxCode",
    "taxLabel",
    "taxIdentifier",
    "taxableAmount",
    "taxPercent",
    "taxAmount",
    "taxText"
})
@XmlRootElement(name = "TaxBreakdown", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class TaxBreakdown {

    @XmlElement(name = "TaxCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String taxCode;
    @XmlElement(name = "TaxLabel", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String taxLabel;
    @XmlElement(name = "TaxIdentifier", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String taxIdentifier;
    @XmlElement(name = "TaxableAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal taxableAmount;
    @XmlElement(name = "TaxPercent", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal taxPercent;
    @XmlElement(name = "TaxAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected List<TaxAmount> taxAmount;
    @XmlElement(name = "TaxText", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String taxText;

    /**
     * Gets the value of the taxCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxCode() {
        return taxCode;
    }

    /**
     * Sets the value of the taxCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxCode(String value) {
        this.taxCode = value;
    }

    /**
     * Gets the value of the taxLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxLabel() {
        return taxLabel;
    }

    /**
     * Sets the value of the taxLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxLabel(String value) {
        this.taxLabel = value;
    }

    /**
     * Gets the value of the taxIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxIdentifier() {
        return taxIdentifier;
    }

    /**
     * Sets the value of the taxIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxIdentifier(String value) {
        this.taxIdentifier = value;
    }

    /**
     * Gets the value of the taxableAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTaxableAmount() {
        return taxableAmount;
    }

    /**
     * Sets the value of the taxableAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTaxableAmount(BigDecimal value) {
        this.taxableAmount = value;
    }

    /**
     * Gets the value of the taxPercent property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTaxPercent() {
        return taxPercent;
    }

    /**
     * Sets the value of the taxPercent property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTaxPercent(BigDecimal value) {
        this.taxPercent = value;
    }

    /**
     * Gets the value of the taxAmount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the taxAmount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTaxAmount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TaxAmount }
     * 
     * 
     */
    public List<TaxAmount> getTaxAmount() {
        if (taxAmount == null) {
            taxAmount = new ArrayList<TaxAmount>();
        }
        return this.taxAmount;
    }

    /**
     * Gets the value of the taxText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxText() {
        return taxText;
    }

    /**
     * Sets the value of the taxText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxText(String value) {
        this.taxText = value;
    }

}
