
package com.sample.app.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="LocationCode" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardMainDictionary>LocationCode">
 *                 &lt;attribute name="Type" use="required" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}LocationCode_XXXX-Type" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="LocationCode_ICAO" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardMainDictionary>LocationCode_ICAO">
 *                 &lt;attribute name="Type" use="required" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}LocationCode_XXXX-Type" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CountryCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CountryCode_ICAO" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SubdivisionCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}WaypointCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}FlightInformationRegion" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Latitude" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Longitude" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}RouteDateTime" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}UTCOffset" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Distance" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DistanceFactor" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DistanceType" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AirspaceCorridorCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}RouteData" maxOccurs="20" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "locationCode",
    "locationCodeICAO",
    "countryCode",
    "countryCodeICAO",
    "subdivisionCode",
    "waypointCode",
    "flightInformationRegion",
    "latitude",
    "longitude",
    "routeDateTime",
    "utcOffset",
    "distance",
    "distanceFactor",
    "distanceType",
    "airspaceCorridorCode",
    "routeData"
})
@XmlRootElement(name = "RouteDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class RouteDetails {

    @XmlElement(name = "LocationCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected RouteDetails.LocationCode locationCode;
    @XmlElement(name = "LocationCode_ICAO", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected RouteDetails.LocationCodeICAO locationCodeICAO;
    @XmlElement(name = "CountryCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String countryCode;
    @XmlElement(name = "CountryCode_ICAO", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String countryCodeICAO;
    @XmlElement(name = "SubdivisionCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String subdivisionCode;
    @XmlElement(name = "WaypointCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected WaypointCode waypointCode;
    @XmlElement(name = "FlightInformationRegion", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String flightInformationRegion;
    @XmlElement(name = "Latitude", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String latitude;
    @XmlElement(name = "Longitude", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String longitude;
    @XmlElement(name = "RouteDateTime", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected RouteDateTime routeDateTime;
    @XmlElement(name = "UTCOffset", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal utcOffset;
    @XmlElement(name = "Distance", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected Distance distance;
    @XmlElement(name = "DistanceFactor", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal distanceFactor;
    @XmlElement(name = "DistanceType", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String distanceType;
    @XmlElement(name = "AirspaceCorridorCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String airspaceCorridorCode;
    @XmlElement(name = "RouteData", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<RouteData> routeData;

    /**
     * Gets the value of the locationCode property.
     * 
     * @return
     *     possible object is
     *     {@link RouteDetails.LocationCode }
     *     
     */
    public RouteDetails.LocationCode getLocationCode() {
        return locationCode;
    }

    /**
     * Sets the value of the locationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteDetails.LocationCode }
     *     
     */
    public void setLocationCode(RouteDetails.LocationCode value) {
        this.locationCode = value;
    }

    /**
     * Gets the value of the locationCodeICAO property.
     * 
     * @return
     *     possible object is
     *     {@link RouteDetails.LocationCodeICAO }
     *     
     */
    public RouteDetails.LocationCodeICAO getLocationCodeICAO() {
        return locationCodeICAO;
    }

    /**
     * Sets the value of the locationCodeICAO property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteDetails.LocationCodeICAO }
     *     
     */
    public void setLocationCodeICAO(RouteDetails.LocationCodeICAO value) {
        this.locationCodeICAO = value;
    }

    /**
     * Gets the value of the countryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * Sets the value of the countryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryCode(String value) {
        this.countryCode = value;
    }

    /**
     * CountryCode_ICAO
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryCodeICAO() {
        return countryCodeICAO;
    }

    /**
     * Sets the value of the countryCodeICAO property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryCodeICAO(String value) {
        this.countryCodeICAO = value;
    }

    /**
     * Gets the value of the subdivisionCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubdivisionCode() {
        return subdivisionCode;
    }

    /**
     * Sets the value of the subdivisionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubdivisionCode(String value) {
        this.subdivisionCode = value;
    }

    /**
     * Gets the value of the waypointCode property.
     * 
     * @return
     *     possible object is
     *     {@link WaypointCode }
     *     
     */
    public WaypointCode getWaypointCode() {
        return waypointCode;
    }

    /**
     * Sets the value of the waypointCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link WaypointCode }
     *     
     */
    public void setWaypointCode(WaypointCode value) {
        this.waypointCode = value;
    }

    /**
     * Gets the value of the flightInformationRegion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlightInformationRegion() {
        return flightInformationRegion;
    }

    /**
     * Sets the value of the flightInformationRegion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlightInformationRegion(String value) {
        this.flightInformationRegion = value;
    }

    /**
     * Gets the value of the latitude property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLatitude() {
        return latitude;
    }

    /**
     * Sets the value of the latitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLatitude(String value) {
        this.latitude = value;
    }

    /**
     * Gets the value of the longitude property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLongitude() {
        return longitude;
    }

    /**
     * Sets the value of the longitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLongitude(String value) {
        this.longitude = value;
    }

    /**
     * Gets the value of the routeDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link RouteDateTime }
     *     
     */
    public RouteDateTime getRouteDateTime() {
        return routeDateTime;
    }

    /**
     * Sets the value of the routeDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteDateTime }
     *     
     */
    public void setRouteDateTime(RouteDateTime value) {
        this.routeDateTime = value;
    }

    /**
     * Gets the value of the utcOffset property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getUTCOffset() {
        return utcOffset;
    }

    /**
     * Sets the value of the utcOffset property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setUTCOffset(BigDecimal value) {
        this.utcOffset = value;
    }

    /**
     * Gets the value of the distance property.
     * 
     * @return
     *     possible object is
     *     {@link Distance }
     *     
     */
    public Distance getDistance() {
        return distance;
    }

    /**
     * Sets the value of the distance property.
     * 
     * @param value
     *     allowed object is
     *     {@link Distance }
     *     
     */
    public void setDistance(Distance value) {
        this.distance = value;
    }

    /**
     * Gets the value of the distanceFactor property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDistanceFactor() {
        return distanceFactor;
    }

    /**
     * Sets the value of the distanceFactor property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDistanceFactor(BigDecimal value) {
        this.distanceFactor = value;
    }

    /**
     * Gets the value of the distanceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistanceType() {
        return distanceType;
    }

    /**
     * Sets the value of the distanceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistanceType(String value) {
        this.distanceType = value;
    }

    /**
     * Gets the value of the airspaceCorridorCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAirspaceCorridorCode() {
        return airspaceCorridorCode;
    }

    /**
     * Sets the value of the airspaceCorridorCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAirspaceCorridorCode(String value) {
        this.airspaceCorridorCode = value;
    }

    /**
     * Gets the value of the routeData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the routeData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRouteData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RouteData }
     * 
     * 
     */
    public List<RouteData> getRouteData() {
        if (routeData == null) {
            routeData = new ArrayList<RouteData>();
        }
        return this.routeData;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardMainDictionary>LocationCode">
     *       &lt;attribute name="Type" use="required" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}LocationCode_XXXX-Type" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class LocationCode {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Type", required = true)
        protected String type;

        /**
         * Description: Identifies an airport or other place where goods or services were provided.  The 3 character IATA 'location identifier' should be used for an airport, but for places not coded by IATA then the 5 character 'UN/LOCODE' may be used instead
         *         Definition: Based on Standards AirportCode from IATA or UN/LOCODE. The IATA airport code, defined by the International Air Transport Association and known as the 'location identifier' is a three-character code designating airports (plus some bus, rail or ferry locations) around the world.  The code is typically a recognisable abbreviation from the airport name.  IATA airport codes are published tri-annually in the IATA Airline Coding Directory.United Nations 'LOCODE' (UN/LOCODE) - Codes for Ports and other locations.  A UN/LOCODE starts with an ISO 3166 alpha-2 Country Code followed by 3-characters for the place name.  When interpreting location code values found outside of the code list in part 2 of the UN/LOCODE Manual, it is understood that: when a three-letter code is used alone to indicate a location, it designates the name of an airport or location as adopted by IATA (whose code only has three letters); whereas a three letter code preceded by a two-letter country code designates the name for a location as adopted within the UN/LOCODE and might depict a different location from that of the IATA code,, e.g. PAR = IATA code for Paris, France (UN/LOCODE = FRPAR); GBPAR = UN/LOCODE for Par, United Kingdom."
         *         URL: http://www.iata.org/whatwedo/aircraft_operations/coding/index.htm
         *         URL: http://www.unece.org/cefact/codesfortrade/codes_index.htm
         *         ExampleXML: 
         * <pre>
         * &lt;?xml version="1.0" encoding="UTF-8"?&gt;&lt;LocationCode xmlns:Base_Datatypes="http://www.IATA.com/IATAAviationStandardDataTypes" xmlns:Custom_Dictionary="http://www.IATA.com/IATAAviationStandardCustomDictionary" xmlns:Main_Dictionary="http://www.IATA.com/IATAAviationStandardMainDictionary" xmlns:xs="http://www.w3.org/2001/XMLSchema"&gt;JFK&lt;/LocationCode&gt;
         * </pre>
         * 
         *         Size: 3 or 5 chars	IATA (airport) location identifiers are 3 characters.  UN/LOCODE codes (for non-airports) are 5 characters
         *         Format: [XX]XXX
         *         CodeExample: JFK	John F. Kennedy Apt/New York (IATA location identifier)
         *         CodeExample: LHR	Heathrow Apt/London (IATA location identifier)
         *         CodeExample: FRLHR	Les Hautes-Rivi�res, France (UN/LOCODE)
         *         Alternate: LocationCode_ICAO	ICAO 4-letter 'Airport Code'
         *       
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the type property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getType() {
            return type;
        }

        /**
         * Sets the value of the type property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setType(String value) {
            this.type = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardMainDictionary>LocationCode_ICAO">
     *       &lt;attribute name="Type" use="required" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}LocationCode_XXXX-Type" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class LocationCodeICAO {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Type", required = true)
        protected String type;

        /**
         * Description: Identifies an airport where goods or services where provided.  This is an alternative code to the IATA airport 'location identifier' code.
         *         Definition: Based on Standard ICAO AirportCode. The ICAO 'Airport code', defined by the International Civil Aviation Organization, is a four-letter alphanumeric code designating each airport around the world, principally for use in relation to air traffic control.  The code has a geographical structure in that the first one or first two characters identify the country or continent and country within it.  In the continental USA, codes normally start with 'K' followed by the 3-letter IATA 'location identifier', but elsewhere there is no direct correlation to the IATA code.
         *         URL:	http://icaodsu.openface.ca/documentItemView.ch2?ID=9038
         *         ExampleXML: 
         * <pre>
         * &lt;?xml version="1.0" encoding="UTF-8"?&gt;&lt;LocationCode_ICAO xmlns:Base_Datatypes="http://www.IATA.com/IATAAviationStandardDataTypes" xmlns:Custom_Dictionary="http://www.IATA.com/IATAAviationStandardCustomDictionary" xmlns:Main_Dictionary="http://www.IATA.com/IATAAviationStandardMainDictionary" xmlns:xs="http://www.w3.org/2001/XMLSchema"&gt;KJFK&lt;/LocationCode_ICAO&gt;
         * </pre>
         * 
         *         CodeExample: KJFK	John F. Kennedy Apt/New York
         *         CodeExample: EGLL	Heathrow Apt/London
         *         Alternate: LocationCode
         *       
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the type property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getType() {
            return type;
        }

        /**
         * Sets the value of the type property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setType(String value) {
            this.type = value;
        }

    }

}
