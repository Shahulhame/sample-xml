package com.sample.app.repository.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.transaction.Transactional;

@Entity
@Table(name = "misc_billing_inv_trans_summary")
@NamedQuery(name = "MiscBillingInvTransSummary.findAll", query = "SELECT m FROM MiscBillingInvTransSummary m")
public class MiscBillingInvTransSummary extends BaseEntity implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "trans_summary_autoid",nullable = false)
	private int transmissionSummaryAutoId;

	@ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	@JoinColumn(name = "trans_hdr_autoid",referencedColumnName = "trans_hdr_autoid",nullable = false,updatable = false, insertable = false)
	private TransmissionHeaderEntity miscBillingInvTransHeader;

	@Column(name = "invoice_count", nullable = false)
	private int invoiceCount;

	@Column(name = "attachment_count")
	private int attachmentCount;

	public MiscBillingInvTransSummary() {
	}

	public int getTransmissionSummaryAutoId() {
		return transmissionSummaryAutoId;
	}

	public void setTransmissionSummaryAutoId(int transmissionSummaryAutoId) {
		this.transmissionSummaryAutoId = transmissionSummaryAutoId;
	}

	public TransmissionHeaderEntity getMiscBillingInvTransHeader() {
		return miscBillingInvTransHeader;
	}

	public void setMiscBillingInvTransHeader(TransmissionHeaderEntity miscBillingInvTransHeader) {
		this.miscBillingInvTransHeader = miscBillingInvTransHeader;
	}

	public int getInvoiceCount() {
		return invoiceCount;
	}

	public void setInvoiceCount(int invoiceCount) {
		this.invoiceCount = invoiceCount;
	}

	public int getAttachmentCount() {
		return attachmentCount;
	}

	public void setAttachmentCount(int attachmentCount) {
		this.attachmentCount = attachmentCount;
	}

	
}
