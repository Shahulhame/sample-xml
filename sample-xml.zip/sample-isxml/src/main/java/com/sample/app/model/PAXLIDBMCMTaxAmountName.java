
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PAX-LID-BMCM-TaxAmount-Name.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PAX-LID-BMCM-TaxAmount-Name">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="Billed"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PAX-LID-BMCM-TaxAmount-Name", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum PAXLIDBMCMTaxAmountName {

    @XmlEnumValue("Billed")
    BILLED("Billed");
    private final String value;

    PAXLIDBMCMTaxAmountName(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PAXLIDBMCMTaxAmountName fromValue(String v) {
        for (PAXLIDBMCMTaxAmountName c: PAXLIDBMCMTaxAmountName.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
