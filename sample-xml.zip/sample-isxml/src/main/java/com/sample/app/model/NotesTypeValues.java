
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Notes-Type-Values.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="Notes-Type-Values">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="Affiliate"/>
 *     &lt;enumeration value="Tax"/>
 *     &lt;enumeration value="PaymentTerms"/>
 *     &lt;enumeration value="Claims"/>
 *     &lt;enumeration value="RemitTo"/>
 *     &lt;enumeration value="TransactionType"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "Notes-Type-Values", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum NotesTypeValues {

    @XmlEnumValue("Affiliate")
    AFFILIATE("Affiliate"),
    @XmlEnumValue("Tax")
    TAX("Tax"),
    @XmlEnumValue("PaymentTerms")
    PAYMENT_TERMS("PaymentTerms"),
    @XmlEnumValue("Claims")
    CLAIMS("Claims"),
    @XmlEnumValue("RemitTo")
    REMIT_TO("RemitTo"),
    @XmlEnumValue("TransactionType")
    TRANSACTION_TYPE("TransactionType");
    private final String value;

    NotesTypeValues(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static NotesTypeValues fromValue(String v) {
        for (NotesTypeValues c: NotesTypeValues.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
