
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TaxIdentifierPAX.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TaxIdentifierPAX">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN02Base">
 *     &lt;enumeration value="GF"/>
 *     &lt;enumeration value="TA"/>
 *     &lt;enumeration value="IS"/>
 *     &lt;enumeration value="OC"/>
 *     &lt;enumeration value="UA"/>
 *     &lt;enumeration value="HF"/>
 *     &lt;enumeration value="OT"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TaxIdentifierPAX", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum TaxIdentifierPAX {

    GF,
    TA,
    IS,
    OC,
    UA,
    HF,
    OT;

    public String value() {
        return name();
    }

    public static TaxIdentifierPAX fromValue(String v) {
        return valueOf(v);
    }

}
