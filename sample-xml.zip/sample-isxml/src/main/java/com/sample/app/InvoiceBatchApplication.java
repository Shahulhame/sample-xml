package com.sample.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableDiscoveryClient
//@EnableCircuitBreaker
//@EnableSwagger
public class InvoiceBatchApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(InvoiceBatchApplication.class, args);
	}
}