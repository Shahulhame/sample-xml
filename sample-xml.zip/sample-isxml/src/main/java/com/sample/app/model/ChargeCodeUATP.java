
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ChargeCodeUATP.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ChargeCodeUATP">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="ATCAN"/>
 *     &lt;enumeration value="Chargeback"/>
 *     &lt;enumeration value="Fees"/>
 *     &lt;enumeration value="Misc"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ChargeCodeUATP", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum ChargeCodeUATP {

    ATCAN("ATCAN"),
    @XmlEnumValue("Chargeback")
    CHARGEBACK("Chargeback"),
    @XmlEnumValue("Fees")
    FEES("Fees"),
    @XmlEnumValue("Misc")
    MISC("Misc");
    private final String value;

    ChargeCodeUATP(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ChargeCodeUATP fromValue(String v) {
        for (ChargeCodeUATP c: ChargeCodeUATP.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
