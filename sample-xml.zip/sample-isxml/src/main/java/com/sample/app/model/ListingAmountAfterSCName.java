
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListingAmountAfterSC-Name.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ListingAmountAfterSC-Name">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="Gross"/>
 *     &lt;enumeration value="ISC"/>
 *     &lt;enumeration value="OtherCommission"/>
 *     &lt;enumeration value="UATP"/>
 *     &lt;enumeration value="HandlingFee"/>
 *     &lt;enumeration value="Tax"/>
 *     &lt;enumeration value="VAT"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ListingAmountAfterSC-Name", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum ListingAmountAfterSCName {

    @XmlEnumValue("Gross")
    GROSS("Gross"),
    ISC("ISC"),
    @XmlEnumValue("OtherCommission")
    OTHER_COMMISSION("OtherCommission"),
    UATP("UATP"),
    @XmlEnumValue("HandlingFee")
    HANDLING_FEE("HandlingFee"),
    @XmlEnumValue("Tax")
    TAX("Tax"),
    VAT("VAT");
    private final String value;

    ListingAmountAfterSCName(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ListingAmountAfterSCName fromValue(String v) {
        for (ListingAmountAfterSCName c: ListingAmountAfterSCName.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
