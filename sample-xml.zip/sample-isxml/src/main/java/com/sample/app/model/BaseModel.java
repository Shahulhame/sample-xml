package com.sample.app.model;

import java.io.Serializable;

import javax.persistence.MappedSuperclass;

import org.springframework.batch.item.ItemProcessor;

import com.sample.app.repository.entity.BaseEntity;

@MappedSuperclass
public abstract class BaseModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public abstract ItemProcessor<? extends BaseModel, ? extends BaseEntity> processor();

}
