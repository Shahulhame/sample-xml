
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TaxIdentifierCargo.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TaxIdentifierCargo">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN02Base">
 *     &lt;enumeration value="WC"/>
 *     &lt;enumeration value="VA"/>
 *     &lt;enumeration value="IS"/>
 *     &lt;enumeration value="OC"/>
 *     &lt;enumeration value="OT"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TaxIdentifierCargo", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum TaxIdentifierCargo {

    WC,
    VA,
    IS,
    OC,
    OT;

    public String value() {
        return name();
    }

    public static TaxIdentifierCargo fromValue(String v) {
        return valueOf(v);
    }

}
