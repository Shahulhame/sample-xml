
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TaxData-Name-Values.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TaxData-Name-Values">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN30Base">
 *     &lt;enumeration value="TaxCode"/>
 *     &lt;enumeration value="TaxRegisteredIn"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TaxData-Name-Values", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum TaxDataNameValues {

    @XmlEnumValue("TaxCode")
    TAX_CODE("TaxCode"),
    @XmlEnumValue("TaxRegisteredIn")
    TAX_REGISTERED_IN("TaxRegisteredIn");
    private final String value;

    TaxDataNameValues(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TaxDataNameValues fromValue(String v) {
        for (TaxDataNameValues c: TaxDataNameValues.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
