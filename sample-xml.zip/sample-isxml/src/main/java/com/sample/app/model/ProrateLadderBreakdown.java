
package com.sample.app.model;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CurrencyOfProrateCalculation" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TotalAmount" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}FromSector" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ToSector" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CarrierPrefix" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisoReqSPAFlag" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProrateFactor" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PercentShare" minOccurs="0"/>
 *         &lt;element name="Amount" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "currencyOfProrateCalculation",
    "totalAmount",
    "fromSector",
    "toSector",
    "carrierPrefix",
    "provisoReqSPAFlag",
    "prorateFactor",
    "percentShare",
    "amount"
})
@XmlRootElement(name = "ProrateLadderBreakdown", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class ProrateLadderBreakdown {

    @XmlElement(name = "CurrencyOfProrateCalculation", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String currencyOfProrateCalculation;
    @XmlElement(name = "TotalAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected TotalAmount totalAmount;
    @XmlElement(name = "FromSector", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String fromSector;
    @XmlElement(name = "ToSector", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String toSector;
    @XmlElement(name = "CarrierPrefix", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String carrierPrefix;
    @XmlElement(name = "ProvisoReqSPAFlag", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected ProvisoReqSPA provisoReqSPAFlag;
    @XmlElement(name = "ProrateFactor", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger prorateFactor;
    @XmlElement(name = "PercentShare", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal percentShare;
    @XmlElement(name = "Amount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal amount;

    /**
     * Gets the value of the currencyOfProrateCalculation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyOfProrateCalculation() {
        return currencyOfProrateCalculation;
    }

    /**
     * Sets the value of the currencyOfProrateCalculation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyOfProrateCalculation(String value) {
        this.currencyOfProrateCalculation = value;
    }

    /**
     * Gets the value of the totalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link TotalAmount }
     *     
     */
    public TotalAmount getTotalAmount() {
        return totalAmount;
    }

    /**
     * Sets the value of the totalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link TotalAmount }
     *     
     */
    public void setTotalAmount(TotalAmount value) {
        this.totalAmount = value;
    }

    /**
     * Gets the value of the fromSector property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFromSector() {
        return fromSector;
    }

    /**
     * Sets the value of the fromSector property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFromSector(String value) {
        this.fromSector = value;
    }

    /**
     * Gets the value of the toSector property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToSector() {
        return toSector;
    }

    /**
     * Sets the value of the toSector property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToSector(String value) {
        this.toSector = value;
    }

    /**
     * Gets the value of the carrierPrefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCarrierPrefix() {
        return carrierPrefix;
    }

    /**
     * Sets the value of the carrierPrefix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCarrierPrefix(String value) {
        this.carrierPrefix = value;
    }

    /**
     * Gets the value of the provisoReqSPAFlag property.
     * 
     * @return
     *     possible object is
     *     {@link ProvisoReqSPA }
     *     
     */
    public ProvisoReqSPA getProvisoReqSPAFlag() {
        return provisoReqSPAFlag;
    }

    /**
     * Sets the value of the provisoReqSPAFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProvisoReqSPA }
     *     
     */
    public void setProvisoReqSPAFlag(ProvisoReqSPA value) {
        this.provisoReqSPAFlag = value;
    }

    /**
     * Gets the value of the prorateFactor property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getProrateFactor() {
        return prorateFactor;
    }

    /**
     * Sets the value of the prorateFactor property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setProrateFactor(BigInteger value) {
        this.prorateFactor = value;
    }

    /**
     * Gets the value of the percentShare property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPercentShare() {
        return percentShare;
    }

    /**
     * Sets the value of the percentShare property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPercentShare(BigDecimal value) {
        this.percentShare = value;
    }

    /**
     * Gets the value of the amount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAmount(BigDecimal value) {
        this.amount = value;
    }

}
