
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AbsorptionName.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AbsorptionName">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="FareAbsorption"/>
 *     &lt;enumeration value="ISCAbsorption"/>
 *     &lt;enumeration value="TaxAbsorption"/>
 *     &lt;enumeration value="UATPAbsorption"/>
 *     &lt;enumeration value="HandlingFeeAbsorption"/>
 *     &lt;enumeration value="OtherCommissionAbsorption"/>
 *     &lt;enumeration value="VATAbsorption"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "AbsorptionName", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum AbsorptionName {

    @XmlEnumValue("FareAbsorption")
    FARE_ABSORPTION("FareAbsorption"),
    @XmlEnumValue("ISCAbsorption")
    ISC_ABSORPTION("ISCAbsorption"),
    @XmlEnumValue("TaxAbsorption")
    TAX_ABSORPTION("TaxAbsorption"),
    @XmlEnumValue("UATPAbsorption")
    UATP_ABSORPTION("UATPAbsorption"),
    @XmlEnumValue("HandlingFeeAbsorption")
    HANDLING_FEE_ABSORPTION("HandlingFeeAbsorption"),
    @XmlEnumValue("OtherCommissionAbsorption")
    OTHER_COMMISSION_ABSORPTION("OtherCommissionAbsorption"),
    @XmlEnumValue("VATAbsorption")
    VAT_ABSORPTION("VATAbsorption");
    private final String value;

    AbsorptionName(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AbsorptionName fromValue(String v) {
        for (AbsorptionName c: AbsorptionName.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
