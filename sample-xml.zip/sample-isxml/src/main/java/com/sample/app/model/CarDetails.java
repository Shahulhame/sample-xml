
package com.sample.app.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CarCategory" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>AN04Base">
 *                 &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardDataTypes}A025Base" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CarType" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>AN04Base">
 *                 &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardDataTypes}A025Base" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CarTransmission" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>AN04Base">
 *                 &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardDataTypes}A025Base" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CarAirFuelCondition" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>AN04Base">
 *                 &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardDataTypes}A025Base" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "carCategory",
    "carType",
    "carTransmission",
    "carAirFuelCondition"
})
@XmlRootElement(name = "CarDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class CarDetails {

    @XmlElement(name = "CarCategory", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected CarDetails.CarCategory carCategory;
    @XmlElement(name = "CarType", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected CarDetails.CarType carType;
    @XmlElement(name = "CarTransmission", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected CarDetails.CarTransmission carTransmission;
    @XmlElement(name = "CarAirFuelCondition", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected CarDetails.CarAirFuelCondition carAirFuelCondition;

    /**
     * Gets the value of the carCategory property.
     * 
     * @return
     *     possible object is
     *     {@link CarDetails.CarCategory }
     *     
     */
    public CarDetails.CarCategory getCarCategory() {
        return carCategory;
    }

    /**
     * Sets the value of the carCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link CarDetails.CarCategory }
     *     
     */
    public void setCarCategory(CarDetails.CarCategory value) {
        this.carCategory = value;
    }

    /**
     * Gets the value of the carType property.
     * 
     * @return
     *     possible object is
     *     {@link CarDetails.CarType }
     *     
     */
    public CarDetails.CarType getCarType() {
        return carType;
    }

    /**
     * Sets the value of the carType property.
     * 
     * @param value
     *     allowed object is
     *     {@link CarDetails.CarType }
     *     
     */
    public void setCarType(CarDetails.CarType value) {
        this.carType = value;
    }

    /**
     * Gets the value of the carTransmission property.
     * 
     * @return
     *     possible object is
     *     {@link CarDetails.CarTransmission }
     *     
     */
    public CarDetails.CarTransmission getCarTransmission() {
        return carTransmission;
    }

    /**
     * Sets the value of the carTransmission property.
     * 
     * @param value
     *     allowed object is
     *     {@link CarDetails.CarTransmission }
     *     
     */
    public void setCarTransmission(CarDetails.CarTransmission value) {
        this.carTransmission = value;
    }

    /**
     * Gets the value of the carAirFuelCondition property.
     * 
     * @return
     *     possible object is
     *     {@link CarDetails.CarAirFuelCondition }
     *     
     */
    public CarDetails.CarAirFuelCondition getCarAirFuelCondition() {
        return carAirFuelCondition;
    }

    /**
     * Sets the value of the carAirFuelCondition property.
     * 
     * @param value
     *     allowed object is
     *     {@link CarDetails.CarAirFuelCondition }
     *     
     */
    public void setCarAirFuelCondition(CarDetails.CarAirFuelCondition value) {
        this.carAirFuelCondition = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>AN04Base">
     *       &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardDataTypes}A025Base" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class CarAirFuelCondition {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Name")
        protected String name;

        /**
         * Base type for string min1 max4
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setName(String value) {
            this.name = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>AN04Base">
     *       &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardDataTypes}A025Base" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class CarCategory {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Name")
        protected String name;

        /**
         * Base type for string min1 max4
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setName(String value) {
            this.name = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>AN04Base">
     *       &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardDataTypes}A025Base" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class CarTransmission {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Name")
        protected String name;

        /**
         * Base type for string min1 max4
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setName(String value) {
            this.name = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>AN04Base">
     *       &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardDataTypes}A025Base" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class CarType {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Name")
        protected String name;

        /**
         * Base type for string min1 max4
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setName(String value) {
            this.name = value;
        }

    }

}
