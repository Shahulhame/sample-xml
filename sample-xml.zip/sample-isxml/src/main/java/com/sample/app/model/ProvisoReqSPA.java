
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProvisoReqSPA.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ProvisoReqSPA">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}A01Base">
 *     &lt;enumeration value="P"/>
 *     &lt;enumeration value="R"/>
 *     &lt;enumeration value="S"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ProvisoReqSPA", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum ProvisoReqSPA {

    P,
    R,
    S;

    public String value() {
        return name();
    }

    public static ProvisoReqSPA fromValue(String v) {
        return valueOf(v);
    }

}
