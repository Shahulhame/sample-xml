
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BillingCode.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="BillingCode">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN01Base">
 *     &lt;enumeration value="P"/>
 *     &lt;enumeration value="C"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "BillingCode", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum BillingCode {

    P,
    C;

    public String value() {
        return name();
    }

    public static BillingCode fromValue(String v) {
        return valueOf(v);
    }

}
