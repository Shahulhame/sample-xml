
package com.sample.app.model;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.sgl.smartpra.batch.iata.invoice.app.domain package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _TicketOrFIMIssuingAirline_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TicketOrFIMIssuingAirline");
    private final static QName _DeskLocationName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DeskLocationName");
    private final static QName _AddressLine3_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AddressLine3");
    private final static QName _RecordSequenceWithinBatch_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "RecordSequenceWithinBatch");
    private final static QName _AddressLine2_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AddressLine2");
    private final static QName _AddressLine1_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AddressLine1");
    private final static QName _AbsorptionPercentage_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AbsorptionPercentage");
    private final static QName _YourInvoiceBillingDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "YourInvoiceBillingDate");
    private final static QName _LocationCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "LocationCode");
    private final static QName _NumberofBags_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "NumberofBags");
    private final static QName _ProrateFactor_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProrateFactor");
    private final static QName _SettlementAuthorizationCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "SettlementAuthorizationCode");
    private final static QName _IBAN_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "IBAN");
    private final static QName _PartNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "PartNo");
    private final static QName _BoardFlightDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "BoardFlightDate");
    private final static QName _InvoiceNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "InvoiceNumber");
    private final static QName _AreaLocationName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AreaLocationName");
    private final static QName _MemberCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "MemberCode");
    private final static QName _ISValidationFlag_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ISValidationFlag");
    private final static QName _FlightDateTime_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "FlightDateTime");
    private final static QName _MailNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "MailNo");
    private final static QName _DaysOverdue_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DaysOverdue");
    private final static QName _LocationID_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "LocationID");
    private final static QName _AdditionalTaxRegistrationID_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AdditionalTaxRegistrationID");
    private final static QName _AreaType_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AreaType");
    private final static QName _SurchargeAmount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "SurchargeAmount");
    private final static QName _RejectionStage_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "RejectionStage");
    private final static QName _PONumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "PONumber");
    private final static QName _OriginalInvoiceDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "OriginalInvoiceDate");
    private final static QName _SubdivisionName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "SubdivisionName");
    private final static QName _ReceivingOrganizationID_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ReceivingOrganizationID");
    private final static QName _RejectionMemoNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "RejectionMemoNumber");
    private final static QName _MailCategory_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "MailCategory");
    private final static QName _CarrierPrefix_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CarrierPrefix");
    private final static QName _MinimumQuantityFlag_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "MinimumQuantityFlag");
    private final static QName _TotalFormBAmount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TotalFormBAmount");
    private final static QName _ValidatedPMI_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ValidatedPMI");
    private final static QName _Facility_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "Facility");
    private final static QName _ContactName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ContactName");
    private final static QName _DeskType_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DeskType");
    private final static QName _NetAmountDueInListingCurrency_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "NetAmountDueInListingCurrency");
    private final static QName _ConsignmentNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ConsignmentNo");
    private final static QName _OnStandDateTime_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "OnStandDateTime");
    private final static QName _CHAgreementIndicator_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CHAgreementIndicator");
    private final static QName _OrganizationDesignator_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "OrganizationDesignator");
    private final static QName _BankCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "BankCode");
    private final static QName _FromAirportCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "FromAirportCode");
    private final static QName _ProvisoReqSPA_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProvisoReqSPA");
    private final static QName _AttachmentIndicatorValidated_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AttachmentIndicatorValidated");
    private final static QName _LinkedFIMBillingCreditMemoNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "LinkedFIMBillingCreditMemoNumber");
    private final static QName _AttachmentCount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AttachmentCount");
    private final static QName _ChargeBasis_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ChargeBasis");
    private final static QName _TotalNetRejectAfterSC_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TotalNetRejectAfterSC");
    private final static QName _TaxableAmount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TaxableAmount");
    private final static QName _Amount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "Amount");
    private final static QName _MealCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "MealCode");
    private final static QName _TicketNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TicketNo");
    private final static QName _TypeOfWeight_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TypeOfWeight");
    private final static QName _PaymentTermsType_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "PaymentTermsType");
    private final static QName _InterestRate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "InterestRate");
    private final static QName _TotalAmountWithoutVAT_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TotalAmountWithoutVAT");
    private final static QName _AddOnChargeAmount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AddOnChargeAmount");
    private final static QName _FromAirportOfCoupon_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "FromAirportOfCoupon");
    private final static QName _TicketIssuingAirline_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TicketIssuingAirline");
    private final static QName _TotalProvisionalAdjustmentAmount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TotalProvisionalAdjustmentAmount");
    private final static QName _NumberOfBillingRecord_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "NumberOfBillingRecord");
    private final static QName _FromSector_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "FromSector");
    private final static QName _SWIFT_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "SWIFT");
    private final static QName _CheckDigit_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CheckDigit");
    private final static QName _TotalProvisionalAdjustmentRate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TotalProvisionalAdjustmentRate");
    private final static QName _InvoiceRefNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "InvoiceRefNumber");
    private final static QName _Description_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "Description");
    private final static QName _NumericCustomerCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "NumericCustomerCode");
    private final static QName _ElectronicTicketIndicator_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ElectronicTicketIndicator");
    private final static QName _TicketDocOrFIMNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TicketDocOrFIMNumber");
    private final static QName _ServiceFlightNbr_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ServiceFlightNbr");
    private final static QName _BranchCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "BranchCode");
    private final static QName _BillingMemoNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "BillingMemoNumber");
    private final static QName _FileSize_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "FileSize");
    private final static QName _ChargeCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ChargeCode");
    private final static QName _TicketOrFIMCouponNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TicketOrFIMCouponNumber");
    private final static QName _ISRejectionFlag_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ISRejectionFlag");
    private final static QName _RejectionFlag_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "RejectionFlag");
    private final static QName _SignedForAmount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "SignedForAmount");
    private final static QName _CurrencyOfProrateCalculation_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CurrencyOfProrateCalculation");
    private final static QName _Recipient_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "Recipient");
    private final static QName _CityName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CityName");
    private final static QName _ReasonCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ReasonCode");
    private final static QName _SubdivisionCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "SubdivisionCode");
    private final static QName _AircraftTypeCodeICAO_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AircraftTypeCode_ICAO");
    private final static QName _ActivityDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ActivityDate");
    private final static QName _AddOnChargeableAmount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AddOnChargeableAmount");
    private final static QName _ClearancePeriod_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ClearancePeriod");
    private final static QName _TotalAddOnChargeAmount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TotalAddOnChargeAmount");
    private final static QName _AircraftTypeCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AircraftTypeCode");
    private final static QName _EngineNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "EngineNo");
    private final static QName _PassIssueDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "PassIssueDate");
    private final static QName _StartDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "StartDate");
    private final static QName _ProvisionalGrossALFAmount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProvisionalGrossALFAmount");
    private final static QName _CompanyRegistrationID_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CompanyRegistrationID");
    private final static QName _ReferenceField20AN_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ReferenceField20AN");
    private final static QName _EndReading_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "EndReading");
    private final static QName _NoiseClass_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "NoiseClass");
    private final static QName _ProductName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProductName");
    private final static QName _ReasonDescription_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ReasonDescription");
    private final static QName _ProvisionalBillingPeriodNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProvisionalBillingPeriodNo");
    private final static QName _EndEstimate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "EndEstimate");
    private final static QName _StaffForename_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "StaffForename");
    private final static QName _KgLbIndicator_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "KgLbIndicator");
    private final static QName _StartDateTime_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "StartDateTime");
    private final static QName _ReferenceField10AN_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ReferenceField10AN");
    private final static QName _DistanceFactor_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DistanceFactor");
    private final static QName _AreaID_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AreaID");
    private final static QName _StartEstimate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "StartEstimate");
    private final static QName _ProrateSlipBreakdown_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProrateSlipBreakdown");
    private final static QName _DateBasis_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DateBasis");
    private final static QName _OrganizationType_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "OrganizationType");
    private final static QName _InvoiceDbsDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "InvoiceDbsDate");
    private final static QName _InvoiceType_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "InvoiceType");
    private final static QName _IssueDescription_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "IssueDescription");
    private final static QName _ProvisionalInvoiceBillingAmount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProvisionalInvoiceBillingAmount");
    private final static QName _NumberOfAttachments_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "NumberOfAttachments");
    private final static QName _NFPReasonCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "NFPReasonCode");
    private final static QName _TicketOrFIMCouponNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TicketOrFIMCouponNo");
    private final static QName _CountryCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CountryCode");
    private final static QName _DueDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DueDate");
    private final static QName _MeterLocationName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "MeterLocationName");
    private final static QName _DueDateFlag_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DueDateFlag");
    private final static QName _InvoiceOpCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "InvoiceOpCode");
    private final static QName _TaxCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TaxCode");
    private final static QName _EndDateTime_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "EndDateTime");
    private final static QName _AircraftRegistrationNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AircraftRegistrationNo");
    private final static QName _PostalCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "PostalCode");
    private final static QName _NetDueDays_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "NetDueDays");
    private final static QName _ContainerNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ContainerNo");
    private final static QName _ProvisoReqSPAFlag_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProvisoReqSPAFlag");
    private final static QName _AgreementNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AgreementNo");
    private final static QName _FlightNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "FlightNo");
    private final static QName _AttachmentID_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AttachmentID");
    private final static QName _PoolNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "PoolNo");
    private final static QName _PassNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "PassNo");
    private final static QName _DetailNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DetailNumber");
    private final static QName _SamplingConstant_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "SamplingConstant");
    private final static QName _StaffID_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "StaffID");
    private final static QName _LinkedFIMNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "LinkedFIMNumber");
    private final static QName _StartReading_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "StartReading");
    private final static QName _CountryCodeICAO_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CountryCode_ICAO");
    private final static QName _AircraftTypeName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AircraftTypeName");
    private final static QName _NoOfBillingRecords_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "NoOfBillingRecords");
    private final static QName _ContactValue_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ContactValue");
    private final static QName _LocationCodeICAO_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "LocationCode_ICAO");
    private final static QName _RejectedCommissions_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "RejectedCommissions");
    private final static QName _TotalAmountInClearanceCurrency_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TotalAmountInClearanceCurrency");
    private final static QName _AbsorptionName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AbsorptionName");
    private final static QName _PassExpiryDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "PassExpiryDate");
    private final static QName _AuthorityToBillFlag_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AuthorityToBillFlag");
    private final static QName _StaffSurname_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "StaffSurname");
    private final static QName _StandNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "StandNo");
    private final static QName _AWBDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AWBDate");
    private final static QName _ProvisionalListingToBillingRate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProvisionalListingToBillingRate");
    private final static QName _CorrespondenceFlag_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CorrespondenceFlag");
    private final static QName _AddOnChargePercentage_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AddOnChargePercentage");
    private final static QName _TransmissionDateTime_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TransmissionDateTime");
    private final static QName _AgreementIndicatorValidated_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AgreementIndicatorValidated");
    private final static QName _CorrespondenceRefNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CorrespondenceRefNumber");
    private final static QName _Longitude_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "Longitude");
    private final static QName _StaffName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "StaffName");
    private final static QName _CCAIndicator_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CCAIndicator");
    private final static QName _TicketDocNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TicketDocNumber");
    private final static QName _PartShipmentIndicator_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "PartShipmentIndicator");
    private final static QName _BoardFlightNbr_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "BoardFlightNbr");
    private final static QName _ChargeCategory_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ChargeCategory");
    private final static QName _ProvisionalInvoiceDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProvisionalInvoiceDate");
    private final static QName _TaxPointDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TaxPointDate");
    private final static QName _AWBIssuingAirline_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AWBIssuingAirline");
    private final static QName _EngineType_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "EngineType");
    private final static QName _DiscountPercent_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DiscountPercent");
    private final static QName _CurrencyCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CurrencyCode");
    private final static QName _InvoiceCount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "InvoiceCount");
    private final static QName _NetAmount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "NetAmount");
    private final static QName _HandlingFeeType_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "HandlingFeeType");
    private final static QName _BillingCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "BillingCode");
    private final static QName _OriginalLineItemNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "OriginalLineItemNumber");
    private final static QName _DistanceType_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DistanceType");
    private final static QName _LocalCurrencyCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "LocalCurrencyCode");
    private final static QName _WeightFactor_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "WeightFactor");
    private final static QName _FareClass_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "FareClass");
    private final static QName _ProductGroup_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProductGroup");
    private final static QName _AreaLocationID_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AreaLocationID");
    private final static QName _BagNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "BagNo");
    private final static QName _PassengerName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "PassengerName");
    private final static QName _OrganizationName1_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "OrganizationName1");
    private final static QName _OrganizationName2_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "OrganizationName2");
    private final static QName _AgreementIndicatorSupplied_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AgreementIndicatorSupplied");
    private final static QName _CabinClass_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CabinClass");
    private final static QName _DailyRate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DailyRate");
    private final static QName _DigitalSignatureFlag_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DigitalSignatureFlag");
    private final static QName _BankAccountName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "BankAccountName");
    private final static QName _CurrAdjustmentIndicator_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CurrAdjustmentIndicator");
    private final static QName _TaxLabel_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TaxLabel");
    private final static QName _EndDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "EndDate");
    private final static QName _BatchSequenceNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "BatchSequenceNumber");
    private final static QName _BilledWeight_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "BilledWeight");
    private final static QName _TaxPercent_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TaxPercent");
    private final static QName _MeterID_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "MeterID");
    private final static QName _MailClass_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "MailClass");
    private final static QName _NetDueDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "NetDueDate");
    private final static QName _TaxCategory_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TaxCategory");
    private final static QName _RejectionReasonCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "RejectionReasonCode");
    private final static QName _CouponNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CouponNumber");
    private final static QName _DeskID_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DeskID");
    private final static QName _InvoiceDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "InvoiceDate");
    private final static QName _AreaName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AreaName");
    private final static QName _ProvisionalBillingMonth_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProvisionalBillingMonth");
    private final static QName _SettlementCurrencyCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "SettlementCurrencyCode");
    private final static QName _AirlineOwnUse20AN_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AirlineOwnUse20AN");
    private final static QName _EmissionClass_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "EmissionClass");
    private final static QName _SimulatorNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "SimulatorNo");
    private final static QName _DiscountDueDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DiscountDueDate");
    private final static QName _BankAccountNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "BankAccountNo");
    private final static QName _TaxIdentifier_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TaxIdentifier");
    private final static QName _ProratePercentage_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProratePercentage");
    private final static QName _ProvisionalInvoiceListingCurrency_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProvisionalInvoiceListingCurrency");
    private final static QName _IssuingOrganizationID_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "IssuingOrganizationID");
    private final static QName _InvoiceTemplateLanguage_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "InvoiceTemplateLanguage");
    private final static QName _TotalNetAmount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TotalNetAmount");
    private final static QName _StationCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "StationCode");
    private final static QName _AddOnChargeName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AddOnChargeName");
    private final static QName _UTCOffset_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "UTCOffset");
    private final static QName _SignedForCurrencyCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "SignedForCurrencyCode");
    private final static QName _LocationName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "LocationName");
    private final static QName _LineItemCount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "LineItemCount");
    private final static QName _CountryName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CountryName");
    private final static QName _YourInvoiceNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "YourInvoiceNumber");
    private final static QName _DiscountDueDays_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DiscountDueDays");
    private final static QName _TaxRegistrationID_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TaxRegistrationID");
    private final static QName _TotalGrossValue_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TotalGrossValue");
    private final static QName _TaxType_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TaxType");
    private final static QName _FlightDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "FlightDate");
    private final static QName _BreakdownSerialNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "BreakdownSerialNumber");
    private final static QName _OurRef_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "OurRef");
    private final static QName _NetAmountDueInBillingCurrency_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "NetAmountDueInBillingCurrency");
    private final static QName _DetailCount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DetailCount");
    private final static QName _TaxInvoiceNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TaxInvoiceNumber");
    private final static QName _AirspaceCorridorCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AirspaceCorridorCode");
    private final static QName _FlightZone_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "FlightZone");
    private final static QName _OrganizationID_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "OrganizationID");
    private final static QName _ToAirportCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ToAirportCode");
    private final static QName _TotalLineItemAmount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TotalLineItemAmount");
    private final static QName _SuspendedAirline_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "SuspendedAirline");
    private final static QName _ChargeCodeType_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ChargeCodeType");
    private final static QName _YourRejectionMemoNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "YourRejectionMemoNumber");
    private final static QName _ClearanceCurrencyCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ClearanceCurrencyCode");
    private final static QName _ProvisionalInvoiceNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProvisionalInvoiceNumber");
    private final static QName _DateOfCarriageOrTransfer_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DateOfCarriageOrTransfer");
    private final static QName _AirlineFlightDesignator_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AirlineFlightDesignator");
    private final static QName _MishandlingType_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "MishandlingType");
    private final static QName _YourRejectionNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "YourRejectionNumber");
    private final static QName _Version_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "Version");
    private final static QName _ContractNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ContractNo");
    private final static QName _ServiceFlightDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ServiceFlightDate");
    private final static QName _TotalTaxAmount_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TotalTaxAmount");
    private final static QName _OriginAirportCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "OriginAirportCode");
    private final static QName _RejectedInvoiceDate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "RejectedInvoiceDate");
    private final static QName _Latitude_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "Latitude");
    private final static QName _CreditMemoNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CreditMemoNumber");
    private final static QName _TaxText_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TaxText");
    private final static QName _TotalAmountAfterSamplingConstant_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TotalAmountAfterSamplingConstant");
    private final static QName _ContactType_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ContactType");
    private final static QName _ProrateMethodology_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProrateMethodology");
    private final static QName _FlightInformationRegion_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "FlightInformationRegion");
    private final static QName _ToAirportOrPointOfTransferCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ToAirportOrPointOfTransferCode");
    private final static QName _RejectedInvoiceNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "RejectedInvoiceNo");
    private final static QName _DestinationAirportCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DestinationAirportCode");
    private final static QName _BillingCategory_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "BillingCategory");
    private final static QName _TaxLevel_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TaxLevel");
    private final static QName _OriginalInvoiceNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "OriginalInvoiceNumber");
    private final static QName _AirlineOwnUse_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AirlineOwnUse");
    private final static QName _AWBCheckDigit_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AWBCheckDigit");
    private final static QName _ToSector_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ToSector");
    private final static QName _ProductID_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ProductID");
    private final static QName _OffStandDateTime_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "OffStandDateTime");
    private final static QName _AWBSerialNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AWBSerialNumber");
    private final static QName _SettlementMethod_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "SettlementMethod");
    private final static QName _CallDayName_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "CallDayName");
    private final static QName _TaxSubType_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TaxSubType");
    private final static QName _AttachmentIndicatorOriginal_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AttachmentIndicatorOriginal");
    private final static QName _PercentShare_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "PercentShare");
    private final static QName _ReceiptNo_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ReceiptNo");
    private final static QName _DailyExchangeRate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "DailyExchangeRate");
    private final static QName _POLineItemNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "POLineItemNumber");
    private final static QName _FlightTypeCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "FlightTypeCode");
    private final static QName _LinkedFIMCouponNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "LinkedFIMCouponNumber");
    private final static QName _ToAirportOfCoupon_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ToAirportOfCoupon");
    private final static QName _SettlementMonthPeriod_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "SettlementMonthPeriod");
    private final static QName _TransmissionID_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "TransmissionID");
    private final static QName _FilingReference_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "FilingReference");
    private final static QName _AddOnChargeCode_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "AddOnChargeCode");
    private final static QName _ExchangeRate_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "ExchangeRate");
    private final static QName _StandType_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "StandType");
    private final static QName _LineItemNumber_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "LineItemNumber");
    private final static QName _OriginalPMI_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "OriginalPMI");
    private final static QName _FlightDirection_QNAME = new QName("http://www.IATA.com/IATAAviationInvoiceStandard", "FlightDirection");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.sgl.smartpra.batch.iata.invoice.app.domain
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link BuyerOrganization }
     * 
     */
    public BuyerOrganization createBuyerOrganization() {
        return new BuyerOrganization();
    }

    /**
     * Create an instance of {@link OtherOrganization }
     * 
     */
    public OtherOrganization createOtherOrganization() {
        return new OtherOrganization();
    }

    /**
     * Create an instance of {@link LineItem }
     * 
     */
    public LineItem createLineItem() {
        return new LineItem();
    }

    /**
     * Create an instance of {@link RouteDetails }
     * 
     */
    public RouteDetails createRouteDetails() {
        return new RouteDetails();
    }

    /**
     * Create an instance of {@link AreaDetails }
     * 
     */
    public AreaDetails createAreaDetails() {
        return new AreaDetails();
    }

    /**
     * Create an instance of {@link SettlementDetails }
     * 
     */
    public SettlementDetails createSettlementDetails() {
        return new SettlementDetails();
    }

    /**
     * Create an instance of {@link AccommodationDetails }
     * 
     */
    public AccommodationDetails createAccommodationDetails() {
        return new AccommodationDetails();
    }

    /**
     * Create an instance of {@link CarDetails }
     * 
     */
    public CarDetails createCarDetails() {
        return new CarDetails();
    }

    /**
     * Create an instance of {@link RejectionMemoDetails }
     * 
     */
    public RejectionMemoDetails createRejectionMemoDetails() {
        return new RejectionMemoDetails();
    }

    /**
     * Create an instance of {@link InvoiceSummary }
     * 
     */
    public InvoiceSummary createInvoiceSummary() {
        return new InvoiceSummary();
    }

    /**
     * Create an instance of {@link SamplingFormEDetails }
     * 
     */
    public SamplingFormEDetails createSamplingFormEDetails() {
        return new SamplingFormEDetails();
    }

    /**
     * Create an instance of {@link TransmissionSummary }
     * 
     */
    public TransmissionSummary createTransmissionSummary() {
        return new TransmissionSummary();
    }

    /**
     * Create an instance of {@link TaxAmount }
     * 
     */
    public TaxAmount createTaxAmount() {
        return new TaxAmount();
    }

    /**
     * Create an instance of {@link ContactDetails }
     * 
     */
    public ContactDetails createContactDetails() {
        return new ContactDetails();
    }

    /**
     * Create an instance of {@link InvoiceTransmission }
     * 
     */
    public InvoiceTransmission createInvoiceTransmission() {
        return new InvoiceTransmission();
    }

    /**
     * Create an instance of {@link TransmissionHeader }
     * 
     */
    public TransmissionHeaderModel createTransmissionHeader() {
        return new TransmissionHeaderModel();
    }

    /**
     * Create an instance of {@link TransmissionData }
     * 
     */
    public TransmissionData createTransmissionData() {
        return new TransmissionData();
    }

    /**
     * Create an instance of {@link Invoice }
     * 
     */
    public Invoice createInvoice() {
        return new Invoice();
    }

    /**
     * Create an instance of {@link InvoiceHeader }
     * 
     */
    public InvoiceHeader createInvoiceHeader() {
        return new InvoiceHeader();
    }

    /**
     * Create an instance of {@link SellerOrganization }
     * 
     */
    public SellerOrganization createSellerOrganization() {
        return new SellerOrganization();
    }

    /**
     * Create an instance of {@link com.sample.app.model.Address }
     * 
     */
    public com.sample.app.model.Address createAddress() {
        return new com.sample.app.model.Address();
    }

    /**
     * Create an instance of {@link AddressBase }
     * 
     */
    public AddressBase createAddressBase() {
        return new AddressBase();
    }

    /**
     * Create an instance of {@link OrganizationData }
     * 
     */
    public OrganizationData createOrganizationData() {
        return new OrganizationData();
    }

    /**
     * Create an instance of {@link BuyerOrganization.Address }
     * 
     */
    public BuyerOrganization.Address createBuyerOrganizationAddress() {
        return new BuyerOrganization.Address();
    }

    /**
     * Create an instance of {@link OtherOrganization.Address }
     * 
     */
    public OtherOrganization.Address createOtherOrganizationAddress() {
        return new OtherOrganization.Address();
    }

    /**
     * Create an instance of {@link AccountDetails }
     * 
     */
    public AccountDetails createAccountDetails() {
        return new AccountDetails();
    }

    /**
     * Create an instance of {@link PaymentTerms }
     * 
     */
    public PaymentTerms createPaymentTerms() {
        return new PaymentTerms();
    }

    /**
     * Create an instance of {@link PaymentData }
     * 
     */
    public PaymentData createPaymentData() {
        return new PaymentData();
    }

    /**
     * Create an instance of {@link ISDetails }
     * 
     */
    public ISDetails createISDetails() {
        return new ISDetails();
    }

    /**
     * Create an instance of {@link RejectedInvoiceDetails }
     * 
     */
    public RejectedInvoiceDetails createRejectedInvoiceDetails() {
        return new RejectedInvoiceDetails();
    }

    /**
     * Create an instance of {@link CorrespondenceDetails }
     * 
     */
    public CorrespondenceDetails createCorrespondenceDetails() {
        return new CorrespondenceDetails();
    }

    /**
     * Create an instance of {@link InvoiceData }
     * 
     */
    public InvoiceData createInvoiceData() {
        return new InvoiceData();
    }

    /**
     * Create an instance of {@link Notes }
     * 
     */
    public Notes createNotes() {
        return new Notes();
    }

    /**
     * Create an instance of {@link Attachment }
     * 
     */
    public Attachment createAttachment() {
        return new Attachment();
    }

    /**
     * Create an instance of {@link Layout }
     * 
     */
    public Layout createLayout() {
        return new Layout();
    }

    /**
     * Create an instance of {@link Quantity }
     * 
     */
    public Quantity createQuantity() {
        return new Quantity();
    }

    /**
     * Create an instance of {@link UnitPrice }
     * 
     */
    public UnitPrice createUnitPrice() {
        return new UnitPrice();
    }

    /**
     * Create an instance of {@link LineItem.ChargeAmount }
     * 
     */
    public LineItem.ChargeAmount createLineItemChargeAmount() {
        return new LineItem.ChargeAmount();
    }

    /**
     * Create an instance of {@link Tax }
     * 
     */
    public Tax createTax() {
        return new Tax();
    }

    /**
     * Create an instance of {@link TaxData }
     * 
     */
    public TaxData createTaxData() {
        return new TaxData();
    }

    /**
     * Create an instance of {@link TaxBreakdown }
     * 
     */
    public TaxBreakdown createTaxBreakdown() {
        return new TaxBreakdown();
    }

    /**
     * Create an instance of {@link com.sample.app.model.AddOnCharges }
     * 
     */
    public com.sample.app.model.AddOnCharges createAddOnCharges() {
        return new com.sample.app.model.AddOnCharges();
    }

    /**
     * Create an instance of {@link LineItemData }
     * 
     */
    public LineItemData createLineItemData() {
        return new LineItemData();
    }

    /**
     * Create an instance of {@link LineItemDetail }
     * 
     */
    public LineItemDetail createLineItemDetail() {
        return new LineItemDetail();
    }

    /**
     * Create an instance of {@link com.sample.app.model.ChargeAmount }
     * 
     */
    public com.sample.app.model.ChargeAmount createChargeAmount() {
        return new com.sample.app.model.ChargeAmount();
    }

    /**
     * Create an instance of {@link ReferenceNo }
     * 
     */
    public ReferenceNo createReferenceNo() {
        return new ReferenceNo();
    }

    /**
     * Create an instance of {@link MailDetails }
     * 
     */
    public MailDetails createMailDetails() {
        return new MailDetails();
    }

    /**
     * Create an instance of {@link AircraftDetails }
     * 
     */
    public AircraftDetails createAircraftDetails() {
        return new AircraftDetails();
    }

    /**
     * Create an instance of {@link MaxTakeOffWeight }
     * 
     */
    public MaxTakeOffWeight createMaxTakeOffWeight() {
        return new MaxTakeOffWeight();
    }

    /**
     * Create an instance of {@link FlightDetails }
     * 
     */
    public FlightDetails createFlightDetails() {
        return new FlightDetails();
    }

    /**
     * Create an instance of {@link PassengerCount }
     * 
     */
    public PassengerCount createPassengerCount() {
        return new PassengerCount();
    }

    /**
     * Create an instance of {@link BagCount }
     * 
     */
    public BagCount createBagCount() {
        return new BagCount();
    }

    /**
     * Create an instance of {@link RouteDetails.LocationCode }
     * 
     */
    public RouteDetails.LocationCode createRouteDetailsLocationCode() {
        return new RouteDetails.LocationCode();
    }

    /**
     * Create an instance of {@link RouteDetails.LocationCodeICAO }
     * 
     */
    public RouteDetails.LocationCodeICAO createRouteDetailsLocationCodeICAO() {
        return new RouteDetails.LocationCodeICAO();
    }

    /**
     * Create an instance of {@link WaypointCode }
     * 
     */
    public WaypointCode createWaypointCode() {
        return new WaypointCode();
    }

    /**
     * Create an instance of {@link RouteDateTime }
     * 
     */
    public RouteDateTime createRouteDateTime() {
        return new RouteDateTime();
    }

    /**
     * Create an instance of {@link Distance }
     * 
     */
    public Distance createDistance() {
        return new Distance();
    }

    /**
     * Create an instance of {@link RouteData }
     * 
     */
    public RouteData createRouteData() {
        return new RouteData();
    }

    /**
     * Create an instance of {@link ParkingDetails }
     * 
     */
    public ParkingDetails createParkingDetails() {
        return new ParkingDetails();
    }

    /**
     * Create an instance of {@link EmployeeDetails }
     * 
     */
    public EmployeeDetails createEmployeeDetails() {
        return new EmployeeDetails();
    }

    /**
     * Create an instance of {@link AreaDetails.Address }
     * 
     */
    public AreaDetails.Address createAreaDetailsAddress() {
        return new AreaDetails.Address();
    }

    /**
     * Create an instance of {@link AreaSize }
     * 
     */
    public AreaSize createAreaSize() {
        return new AreaSize();
    }

    /**
     * Create an instance of {@link DeskGateDetails }
     * 
     */
    public DeskGateDetails createDeskGateDetails() {
        return new DeskGateDetails();
    }

    /**
     * Create an instance of {@link ConsumptionDetails }
     * 
     */
    public ConsumptionDetails createConsumptionDetails() {
        return new ConsumptionDetails();
    }

    /**
     * Create an instance of {@link ConsumedUnits }
     * 
     */
    public ConsumedUnits createConsumedUnits() {
        return new ConsumedUnits();
    }

    /**
     * Create an instance of {@link Temperature }
     * 
     */
    public Temperature createTemperature() {
        return new Temperature();
    }

    /**
     * Create an instance of {@link Density }
     * 
     */
    public Density createDensity() {
        return new Density();
    }

    /**
     * Create an instance of {@link SettlementDetails.Amount }
     * 
     */
    public SettlementDetails.Amount createSettlementDetailsAmount() {
        return new SettlementDetails.Amount();
    }

    /**
     * Create an instance of {@link SettlementDetails.PartialPayments }
     * 
     */
    public SettlementDetails.PartialPayments createSettlementDetailsPartialPayments() {
        return new SettlementDetails.PartialPayments();
    }

    /**
     * Create an instance of {@link ServiceProviderDetails }
     * 
     */
    public ServiceProviderDetails createServiceProviderDetails() {
        return new ServiceProviderDetails();
    }

    /**
     * Create an instance of {@link AccommodationDetails.RoomCategory }
     * 
     */
    public AccommodationDetails.RoomCategory createAccommodationDetailsRoomCategory() {
        return new AccommodationDetails.RoomCategory();
    }

    /**
     * Create an instance of {@link AccommodationDetails.RoomType }
     * 
     */
    public AccommodationDetails.RoomType createAccommodationDetailsRoomType() {
        return new AccommodationDetails.RoomType();
    }

    /**
     * Create an instance of {@link AccommodationDetails.BedType }
     * 
     */
    public AccommodationDetails.BedType createAccommodationDetailsBedType() {
        return new AccommodationDetails.BedType();
    }

    /**
     * Create an instance of {@link CarDetails.CarCategory }
     * 
     */
    public CarDetails.CarCategory createCarDetailsCarCategory() {
        return new CarDetails.CarCategory();
    }

    /**
     * Create an instance of {@link CarDetails.CarType }
     * 
     */
    public CarDetails.CarType createCarDetailsCarType() {
        return new CarDetails.CarType();
    }

    /**
     * Create an instance of {@link CarDetails.CarTransmission }
     * 
     */
    public CarDetails.CarTransmission createCarDetailsCarTransmission() {
        return new CarDetails.CarTransmission();
    }

    /**
     * Create an instance of {@link CarDetails.CarAirFuelCondition }
     * 
     */
    public CarDetails.CarAirFuelCondition createCarDetailsCarAirFuelCondition() {
        return new CarDetails.CarAirFuelCondition();
    }

    /**
     * Create an instance of {@link UATPDetails }
     * 
     */
    public UATPDetails createUATPDetails() {
        return new UATPDetails();
    }

    /**
     * Create an instance of {@link PassengerDetails }
     * 
     */
    public PassengerDetails createPassengerDetails() {
        return new PassengerDetails();
    }

    /**
     * Create an instance of {@link CateringDetails }
     * 
     */
    public CateringDetails createCateringDetails() {
        return new CateringDetails();
    }

    /**
     * Create an instance of {@link MealType }
     * 
     */
    public MealType createMealType() {
        return new MealType();
    }

    /**
     * Create an instance of {@link MiscDetails }
     * 
     */
    public MiscDetails createMiscDetails() {
        return new MiscDetails();
    }

    /**
     * Create an instance of {@link MiscData }
     * 
     */
    public MiscData createMiscData() {
        return new MiscData();
    }

    /**
     * Create an instance of {@link CouponDetails }
     * 
     */
    public CouponDetails createCouponDetails() {
        return new CouponDetails();
    }

    /**
     * Create an instance of {@link SamplingFormDDetails }
     * 
     */
    public SamplingFormDDetails createSamplingFormDDetails() {
        return new SamplingFormDDetails();
    }

    /**
     * Create an instance of {@link AirWaybillDetails }
     * 
     */
    public AirWaybillDetails createAirWaybillDetails() {
        return new AirWaybillDetails();
    }

    /**
     * Create an instance of {@link RMCouponBreakdown }
     * 
     */
    public RMCouponBreakdown createRMCouponBreakdown() {
        return new RMCouponBreakdown();
    }

    /**
     * Create an instance of {@link RejectionMemoDetails.AirWaybillBreakdown }
     * 
     */
    public RejectionMemoDetails.AirWaybillBreakdown createRejectionMemoDetailsAirWaybillBreakdown() {
        return new RejectionMemoDetails.AirWaybillBreakdown();
    }

    /**
     * Create an instance of {@link BillingMemoDetails }
     * 
     */
    public BillingMemoDetails createBillingMemoDetails() {
        return new BillingMemoDetails();
    }

    /**
     * Create an instance of {@link BMCMCouponBreakdown }
     * 
     */
    public BMCMCouponBreakdown createBMCMCouponBreakdown() {
        return new BMCMCouponBreakdown();
    }

    /**
     * Create an instance of {@link com.sample.app.model.AirWaybillBreakdown }
     * 
     */
    public com.sample.app.model.AirWaybillBreakdown createAirWaybillBreakdown() {
        return new com.sample.app.model.AirWaybillBreakdown();
    }

    /**
     * Create an instance of {@link ProrateLadderBreakdown }
     * 
     */
    public ProrateLadderBreakdown createProrateLadderBreakdown() {
        return new ProrateLadderBreakdown();
    }

    /**
     * Create an instance of {@link com.sample.app.model.TotalAmount }
     * 
     */
    public com.sample.app.model.TotalAmount createTotalAmount() {
        return new com.sample.app.model.TotalAmount();
    }

    /**
     * Create an instance of {@link CreditMemoDetails }
     * 
     */
    public CreditMemoDetails createCreditMemoDetails() {
        return new CreditMemoDetails();
    }

    /**
     * Create an instance of {@link InvoiceSummary.AddOnCharges }
     * 
     */
    public InvoiceSummary.AddOnCharges createInvoiceSummaryAddOnCharges() {
        return new InvoiceSummary.AddOnCharges();
    }

    /**
     * Create an instance of {@link InvoiceSummary.TotalAddOnChargeAmount }
     * 
     */
    public InvoiceSummary.TotalAddOnChargeAmount createInvoiceSummaryTotalAddOnChargeAmount() {
        return new InvoiceSummary.TotalAddOnChargeAmount();
    }

    /**
     * Create an instance of {@link SamplingProvisionalAdjustmentDetails }
     * 
     */
    public SamplingProvisionalAdjustmentDetails createSamplingProvisionalAdjustmentDetails() {
        return new SamplingProvisionalAdjustmentDetails();
    }

    /**
     * Create an instance of {@link AbsorptionDetails }
     * 
     */
    public AbsorptionDetails createAbsorptionDetails() {
        return new AbsorptionDetails();
    }

    /**
     * Create an instance of {@link ListingAmountAfterSC }
     * 
     */
    public ListingAmountAfterSC createListingAmountAfterSC() {
        return new ListingAmountAfterSC();
    }

    /**
     * Create an instance of {@link ProvisionalFormBAmount }
     * 
     */
    public ProvisionalFormBAmount createProvisionalFormBAmount() {
        return new ProvisionalFormBAmount();
    }

    /**
     * Create an instance of {@link SamplingFormEDetails.ProvisionalInvoiceDetails }
     * 
     */
    public SamplingFormEDetails.ProvisionalInvoiceDetails createSamplingFormEDetailsProvisionalInvoiceDetails() {
        return new SamplingFormEDetails.ProvisionalInvoiceDetails();
    }

    /**
     * Create an instance of {@link TransmissionSummary.TotalAmount }
     * 
     */
    public TransmissionSummary.TotalAmount createTransmissionSummaryTotalAmount() {
        return new TransmissionSummary.TotalAmount();
    }

    /**
     * Create an instance of {@link TransmissionSummary.TotalAddOnChargeAmount }
     * 
     */
    public TransmissionSummary.TotalAddOnChargeAmount createTransmissionSummaryTotalAddOnChargeAmount() {
        return new TransmissionSummary.TotalAddOnChargeAmount();
    }

    /**
     * Create an instance of {@link TransmissionSummary.TotalTaxAmount }
     * 
     */
    public TransmissionSummary.TotalTaxAmount createTransmissionSummaryTotalTaxAmount() {
        return new TransmissionSummary.TotalTaxAmount();
    }

    /**
     * Create an instance of {@link TransmissionSummary.TotalVATAmount }
     * 
     */
    public TransmissionSummary.TotalVATAmount createTransmissionSummaryTotalVATAmount() {
        return new TransmissionSummary.TotalVATAmount();
    }

    /**
     * Create an instance of {@link com.sample.app.model.PartialPayments }
     * 
     */
    public com.sample.app.model.PartialPayments createPartialPayments() {
        return new com.sample.app.model.PartialPayments();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TicketOrFIMIssuingAirline")
    public JAXBElement<String> createTicketOrFIMIssuingAirline(String value) {
        return new JAXBElement<String>(_TicketOrFIMIssuingAirline_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DeskLocationName")
    public JAXBElement<String> createDeskLocationName(String value) {
        return new JAXBElement<String>(_DeskLocationName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AddressLine3")
    public JAXBElement<String> createAddressLine3(String value) {
        return new JAXBElement<String>(_AddressLine3_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "RecordSequenceWithinBatch")
    public JAXBElement<BigInteger> createRecordSequenceWithinBatch(BigInteger value) {
        return new JAXBElement<BigInteger>(_RecordSequenceWithinBatch_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AddressLine2")
    public JAXBElement<String> createAddressLine2(String value) {
        return new JAXBElement<String>(_AddressLine2_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AddressLine1")
    public JAXBElement<String> createAddressLine1(String value) {
        return new JAXBElement<String>(_AddressLine1_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AbsorptionPercentage")
    public JAXBElement<BigDecimal> createAbsorptionPercentage(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_AbsorptionPercentage_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "YourInvoiceBillingDate")
    public JAXBElement<String> createYourInvoiceBillingDate(String value) {
        return new JAXBElement<String>(_YourInvoiceBillingDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "LocationCode")
    public JAXBElement<String> createLocationCode(String value) {
        return new JAXBElement<String>(_LocationCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "NumberofBags")
    public JAXBElement<BigInteger> createNumberofBags(BigInteger value) {
        return new JAXBElement<BigInteger>(_NumberofBags_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProrateFactor")
    public JAXBElement<BigInteger> createProrateFactor(BigInteger value) {
        return new JAXBElement<BigInteger>(_ProrateFactor_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "SettlementAuthorizationCode")
    public JAXBElement<String> createSettlementAuthorizationCode(String value) {
        return new JAXBElement<String>(_SettlementAuthorizationCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "IBAN")
    public JAXBElement<String> createIBAN(String value) {
        return new JAXBElement<String>(_IBAN_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "PartNo")
    public JAXBElement<String> createPartNo(String value) {
        return new JAXBElement<String>(_PartNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "BoardFlightDate")
    public JAXBElement<String> createBoardFlightDate(String value) {
        return new JAXBElement<String>(_BoardFlightDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "InvoiceNumber")
    public JAXBElement<String> createInvoiceNumber(String value) {
        return new JAXBElement<String>(_InvoiceNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AreaLocationName")
    public JAXBElement<String> createAreaLocationName(String value) {
        return new JAXBElement<String>(_AreaLocationName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "MemberCode")
    public JAXBElement<String> createMemberCode(String value) {
        return new JAXBElement<String>(_MemberCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ISValidationFlag")
    public JAXBElement<String> createISValidationFlag(String value) {
        return new JAXBElement<String>(_ISValidationFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "FlightDateTime")
    public JAXBElement<String> createFlightDateTime(String value) {
        return new JAXBElement<String>(_FlightDateTime_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "MailNo")
    public JAXBElement<String> createMailNo(String value) {
        return new JAXBElement<String>(_MailNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DaysOverdue")
    public JAXBElement<BigInteger> createDaysOverdue(BigInteger value) {
        return new JAXBElement<BigInteger>(_DaysOverdue_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "LocationID")
    public JAXBElement<String> createLocationID(String value) {
        return new JAXBElement<String>(_LocationID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AdditionalTaxRegistrationID")
    public JAXBElement<String> createAdditionalTaxRegistrationID(String value) {
        return new JAXBElement<String>(_AdditionalTaxRegistrationID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AreaType")
    public JAXBElement<String> createAreaType(String value) {
        return new JAXBElement<String>(_AreaType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "SurchargeAmount")
    public JAXBElement<BigDecimal> createSurchargeAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_SurchargeAmount_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "RejectionStage")
    public JAXBElement<BigInteger> createRejectionStage(BigInteger value) {
        return new JAXBElement<BigInteger>(_RejectionStage_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "PONumber")
    public JAXBElement<String> createPONumber(String value) {
        return new JAXBElement<String>(_PONumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "OriginalInvoiceDate")
    public JAXBElement<String> createOriginalInvoiceDate(String value) {
        return new JAXBElement<String>(_OriginalInvoiceDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "SubdivisionName")
    public JAXBElement<String> createSubdivisionName(String value) {
        return new JAXBElement<String>(_SubdivisionName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ReceivingOrganizationID")
    public JAXBElement<String> createReceivingOrganizationID(String value) {
        return new JAXBElement<String>(_ReceivingOrganizationID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "RejectionMemoNumber")
    public JAXBElement<String> createRejectionMemoNumber(String value) {
        return new JAXBElement<String>(_RejectionMemoNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "MailCategory")
    public JAXBElement<String> createMailCategory(String value) {
        return new JAXBElement<String>(_MailCategory_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CarrierPrefix")
    public JAXBElement<String> createCarrierPrefix(String value) {
        return new JAXBElement<String>(_CarrierPrefix_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MinimumQuantityFlag }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "MinimumQuantityFlag")
    public JAXBElement<MinimumQuantityFlag> createMinimumQuantityFlag(MinimumQuantityFlag value) {
        return new JAXBElement<MinimumQuantityFlag>(_MinimumQuantityFlag_QNAME, MinimumQuantityFlag.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TotalFormBAmount")
    public JAXBElement<BigDecimal> createTotalFormBAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TotalFormBAmount_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ValidatedPMI")
    public JAXBElement<String> createValidatedPMI(String value) {
        return new JAXBElement<String>(_ValidatedPMI_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "Facility")
    public JAXBElement<String> createFacility(String value) {
        return new JAXBElement<String>(_Facility_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ContactName")
    public JAXBElement<String> createContactName(String value) {
        return new JAXBElement<String>(_ContactName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DeskType")
    public JAXBElement<String> createDeskType(String value) {
        return new JAXBElement<String>(_DeskType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "NetAmountDueInListingCurrency")
    public JAXBElement<BigDecimal> createNetAmountDueInListingCurrency(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_NetAmountDueInListingCurrency_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ConsignmentNo")
    public JAXBElement<String> createConsignmentNo(String value) {
        return new JAXBElement<String>(_ConsignmentNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "OnStandDateTime")
    public JAXBElement<String> createOnStandDateTime(String value) {
        return new JAXBElement<String>(_OnStandDateTime_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CHAgreementIndicator")
    public JAXBElement<String> createCHAgreementIndicator(String value) {
        return new JAXBElement<String>(_CHAgreementIndicator_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "OrganizationDesignator")
    public JAXBElement<String> createOrganizationDesignator(String value) {
        return new JAXBElement<String>(_OrganizationDesignator_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "BankCode")
    public JAXBElement<String> createBankCode(String value) {
        return new JAXBElement<String>(_BankCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "FromAirportCode")
    public JAXBElement<String> createFromAirportCode(String value) {
        return new JAXBElement<String>(_FromAirportCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProvisoReqSPA }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProvisoReqSPA")
    public JAXBElement<ProvisoReqSPA> createProvisoReqSPA(ProvisoReqSPA value) {
        return new JAXBElement<ProvisoReqSPA>(_ProvisoReqSPA_QNAME, ProvisoReqSPA.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AttachmentIndicatorValidated")
    public JAXBElement<String> createAttachmentIndicatorValidated(String value) {
        return new JAXBElement<String>(_AttachmentIndicatorValidated_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "LinkedFIMBillingCreditMemoNumber")
    public JAXBElement<String> createLinkedFIMBillingCreditMemoNumber(String value) {
        return new JAXBElement<String>(_LinkedFIMBillingCreditMemoNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AttachmentCount")
    public JAXBElement<BigInteger> createAttachmentCount(BigInteger value) {
        return new JAXBElement<BigInteger>(_AttachmentCount_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChargeBasis }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ChargeBasis")
    public JAXBElement<ChargeBasis> createChargeBasis(ChargeBasis value) {
        return new JAXBElement<ChargeBasis>(_ChargeBasis_QNAME, ChargeBasis.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TotalNetRejectAfterSC")
    public JAXBElement<BigDecimal> createTotalNetRejectAfterSC(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TotalNetRejectAfterSC_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TaxableAmount")
    public JAXBElement<BigDecimal> createTaxableAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TaxableAmount_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "Amount")
    public JAXBElement<BigDecimal> createAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_Amount_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "MealCode")
    public JAXBElement<String> createMealCode(String value) {
        return new JAXBElement<String>(_MealCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TicketNo")
    public JAXBElement<String> createTicketNo(String value) {
        return new JAXBElement<String>(_TicketNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TypeOfWeight")
    public JAXBElement<String> createTypeOfWeight(String value) {
        return new JAXBElement<String>(_TypeOfWeight_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "PaymentTermsType")
    public JAXBElement<String> createPaymentTermsType(String value) {
        return new JAXBElement<String>(_PaymentTermsType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "InterestRate")
    public JAXBElement<BigDecimal> createInterestRate(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_InterestRate_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TotalAmountWithoutVAT")
    public JAXBElement<BigDecimal> createTotalAmountWithoutVAT(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TotalAmountWithoutVAT_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AddOnChargeAmount")
    public JAXBElement<BigDecimal> createAddOnChargeAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_AddOnChargeAmount_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "FromAirportOfCoupon")
    public JAXBElement<String> createFromAirportOfCoupon(String value) {
        return new JAXBElement<String>(_FromAirportOfCoupon_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TicketIssuingAirline")
    public JAXBElement<BigInteger> createTicketIssuingAirline(BigInteger value) {
        return new JAXBElement<BigInteger>(_TicketIssuingAirline_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TotalProvisionalAdjustmentAmount")
    public JAXBElement<BigDecimal> createTotalProvisionalAdjustmentAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TotalProvisionalAdjustmentAmount_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "NumberOfBillingRecord")
    public JAXBElement<BigInteger> createNumberOfBillingRecord(BigInteger value) {
        return new JAXBElement<BigInteger>(_NumberOfBillingRecord_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "FromSector")
    public JAXBElement<String> createFromSector(String value) {
        return new JAXBElement<String>(_FromSector_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "SWIFT")
    public JAXBElement<String> createSWIFT(String value) {
        return new JAXBElement<String>(_SWIFT_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CheckDigit")
    public JAXBElement<BigInteger> createCheckDigit(BigInteger value) {
        return new JAXBElement<BigInteger>(_CheckDigit_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TotalProvisionalAdjustmentRate")
    public JAXBElement<BigDecimal> createTotalProvisionalAdjustmentRate(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TotalProvisionalAdjustmentRate_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "InvoiceRefNumber")
    public JAXBElement<String> createInvoiceRefNumber(String value) {
        return new JAXBElement<String>(_InvoiceRefNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "Description")
    public JAXBElement<String> createDescription(String value) {
        return new JAXBElement<String>(_Description_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "NumericCustomerCode")
    public JAXBElement<String> createNumericCustomerCode(String value) {
        return new JAXBElement<String>(_NumericCustomerCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ElectronicTicketIndicator }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ElectronicTicketIndicator")
    public JAXBElement<ElectronicTicketIndicator> createElectronicTicketIndicator(ElectronicTicketIndicator value) {
        return new JAXBElement<ElectronicTicketIndicator>(_ElectronicTicketIndicator_QNAME, ElectronicTicketIndicator.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TicketDocOrFIMNumber")
    public JAXBElement<BigInteger> createTicketDocOrFIMNumber(BigInteger value) {
        return new JAXBElement<BigInteger>(_TicketDocOrFIMNumber_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ServiceFlightNbr")
    public JAXBElement<String> createServiceFlightNbr(String value) {
        return new JAXBElement<String>(_ServiceFlightNbr_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "BranchCode")
    public JAXBElement<String> createBranchCode(String value) {
        return new JAXBElement<String>(_BranchCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "BillingMemoNumber")
    public JAXBElement<String> createBillingMemoNumber(String value) {
        return new JAXBElement<String>(_BillingMemoNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "FileSize")
    public JAXBElement<BigInteger> createFileSize(BigInteger value) {
        return new JAXBElement<BigInteger>(_FileSize_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ChargeCode")
    public JAXBElement<String> createChargeCode(String value) {
        return new JAXBElement<String>(_ChargeCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TicketOrFIMCouponNumber")
    public JAXBElement<BigInteger> createTicketOrFIMCouponNumber(BigInteger value) {
        return new JAXBElement<BigInteger>(_TicketOrFIMCouponNumber_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ISRejectionFlag")
    public JAXBElement<String> createISRejectionFlag(String value) {
        return new JAXBElement<String>(_ISRejectionFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RejectionFlag }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "RejectionFlag")
    public JAXBElement<RejectionFlag> createRejectionFlag(RejectionFlag value) {
        return new JAXBElement<RejectionFlag>(_RejectionFlag_QNAME, RejectionFlag.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "SignedForAmount")
    public JAXBElement<BigDecimal> createSignedForAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_SignedForAmount_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CurrencyOfProrateCalculation")
    public JAXBElement<String> createCurrencyOfProrateCalculation(String value) {
        return new JAXBElement<String>(_CurrencyOfProrateCalculation_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "Recipient")
    public JAXBElement<String> createRecipient(String value) {
        return new JAXBElement<String>(_Recipient_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CityName")
    public JAXBElement<String> createCityName(String value) {
        return new JAXBElement<String>(_CityName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ReasonCode")
    public JAXBElement<String> createReasonCode(String value) {
        return new JAXBElement<String>(_ReasonCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "SubdivisionCode")
    public JAXBElement<String> createSubdivisionCode(String value) {
        return new JAXBElement<String>(_SubdivisionCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AircraftTypeCode_ICAO")
    public JAXBElement<String> createAircraftTypeCodeICAO(String value) {
        return new JAXBElement<String>(_AircraftTypeCodeICAO_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ActivityDate")
    public JAXBElement<String> createActivityDate(String value) {
        return new JAXBElement<String>(_ActivityDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AddOnChargeableAmount")
    public JAXBElement<BigDecimal> createAddOnChargeableAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_AddOnChargeableAmount_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ClearancePeriod")
    public JAXBElement<String> createClearancePeriod(String value) {
        return new JAXBElement<String>(_ClearancePeriod_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TotalAddOnChargeAmount")
    public JAXBElement<BigDecimal> createTotalAddOnChargeAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TotalAddOnChargeAmount_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AircraftTypeCode")
    public JAXBElement<String> createAircraftTypeCode(String value) {
        return new JAXBElement<String>(_AircraftTypeCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "EngineNo")
    public JAXBElement<String> createEngineNo(String value) {
        return new JAXBElement<String>(_EngineNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "PassIssueDate")
    public JAXBElement<String> createPassIssueDate(String value) {
        return new JAXBElement<String>(_PassIssueDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "StartDate")
    public JAXBElement<String> createStartDate(String value) {
        return new JAXBElement<String>(_StartDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProvisionalGrossALFAmount")
    public JAXBElement<BigDecimal> createProvisionalGrossALFAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_ProvisionalGrossALFAmount_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CompanyRegistrationID")
    public JAXBElement<String> createCompanyRegistrationID(String value) {
        return new JAXBElement<String>(_CompanyRegistrationID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ReferenceField20AN")
    public JAXBElement<String> createReferenceField20AN(String value) {
        return new JAXBElement<String>(_ReferenceField20AN_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "EndReading")
    public JAXBElement<BigDecimal> createEndReading(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_EndReading_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "NoiseClass")
    public JAXBElement<String> createNoiseClass(String value) {
        return new JAXBElement<String>(_NoiseClass_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProductName")
    public JAXBElement<String> createProductName(String value) {
        return new JAXBElement<String>(_ProductName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ReasonDescription")
    public JAXBElement<String> createReasonDescription(String value) {
        return new JAXBElement<String>(_ReasonDescription_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProvisionalBillingPeriodNo")
    public JAXBElement<BigInteger> createProvisionalBillingPeriodNo(BigInteger value) {
        return new JAXBElement<BigInteger>(_ProvisionalBillingPeriodNo_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "EndEstimate")
    public JAXBElement<String> createEndEstimate(String value) {
        return new JAXBElement<String>(_EndEstimate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "StaffForename")
    public JAXBElement<String> createStaffForename(String value) {
        return new JAXBElement<String>(_StaffForename_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link KgLbIndicator }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "KgLbIndicator")
    public JAXBElement<KgLbIndicator> createKgLbIndicator(KgLbIndicator value) {
        return new JAXBElement<KgLbIndicator>(_KgLbIndicator_QNAME, KgLbIndicator.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "StartDateTime")
    public JAXBElement<String> createStartDateTime(String value) {
        return new JAXBElement<String>(_StartDateTime_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ReferenceField10AN")
    public JAXBElement<String> createReferenceField10AN(String value) {
        return new JAXBElement<String>(_ReferenceField10AN_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DistanceFactor")
    public JAXBElement<BigDecimal> createDistanceFactor(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_DistanceFactor_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AreaID")
    public JAXBElement<String> createAreaID(String value) {
        return new JAXBElement<String>(_AreaID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "StartEstimate")
    public JAXBElement<String> createStartEstimate(String value) {
        return new JAXBElement<String>(_StartEstimate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProrateSlipBreakdown")
    public JAXBElement<String> createProrateSlipBreakdown(String value) {
        return new JAXBElement<String>(_ProrateSlipBreakdown_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateBasis }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DateBasis")
    public JAXBElement<DateBasis> createDateBasis(DateBasis value) {
        return new JAXBElement<DateBasis>(_DateBasis_QNAME, DateBasis.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrganizationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "OrganizationType")
    public JAXBElement<OrganizationType> createOrganizationType(OrganizationType value) {
        return new JAXBElement<OrganizationType>(_OrganizationType_QNAME, OrganizationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "InvoiceDbsDate")
    public JAXBElement<String> createInvoiceDbsDate(String value) {
        return new JAXBElement<String>(_InvoiceDbsDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InvoiceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "InvoiceType")
    public JAXBElement<InvoiceType> createInvoiceType(InvoiceType value) {
        return new JAXBElement<InvoiceType>(_InvoiceType_QNAME, InvoiceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "IssueDescription")
    public JAXBElement<String> createIssueDescription(String value) {
        return new JAXBElement<String>(_IssueDescription_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProvisionalInvoiceBillingAmount")
    public JAXBElement<BigDecimal> createProvisionalInvoiceBillingAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_ProvisionalInvoiceBillingAmount_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "NumberOfAttachments")
    public JAXBElement<BigInteger> createNumberOfAttachments(BigInteger value) {
        return new JAXBElement<BigInteger>(_NumberOfAttachments_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "NFPReasonCode")
    public JAXBElement<String> createNFPReasonCode(String value) {
        return new JAXBElement<String>(_NFPReasonCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TicketOrFIMCouponNo")
    public JAXBElement<BigInteger> createTicketOrFIMCouponNo(BigInteger value) {
        return new JAXBElement<BigInteger>(_TicketOrFIMCouponNo_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CountryCode")
    public JAXBElement<String> createCountryCode(String value) {
        return new JAXBElement<String>(_CountryCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DueDate")
    public JAXBElement<String> createDueDate(String value) {
        return new JAXBElement<String>(_DueDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "MeterLocationName")
    public JAXBElement<String> createMeterLocationName(String value) {
        return new JAXBElement<String>(_MeterLocationName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DueDateFlag")
    public JAXBElement<String> createDueDateFlag(String value) {
        return new JAXBElement<String>(_DueDateFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "InvoiceOpCode")
    public JAXBElement<String> createInvoiceOpCode(String value) {
        return new JAXBElement<String>(_InvoiceOpCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TaxCode")
    public JAXBElement<String> createTaxCode(String value) {
        return new JAXBElement<String>(_TaxCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "EndDateTime")
    public JAXBElement<String> createEndDateTime(String value) {
        return new JAXBElement<String>(_EndDateTime_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AircraftRegistrationNo")
    public JAXBElement<String> createAircraftRegistrationNo(String value) {
        return new JAXBElement<String>(_AircraftRegistrationNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "PostalCode")
    public JAXBElement<String> createPostalCode(String value) {
        return new JAXBElement<String>(_PostalCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "NetDueDays")
    public JAXBElement<BigInteger> createNetDueDays(BigInteger value) {
        return new JAXBElement<BigInteger>(_NetDueDays_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ContainerNo")
    public JAXBElement<String> createContainerNo(String value) {
        return new JAXBElement<String>(_ContainerNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProvisoReqSPA }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProvisoReqSPAFlag")
    public JAXBElement<ProvisoReqSPA> createProvisoReqSPAFlag(ProvisoReqSPA value) {
        return new JAXBElement<ProvisoReqSPA>(_ProvisoReqSPAFlag_QNAME, ProvisoReqSPA.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AgreementNo")
    public JAXBElement<String> createAgreementNo(String value) {
        return new JAXBElement<String>(_AgreementNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "FlightNo")
    public JAXBElement<BigInteger> createFlightNo(BigInteger value) {
        return new JAXBElement<BigInteger>(_FlightNo_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AttachmentID")
    public JAXBElement<String> createAttachmentID(String value) {
        return new JAXBElement<String>(_AttachmentID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "PoolNo")
    public JAXBElement<String> createPoolNo(String value) {
        return new JAXBElement<String>(_PoolNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "PassNo")
    public JAXBElement<String> createPassNo(String value) {
        return new JAXBElement<String>(_PassNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DetailNumber")
    public JAXBElement<BigInteger> createDetailNumber(BigInteger value) {
        return new JAXBElement<BigInteger>(_DetailNumber_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "SamplingConstant")
    public JAXBElement<BigDecimal> createSamplingConstant(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_SamplingConstant_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "StaffID")
    public JAXBElement<String> createStaffID(String value) {
        return new JAXBElement<String>(_StaffID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "LinkedFIMNumber")
    public JAXBElement<BigInteger> createLinkedFIMNumber(BigInteger value) {
        return new JAXBElement<BigInteger>(_LinkedFIMNumber_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "StartReading")
    public JAXBElement<BigDecimal> createStartReading(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_StartReading_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CountryCode_ICAO")
    public JAXBElement<String> createCountryCodeICAO(String value) {
        return new JAXBElement<String>(_CountryCodeICAO_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AircraftTypeName")
    public JAXBElement<String> createAircraftTypeName(String value) {
        return new JAXBElement<String>(_AircraftTypeName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "NoOfBillingRecords")
    public JAXBElement<BigInteger> createNoOfBillingRecords(BigInteger value) {
        return new JAXBElement<BigInteger>(_NoOfBillingRecords_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ContactValue")
    public JAXBElement<String> createContactValue(String value) {
        return new JAXBElement<String>(_ContactValue_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "LocationCode_ICAO")
    public JAXBElement<String> createLocationCodeICAO(String value) {
        return new JAXBElement<String>(_LocationCodeICAO_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "RejectedCommissions")
    public JAXBElement<BigDecimal> createRejectedCommissions(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_RejectedCommissions_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TotalAmountInClearanceCurrency")
    public JAXBElement<BigDecimal> createTotalAmountInClearanceCurrency(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TotalAmountInClearanceCurrency_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AbsorptionName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AbsorptionName")
    public JAXBElement<AbsorptionName> createAbsorptionName(AbsorptionName value) {
        return new JAXBElement<AbsorptionName>(_AbsorptionName_QNAME, AbsorptionName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "PassExpiryDate")
    public JAXBElement<String> createPassExpiryDate(String value) {
        return new JAXBElement<String>(_PassExpiryDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BooleanFlag }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AuthorityToBillFlag")
    public JAXBElement<BooleanFlag> createAuthorityToBillFlag(BooleanFlag value) {
        return new JAXBElement<BooleanFlag>(_AuthorityToBillFlag_QNAME, BooleanFlag.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "StaffSurname")
    public JAXBElement<String> createStaffSurname(String value) {
        return new JAXBElement<String>(_StaffSurname_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "StandNo")
    public JAXBElement<String> createStandNo(String value) {
        return new JAXBElement<String>(_StandNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AWBDate")
    public JAXBElement<String> createAWBDate(String value) {
        return new JAXBElement<String>(_AWBDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProvisionalListingToBillingRate")
    public JAXBElement<BigDecimal> createProvisionalListingToBillingRate(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_ProvisionalListingToBillingRate_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CorrespondenceFlag }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CorrespondenceFlag")
    public JAXBElement<CorrespondenceFlag> createCorrespondenceFlag(CorrespondenceFlag value) {
        return new JAXBElement<CorrespondenceFlag>(_CorrespondenceFlag_QNAME, CorrespondenceFlag.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AddOnChargePercentage")
    public JAXBElement<Object> createAddOnChargePercentage(Object value) {
        return new JAXBElement<Object>(_AddOnChargePercentage_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TransmissionDateTime")
    public JAXBElement<String> createTransmissionDateTime(String value) {
        return new JAXBElement<String>(_TransmissionDateTime_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AgreementIndicatorValidated")
    public JAXBElement<String> createAgreementIndicatorValidated(String value) {
        return new JAXBElement<String>(_AgreementIndicatorValidated_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CorrespondenceRefNumber")
    public JAXBElement<BigInteger> createCorrespondenceRefNumber(BigInteger value) {
        return new JAXBElement<BigInteger>(_CorrespondenceRefNumber_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "Longitude")
    public JAXBElement<String> createLongitude(String value) {
        return new JAXBElement<String>(_Longitude_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "StaffName")
    public JAXBElement<String> createStaffName(String value) {
        return new JAXBElement<String>(_StaffName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BooleanFlag }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CCAIndicator")
    public JAXBElement<BooleanFlag> createCCAIndicator(BooleanFlag value) {
        return new JAXBElement<BooleanFlag>(_CCAIndicator_QNAME, BooleanFlag.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TicketDocNumber")
    public JAXBElement<BigInteger> createTicketDocNumber(BigInteger value) {
        return new JAXBElement<BigInteger>(_TicketDocNumber_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PartShipmentIndicator }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "PartShipmentIndicator")
    public JAXBElement<PartShipmentIndicator> createPartShipmentIndicator(PartShipmentIndicator value) {
        return new JAXBElement<PartShipmentIndicator>(_PartShipmentIndicator_QNAME, PartShipmentIndicator.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "BoardFlightNbr")
    public JAXBElement<String> createBoardFlightNbr(String value) {
        return new JAXBElement<String>(_BoardFlightNbr_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ChargeCategory")
    public JAXBElement<String> createChargeCategory(String value) {
        return new JAXBElement<String>(_ChargeCategory_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProvisionalInvoiceDate")
    public JAXBElement<String> createProvisionalInvoiceDate(String value) {
        return new JAXBElement<String>(_ProvisionalInvoiceDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TaxPointDate")
    public JAXBElement<String> createTaxPointDate(String value) {
        return new JAXBElement<String>(_TaxPointDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AWBIssuingAirline")
    public JAXBElement<BigInteger> createAWBIssuingAirline(BigInteger value) {
        return new JAXBElement<BigInteger>(_AWBIssuingAirline_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "EngineType")
    public JAXBElement<String> createEngineType(String value) {
        return new JAXBElement<String>(_EngineType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DiscountPercent")
    public JAXBElement<BigDecimal> createDiscountPercent(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_DiscountPercent_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CurrencyCode")
    public JAXBElement<String> createCurrencyCode(String value) {
        return new JAXBElement<String>(_CurrencyCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "InvoiceCount")
    public JAXBElement<Integer> createInvoiceCount(Integer value) {
        return new JAXBElement<Integer>(_InvoiceCount_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "NetAmount")
    public JAXBElement<BigDecimal> createNetAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_NetAmount_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HandlingFeeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "HandlingFeeType")
    public JAXBElement<HandlingFeeType> createHandlingFeeType(HandlingFeeType value) {
        return new JAXBElement<HandlingFeeType>(_HandlingFeeType_QNAME, HandlingFeeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BillingCode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "BillingCode")
    public JAXBElement<BillingCode> createBillingCode(BillingCode value) {
        return new JAXBElement<BillingCode>(_BillingCode_QNAME, BillingCode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "OriginalLineItemNumber")
    public JAXBElement<BigInteger> createOriginalLineItemNumber(BigInteger value) {
        return new JAXBElement<BigInteger>(_OriginalLineItemNumber_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DistanceType")
    public JAXBElement<String> createDistanceType(String value) {
        return new JAXBElement<String>(_DistanceType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "LocalCurrencyCode")
    public JAXBElement<String> createLocalCurrencyCode(String value) {
        return new JAXBElement<String>(_LocalCurrencyCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "WeightFactor")
    public JAXBElement<BigDecimal> createWeightFactor(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_WeightFactor_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "FareClass")
    public JAXBElement<String> createFareClass(String value) {
        return new JAXBElement<String>(_FareClass_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProductGroup")
    public JAXBElement<String> createProductGroup(String value) {
        return new JAXBElement<String>(_ProductGroup_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AreaLocationID")
    public JAXBElement<String> createAreaLocationID(String value) {
        return new JAXBElement<String>(_AreaLocationID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "BagNo")
    public JAXBElement<String> createBagNo(String value) {
        return new JAXBElement<String>(_BagNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "PassengerName")
    public JAXBElement<String> createPassengerName(String value) {
        return new JAXBElement<String>(_PassengerName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "OrganizationName1")
    public JAXBElement<String> createOrganizationName1(String value) {
        return new JAXBElement<String>(_OrganizationName1_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "OrganizationName2")
    public JAXBElement<String> createOrganizationName2(String value) {
        return new JAXBElement<String>(_OrganizationName2_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AgreementIndicatorSupplied")
    public JAXBElement<String> createAgreementIndicatorSupplied(String value) {
        return new JAXBElement<String>(_AgreementIndicatorSupplied_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CabinClass")
    public JAXBElement<String> createCabinClass(String value) {
        return new JAXBElement<String>(_CabinClass_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DailyRate")
    public JAXBElement<BigDecimal> createDailyRate(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_DailyRate_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DigitalSignatureFlag }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DigitalSignatureFlag")
    public JAXBElement<DigitalSignatureFlag> createDigitalSignatureFlag(DigitalSignatureFlag value) {
        return new JAXBElement<DigitalSignatureFlag>(_DigitalSignatureFlag_QNAME, DigitalSignatureFlag.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "BankAccountName")
    public JAXBElement<String> createBankAccountName(String value) {
        return new JAXBElement<String>(_BankAccountName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CurrAdjustmentIndicator")
    public JAXBElement<String> createCurrAdjustmentIndicator(String value) {
        return new JAXBElement<String>(_CurrAdjustmentIndicator_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TaxLabel")
    public JAXBElement<String> createTaxLabel(String value) {
        return new JAXBElement<String>(_TaxLabel_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "EndDate")
    public JAXBElement<String> createEndDate(String value) {
        return new JAXBElement<String>(_EndDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "BatchSequenceNumber")
    public JAXBElement<BigInteger> createBatchSequenceNumber(BigInteger value) {
        return new JAXBElement<BigInteger>(_BatchSequenceNumber_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "BilledWeight")
    public JAXBElement<BigInteger> createBilledWeight(BigInteger value) {
        return new JAXBElement<BigInteger>(_BilledWeight_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TaxPercent")
    public JAXBElement<BigDecimal> createTaxPercent(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TaxPercent_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "MeterID")
    public JAXBElement<String> createMeterID(String value) {
        return new JAXBElement<String>(_MeterID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "MailClass")
    public JAXBElement<String> createMailClass(String value) {
        return new JAXBElement<String>(_MailClass_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "NetDueDate")
    public JAXBElement<String> createNetDueDate(String value) {
        return new JAXBElement<String>(_NetDueDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TaxCategory }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TaxCategory")
    public JAXBElement<TaxCategory> createTaxCategory(TaxCategory value) {
        return new JAXBElement<TaxCategory>(_TaxCategory_QNAME, TaxCategory.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "RejectionReasonCode")
    public JAXBElement<String> createRejectionReasonCode(String value) {
        return new JAXBElement<String>(_RejectionReasonCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CouponNumber")
    public JAXBElement<BigInteger> createCouponNumber(BigInteger value) {
        return new JAXBElement<BigInteger>(_CouponNumber_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DeskID")
    public JAXBElement<String> createDeskID(String value) {
        return new JAXBElement<String>(_DeskID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "InvoiceDate")
    public JAXBElement<String> createInvoiceDate(String value) {
        return new JAXBElement<String>(_InvoiceDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AreaName")
    public JAXBElement<String> createAreaName(String value) {
        return new JAXBElement<String>(_AreaName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProvisionalBillingMonth")
    public JAXBElement<String> createProvisionalBillingMonth(String value) {
        return new JAXBElement<String>(_ProvisionalBillingMonth_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "SettlementCurrencyCode")
    public JAXBElement<String> createSettlementCurrencyCode(String value) {
        return new JAXBElement<String>(_SettlementCurrencyCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AirlineOwnUse20AN")
    public JAXBElement<String> createAirlineOwnUse20AN(String value) {
        return new JAXBElement<String>(_AirlineOwnUse20AN_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "EmissionClass")
    public JAXBElement<String> createEmissionClass(String value) {
        return new JAXBElement<String>(_EmissionClass_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "SimulatorNo")
    public JAXBElement<String> createSimulatorNo(String value) {
        return new JAXBElement<String>(_SimulatorNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DiscountDueDate")
    public JAXBElement<String> createDiscountDueDate(String value) {
        return new JAXBElement<String>(_DiscountDueDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "BankAccountNo")
    public JAXBElement<String> createBankAccountNo(String value) {
        return new JAXBElement<String>(_BankAccountNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TaxIdentifier")
    public JAXBElement<String> createTaxIdentifier(String value) {
        return new JAXBElement<String>(_TaxIdentifier_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProratePercentage")
    public JAXBElement<BigInteger> createProratePercentage(BigInteger value) {
        return new JAXBElement<BigInteger>(_ProratePercentage_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProvisionalInvoiceListingCurrency")
    public JAXBElement<String> createProvisionalInvoiceListingCurrency(String value) {
        return new JAXBElement<String>(_ProvisionalInvoiceListingCurrency_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "IssuingOrganizationID")
    public JAXBElement<String> createIssuingOrganizationID(String value) {
        return new JAXBElement<String>(_IssuingOrganizationID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "InvoiceTemplateLanguage")
    public JAXBElement<String> createInvoiceTemplateLanguage(String value) {
        return new JAXBElement<String>(_InvoiceTemplateLanguage_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TotalNetAmount")
    public JAXBElement<BigDecimal> createTotalNetAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TotalNetAmount_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "StationCode")
    public JAXBElement<String> createStationCode(String value) {
        return new JAXBElement<String>(_StationCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AddOnChargeName")
    public JAXBElement<String> createAddOnChargeName(String value) {
        return new JAXBElement<String>(_AddOnChargeName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "UTCOffset")
    public JAXBElement<BigDecimal> createUTCOffset(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_UTCOffset_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "SignedForCurrencyCode")
    public JAXBElement<String> createSignedForCurrencyCode(String value) {
        return new JAXBElement<String>(_SignedForCurrencyCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "LocationName")
    public JAXBElement<String> createLocationName(String value) {
        return new JAXBElement<String>(_LocationName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "LineItemCount")
    public JAXBElement<BigInteger> createLineItemCount(BigInteger value) {
        return new JAXBElement<BigInteger>(_LineItemCount_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CountryName")
    public JAXBElement<String> createCountryName(String value) {
        return new JAXBElement<String>(_CountryName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "YourInvoiceNumber")
    public JAXBElement<String> createYourInvoiceNumber(String value) {
        return new JAXBElement<String>(_YourInvoiceNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DiscountDueDays")
    public JAXBElement<BigInteger> createDiscountDueDays(BigInteger value) {
        return new JAXBElement<BigInteger>(_DiscountDueDays_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TaxRegistrationID")
    public JAXBElement<String> createTaxRegistrationID(String value) {
        return new JAXBElement<String>(_TaxRegistrationID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TotalGrossValue")
    public JAXBElement<BigDecimal> createTotalGrossValue(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TotalGrossValue_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TaxType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TaxType")
    public JAXBElement<TaxType> createTaxType(TaxType value) {
        return new JAXBElement<TaxType>(_TaxType_QNAME, TaxType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "FlightDate")
    public JAXBElement<String> createFlightDate(String value) {
        return new JAXBElement<String>(_FlightDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "BreakdownSerialNumber")
    public JAXBElement<BigInteger> createBreakdownSerialNumber(BigInteger value) {
        return new JAXBElement<BigInteger>(_BreakdownSerialNumber_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "OurRef")
    public JAXBElement<String> createOurRef(String value) {
        return new JAXBElement<String>(_OurRef_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "NetAmountDueInBillingCurrency")
    public JAXBElement<BigDecimal> createNetAmountDueInBillingCurrency(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_NetAmountDueInBillingCurrency_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DetailCount")
    public JAXBElement<BigInteger> createDetailCount(BigInteger value) {
        return new JAXBElement<BigInteger>(_DetailCount_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TaxInvoiceNumber")
    public JAXBElement<String> createTaxInvoiceNumber(String value) {
        return new JAXBElement<String>(_TaxInvoiceNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AirspaceCorridorCode")
    public JAXBElement<String> createAirspaceCorridorCode(String value) {
        return new JAXBElement<String>(_AirspaceCorridorCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "FlightZone")
    public JAXBElement<String> createFlightZone(String value) {
        return new JAXBElement<String>(_FlightZone_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "OrganizationID")
    public JAXBElement<String> createOrganizationID(String value) {
        return new JAXBElement<String>(_OrganizationID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ToAirportCode")
    public JAXBElement<String> createToAirportCode(String value) {
        return new JAXBElement<String>(_ToAirportCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TotalLineItemAmount")
    public JAXBElement<BigDecimal> createTotalLineItemAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TotalLineItemAmount_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "SuspendedAirline")
    public JAXBElement<String> createSuspendedAirline(String value) {
        return new JAXBElement<String>(_SuspendedAirline_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ChargeCodeType")
    public JAXBElement<String> createChargeCodeType(String value) {
        return new JAXBElement<String>(_ChargeCodeType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "YourRejectionMemoNumber")
    public JAXBElement<String> createYourRejectionMemoNumber(String value) {
        return new JAXBElement<String>(_YourRejectionMemoNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ClearanceCurrencyCode")
    public JAXBElement<String> createClearanceCurrencyCode(String value) {
        return new JAXBElement<String>(_ClearanceCurrencyCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProvisionalInvoiceNumber")
    public JAXBElement<String> createProvisionalInvoiceNumber(String value) {
        return new JAXBElement<String>(_ProvisionalInvoiceNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DateOfCarriageOrTransfer")
    public JAXBElement<String> createDateOfCarriageOrTransfer(String value) {
        return new JAXBElement<String>(_DateOfCarriageOrTransfer_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AirlineFlightDesignator")
    public JAXBElement<String> createAirlineFlightDesignator(String value) {
        return new JAXBElement<String>(_AirlineFlightDesignator_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "MishandlingType")
    public JAXBElement<String> createMishandlingType(String value) {
        return new JAXBElement<String>(_MishandlingType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "YourRejectionNumber")
    public JAXBElement<String> createYourRejectionNumber(String value) {
        return new JAXBElement<String>(_YourRejectionNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "Version")
    public JAXBElement<String> createVersion(String value) {
        return new JAXBElement<String>(_Version_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ContractNo")
    public JAXBElement<String> createContractNo(String value) {
        return new JAXBElement<String>(_ContractNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ServiceFlightDate")
    public JAXBElement<String> createServiceFlightDate(String value) {
        return new JAXBElement<String>(_ServiceFlightDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TotalTaxAmount")
    public JAXBElement<BigDecimal> createTotalTaxAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TotalTaxAmount_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "OriginAirportCode")
    public JAXBElement<String> createOriginAirportCode(String value) {
        return new JAXBElement<String>(_OriginAirportCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "RejectedInvoiceDate")
    public JAXBElement<String> createRejectedInvoiceDate(String value) {
        return new JAXBElement<String>(_RejectedInvoiceDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "Latitude")
    public JAXBElement<String> createLatitude(String value) {
        return new JAXBElement<String>(_Latitude_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CreditMemoNumber")
    public JAXBElement<String> createCreditMemoNumber(String value) {
        return new JAXBElement<String>(_CreditMemoNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TaxText")
    public JAXBElement<String> createTaxText(String value) {
        return new JAXBElement<String>(_TaxText_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TotalAmountAfterSamplingConstant")
    public JAXBElement<BigDecimal> createTotalAmountAfterSamplingConstant(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TotalAmountAfterSamplingConstant_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContactType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ContactType")
    public JAXBElement<ContactType> createContactType(ContactType value) {
        return new JAXBElement<ContactType>(_ContactType_QNAME, ContactType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProrateMethodology")
    public JAXBElement<String> createProrateMethodology(String value) {
        return new JAXBElement<String>(_ProrateMethodology_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "FlightInformationRegion")
    public JAXBElement<String> createFlightInformationRegion(String value) {
        return new JAXBElement<String>(_FlightInformationRegion_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ToAirportOrPointOfTransferCode")
    public JAXBElement<String> createToAirportOrPointOfTransferCode(String value) {
        return new JAXBElement<String>(_ToAirportOrPointOfTransferCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "RejectedInvoiceNo")
    public JAXBElement<String> createRejectedInvoiceNo(String value) {
        return new JAXBElement<String>(_RejectedInvoiceNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DestinationAirportCode")
    public JAXBElement<String> createDestinationAirportCode(String value) {
        return new JAXBElement<String>(_DestinationAirportCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "BillingCategory")
    public JAXBElement<String> createBillingCategory(String value) {
        return new JAXBElement<String>(_BillingCategory_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TaxLevel }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TaxLevel")
    public JAXBElement<TaxLevel> createTaxLevel(TaxLevel value) {
        return new JAXBElement<TaxLevel>(_TaxLevel_QNAME, TaxLevel.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "OriginalInvoiceNumber")
    public JAXBElement<String> createOriginalInvoiceNumber(String value) {
        return new JAXBElement<String>(_OriginalInvoiceNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AirlineOwnUse")
    public JAXBElement<String> createAirlineOwnUse(String value) {
        return new JAXBElement<String>(_AirlineOwnUse_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AWBCheckDigit")
    public JAXBElement<BigInteger> createAWBCheckDigit(BigInteger value) {
        return new JAXBElement<BigInteger>(_AWBCheckDigit_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ToSector")
    public JAXBElement<String> createToSector(String value) {
        return new JAXBElement<String>(_ToSector_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ProductID")
    public JAXBElement<String> createProductID(String value) {
        return new JAXBElement<String>(_ProductID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "OffStandDateTime")
    public JAXBElement<String> createOffStandDateTime(String value) {
        return new JAXBElement<String>(_OffStandDateTime_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AWBSerialNumber")
    public JAXBElement<String> createAWBSerialNumber(String value) {
        return new JAXBElement<String>(_AWBSerialNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SettlementMethod }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "SettlementMethod")
    public JAXBElement<SettlementMethod> createSettlementMethod(SettlementMethod value) {
        return new JAXBElement<SettlementMethod>(_SettlementMethod_QNAME, SettlementMethod.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "CallDayName")
    public JAXBElement<String> createCallDayName(String value) {
        return new JAXBElement<String>(_CallDayName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TaxSubType")
    public JAXBElement<String> createTaxSubType(String value) {
        return new JAXBElement<String>(_TaxSubType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AttachmentIndicatorOriginalFlag }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AttachmentIndicatorOriginal")
    public JAXBElement<AttachmentIndicatorOriginalFlag> createAttachmentIndicatorOriginal(AttachmentIndicatorOriginalFlag value) {
        return new JAXBElement<AttachmentIndicatorOriginalFlag>(_AttachmentIndicatorOriginal_QNAME, AttachmentIndicatorOriginalFlag.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "PercentShare")
    public JAXBElement<BigDecimal> createPercentShare(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_PercentShare_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ReceiptNo")
    public JAXBElement<String> createReceiptNo(String value) {
        return new JAXBElement<String>(_ReceiptNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "DailyExchangeRate")
    public JAXBElement<BigDecimal> createDailyExchangeRate(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_DailyExchangeRate_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "POLineItemNumber")
    public JAXBElement<BigInteger> createPOLineItemNumber(BigInteger value) {
        return new JAXBElement<BigInteger>(_POLineItemNumber_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "FlightTypeCode")
    public JAXBElement<String> createFlightTypeCode(String value) {
        return new JAXBElement<String>(_FlightTypeCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "LinkedFIMCouponNumber")
    public JAXBElement<BigInteger> createLinkedFIMCouponNumber(BigInteger value) {
        return new JAXBElement<BigInteger>(_LinkedFIMCouponNumber_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ToAirportOfCoupon")
    public JAXBElement<String> createToAirportOfCoupon(String value) {
        return new JAXBElement<String>(_ToAirportOfCoupon_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "SettlementMonthPeriod")
    public JAXBElement<String> createSettlementMonthPeriod(String value) {
        return new JAXBElement<String>(_SettlementMonthPeriod_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "TransmissionID")
    public JAXBElement<String> createTransmissionID(String value) {
        return new JAXBElement<String>(_TransmissionID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "FilingReference")
    public JAXBElement<String> createFilingReference(String value) {
        return new JAXBElement<String>(_FilingReference_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "AddOnChargeCode")
    public JAXBElement<String> createAddOnChargeCode(String value) {
        return new JAXBElement<String>(_AddOnChargeCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "ExchangeRate")
    public JAXBElement<BigDecimal> createExchangeRate(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_ExchangeRate_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "StandType")
    public JAXBElement<String> createStandType(String value) {
        return new JAXBElement<String>(_StandType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "LineItemNumber")
    public JAXBElement<BigInteger> createLineItemNumber(BigInteger value) {
        return new JAXBElement<BigInteger>(_LineItemNumber_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "OriginalPMI")
    public JAXBElement<String> createOriginalPMI(String value) {
        return new JAXBElement<String>(_OriginalPMI_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", name = "FlightDirection")
    public JAXBElement<String> createFlightDirection(String value) {
        return new JAXBElement<String>(_FlightDirection_QNAME, String.class, null, value);
    }

}
