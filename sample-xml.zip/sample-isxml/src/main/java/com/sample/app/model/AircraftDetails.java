
package com.sample.app.model;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AircraftRegistrationNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}MaxTakeOffWeight" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TypeOfWeight" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}WeightFactor" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AircraftTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AircraftTypeCode_ICAO" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AircraftTypeName" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}EngineType" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}EngineNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PartNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CabinClass" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}NoiseClass" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}EmissionClass" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "aircraftRegistrationNo",
    "maxTakeOffWeight",
    "typeOfWeight",
    "weightFactor",
    "aircraftTypeCode",
    "aircraftTypeCodeICAO",
    "aircraftTypeName",
    "engineType",
    "engineNo",
    "partNo",
    "cabinClass",
    "noiseClass",
    "emissionClass"
})
@XmlRootElement(name = "AircraftDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class AircraftDetails {

    @XmlElement(name = "AircraftRegistrationNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String aircraftRegistrationNo;
    @XmlElement(name = "MaxTakeOffWeight", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected MaxTakeOffWeight maxTakeOffWeight;
    @XmlElement(name = "TypeOfWeight", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String typeOfWeight;
    @XmlElement(name = "WeightFactor", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal weightFactor;
    @XmlElement(name = "AircraftTypeCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String aircraftTypeCode;
    @XmlElement(name = "AircraftTypeCode_ICAO", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String aircraftTypeCodeICAO;
    @XmlElement(name = "AircraftTypeName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String aircraftTypeName;
    @XmlElement(name = "EngineType", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String engineType;
    @XmlElement(name = "EngineNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String engineNo;
    @XmlElement(name = "PartNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String partNo;
    @XmlElement(name = "CabinClass", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String cabinClass;
    @XmlElement(name = "NoiseClass", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String noiseClass;
    @XmlElement(name = "EmissionClass", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String emissionClass;

    /**
     * Gets the value of the aircraftRegistrationNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAircraftRegistrationNo() {
        return aircraftRegistrationNo;
    }

    /**
     * Sets the value of the aircraftRegistrationNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAircraftRegistrationNo(String value) {
        this.aircraftRegistrationNo = value;
    }

    /**
     * Gets the value of the maxTakeOffWeight property.
     * 
     * @return
     *     possible object is
     *     {@link MaxTakeOffWeight }
     *     
     */
    public MaxTakeOffWeight getMaxTakeOffWeight() {
        return maxTakeOffWeight;
    }

    /**
     * Sets the value of the maxTakeOffWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link MaxTakeOffWeight }
     *     
     */
    public void setMaxTakeOffWeight(MaxTakeOffWeight value) {
        this.maxTakeOffWeight = value;
    }

    /**
     * Gets the value of the typeOfWeight property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfWeight() {
        return typeOfWeight;
    }

    /**
     * Sets the value of the typeOfWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfWeight(String value) {
        this.typeOfWeight = value;
    }

    /**
     * Gets the value of the weightFactor property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getWeightFactor() {
        return weightFactor;
    }

    /**
     * Sets the value of the weightFactor property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setWeightFactor(BigDecimal value) {
        this.weightFactor = value;
    }

    /**
     * Gets the value of the aircraftTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAircraftTypeCode() {
        return aircraftTypeCode;
    }

    /**
     * Sets the value of the aircraftTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAircraftTypeCode(String value) {
        this.aircraftTypeCode = value;
    }

    /**
     * Gets the value of the aircraftTypeCodeICAO property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAircraftTypeCodeICAO() {
        return aircraftTypeCodeICAO;
    }

    /**
     * Sets the value of the aircraftTypeCodeICAO property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAircraftTypeCodeICAO(String value) {
        this.aircraftTypeCodeICAO = value;
    }

    /**
     * Gets the value of the aircraftTypeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAircraftTypeName() {
        return aircraftTypeName;
    }

    /**
     * Sets the value of the aircraftTypeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAircraftTypeName(String value) {
        this.aircraftTypeName = value;
    }

    /**
     * Gets the value of the engineType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEngineType() {
        return engineType;
    }

    /**
     * Sets the value of the engineType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEngineType(String value) {
        this.engineType = value;
    }

    /**
     * Gets the value of the engineNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEngineNo() {
        return engineNo;
    }

    /**
     * Sets the value of the engineNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEngineNo(String value) {
        this.engineNo = value;
    }

    /**
     * Gets the value of the partNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartNo() {
        return partNo;
    }

    /**
     * Sets the value of the partNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartNo(String value) {
        this.partNo = value;
    }

    /**
     * Gets the value of the cabinClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCabinClass() {
        return cabinClass;
    }

    /**
     * Sets the value of the cabinClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCabinClass(String value) {
        this.cabinClass = value;
    }

    /**
     * Gets the value of the noiseClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoiseClass() {
        return noiseClass;
    }

    /**
     * Sets the value of the noiseClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoiseClass(String value) {
        this.noiseClass = value;
    }

    /**
     * Gets the value of the emissionClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmissionClass() {
        return emissionClass;
    }

    /**
     * Sets the value of the emissionClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmissionClass(String value) {
        this.emissionClass = value;
    }

}
