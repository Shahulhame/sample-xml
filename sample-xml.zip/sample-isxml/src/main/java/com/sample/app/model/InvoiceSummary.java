
package com.sample.app.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}LineItemCount"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TotalLineItemAmount"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Tax" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="AddOnCharges" maxOccurs="unbounded" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnChargeName"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnChargeCode" minOccurs="0"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnChargePercentage" minOccurs="0"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnChargeableAmount" minOccurs="0"/>
 *                   &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnChargeAmount"/>
 *                   &lt;element name="ChargeForLineItemNos" type="{http://www.IATA.com/IATAAviationStandardDataTypes}AN700Base" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="TotalAddOnChargeAmount" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="TotalTaxAmount" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base" minOccurs="0"/>
 *         &lt;element name="TotalVATAmount" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base" minOccurs="0"/>
 *         &lt;element name="TotalVatAmountAfterSamplingConstant" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TotalAmountWithoutVAT" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TotalAmount"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TotalAmountInClearanceCurrency" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SamplingProvisionalAdjustmentDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SamplingFormEDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AttachmentCount" minOccurs="0"/>
 *         &lt;element name="LegalText" type="{http://www.IATA.com/IATAAviationStandardDataTypes}AN70Base" maxOccurs="10" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "lineItemCount",
    "totalLineItemAmount",
    "tax",
    "addOnCharges",
    "totalAddOnChargeAmount",
    "totalTaxAmount",
    "totalVATAmount",
    "totalVatAmountAfterSamplingConstant",
    "totalAmountWithoutVAT",
    "totalAmount",
    "totalAmountInClearanceCurrency",
    "samplingProvisionalAdjustmentDetails",
    "samplingFormEDetails",
    "attachmentCount",
    "legalText"
})
@XmlRootElement(name = "InvoiceSummary", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class InvoiceSummary {

    @XmlElement(name = "LineItemCount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigInteger lineItemCount;
    @XmlElement(name = "TotalLineItemAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigDecimal totalLineItemAmount;
    @XmlElement(name = "Tax", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<Tax> tax;
    @XmlElement(name = "AddOnCharges", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<InvoiceSummary.AddOnCharges> addOnCharges;
    @XmlElement(name = "TotalAddOnChargeAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected InvoiceSummary.TotalAddOnChargeAmount totalAddOnChargeAmount;
    @XmlElement(name = "TotalTaxAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal totalTaxAmount;
    @XmlElement(name = "TotalVATAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal totalVATAmount;
    @XmlElement(name = "TotalVatAmountAfterSamplingConstant", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal totalVatAmountAfterSamplingConstant;
    @XmlElement(name = "TotalAmountWithoutVAT", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal totalAmountWithoutVAT;
    @XmlElement(name = "TotalAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected TotalAmount totalAmount;
    @XmlElement(name = "TotalAmountInClearanceCurrency", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal totalAmountInClearanceCurrency;
    @XmlElement(name = "SamplingProvisionalAdjustmentDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected SamplingProvisionalAdjustmentDetails samplingProvisionalAdjustmentDetails;
    @XmlElement(name = "SamplingFormEDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected SamplingFormEDetails samplingFormEDetails;
    @XmlElement(name = "AttachmentCount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger attachmentCount;
    @XmlElement(name = "LegalText", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<String> legalText;

    /**
     * LineItemCount
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getLineItemCount() {
        return lineItemCount;
    }

    /**
     * Sets the value of the lineItemCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setLineItemCount(BigInteger value) {
        this.lineItemCount = value;
    }

    /**
     * Gets the value of the totalLineItemAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalLineItemAmount() {
        return totalLineItemAmount;
    }

    /**
     * Sets the value of the totalLineItemAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalLineItemAmount(BigDecimal value) {
        this.totalLineItemAmount = value;
    }

    /**
     * Gets the value of the tax property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tax property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTax().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Tax }
     * 
     * 
     */
    public List<Tax> getTax() {
        if (tax == null) {
            tax = new ArrayList<Tax>();
        }
        return this.tax;
    }

    /**
     * Gets the value of the addOnCharges property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addOnCharges property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddOnCharges().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvoiceSummary.AddOnCharges }
     * 
     * 
     */
    public List<InvoiceSummary.AddOnCharges> getAddOnCharges() {
        if (addOnCharges == null) {
            addOnCharges = new ArrayList<InvoiceSummary.AddOnCharges>();
        }
        return this.addOnCharges;
    }

    /**
     * Gets the value of the totalAddOnChargeAmount property.
     * 
     * @return
     *     possible object is
     *     {@link InvoiceSummary.TotalAddOnChargeAmount }
     *     
     */
    public InvoiceSummary.TotalAddOnChargeAmount getTotalAddOnChargeAmount() {
        return totalAddOnChargeAmount;
    }

    /**
     * Sets the value of the totalAddOnChargeAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link InvoiceSummary.TotalAddOnChargeAmount }
     *     
     */
    public void setTotalAddOnChargeAmount(InvoiceSummary.TotalAddOnChargeAmount value) {
        this.totalAddOnChargeAmount = value;
    }

    /**
     * Gets the value of the totalTaxAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalTaxAmount() {
        return totalTaxAmount;
    }

    /**
     * Sets the value of the totalTaxAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalTaxAmount(BigDecimal value) {
        this.totalTaxAmount = value;
    }

    /**
     * Gets the value of the totalVATAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalVATAmount() {
        return totalVATAmount;
    }

    /**
     * Sets the value of the totalVATAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalVATAmount(BigDecimal value) {
        this.totalVATAmount = value;
    }

    /**
     * Gets the value of the totalVatAmountAfterSamplingConstant property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalVatAmountAfterSamplingConstant() {
        return totalVatAmountAfterSamplingConstant;
    }

    /**
     * Sets the value of the totalVatAmountAfterSamplingConstant property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalVatAmountAfterSamplingConstant(BigDecimal value) {
        this.totalVatAmountAfterSamplingConstant = value;
    }

    /**
     * Gets the value of the totalAmountWithoutVAT property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalAmountWithoutVAT() {
        return totalAmountWithoutVAT;
    }

    /**
     * Sets the value of the totalAmountWithoutVAT property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalAmountWithoutVAT(BigDecimal value) {
        this.totalAmountWithoutVAT = value;
    }

    /**
     * Gets the value of the totalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link TotalAmount }
     *     
     */
    public TotalAmount getTotalAmount() {
        return totalAmount;
    }

    /**
     * Sets the value of the totalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link TotalAmount }
     *     
     */
    public void setTotalAmount(TotalAmount value) {
        this.totalAmount = value;
    }

    /**
     * Gets the value of the totalAmountInClearanceCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalAmountInClearanceCurrency() {
        return totalAmountInClearanceCurrency;
    }

    /**
     * Sets the value of the totalAmountInClearanceCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalAmountInClearanceCurrency(BigDecimal value) {
        this.totalAmountInClearanceCurrency = value;
    }

    /**
     * Gets the value of the samplingProvisionalAdjustmentDetails property.
     * 
     * @return
     *     possible object is
     *     {@link SamplingProvisionalAdjustmentDetails }
     *     
     */
    public SamplingProvisionalAdjustmentDetails getSamplingProvisionalAdjustmentDetails() {
        return samplingProvisionalAdjustmentDetails;
    }

    /**
     * Sets the value of the samplingProvisionalAdjustmentDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link SamplingProvisionalAdjustmentDetails }
     *     
     */
    public void setSamplingProvisionalAdjustmentDetails(SamplingProvisionalAdjustmentDetails value) {
        this.samplingProvisionalAdjustmentDetails = value;
    }

    /**
     * Gets the value of the samplingFormEDetails property.
     * 
     * @return
     *     possible object is
     *     {@link SamplingFormEDetails }
     *     
     */
    public SamplingFormEDetails getSamplingFormEDetails() {
        return samplingFormEDetails;
    }

    /**
     * Sets the value of the samplingFormEDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link SamplingFormEDetails }
     *     
     */
    public void setSamplingFormEDetails(SamplingFormEDetails value) {
        this.samplingFormEDetails = value;
    }

    /**
     * Gets the value of the attachmentCount property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAttachmentCount() {
        return attachmentCount;
    }

    /**
     * Sets the value of the attachmentCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAttachmentCount(BigInteger value) {
        this.attachmentCount = value;
    }

    /**
     * Gets the value of the legalText property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the legalText property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLegalText().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getLegalText() {
        if (legalText == null) {
            legalText = new ArrayList<String>();
        }
        return this.legalText;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnChargeName"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnChargeCode" minOccurs="0"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnChargePercentage" minOccurs="0"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnChargeableAmount" minOccurs="0"/>
     *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnChargeAmount"/>
     *         &lt;element name="ChargeForLineItemNos" type="{http://www.IATA.com/IATAAviationStandardDataTypes}AN700Base" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "addOnChargeName",
        "addOnChargeCode",
        "addOnChargePercentage",
        "addOnChargeableAmount",
        "addOnChargeAmount",
        "chargeForLineItemNos"
    })
    public static class AddOnCharges {

        @XmlElement(name = "AddOnChargeName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
        protected String addOnChargeName;
        @XmlElement(name = "AddOnChargeCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
        protected String addOnChargeCode;
        @XmlElement(name = "AddOnChargePercentage", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
        protected Object addOnChargePercentage;
        @XmlElement(name = "AddOnChargeableAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
        protected BigDecimal addOnChargeableAmount;
        @XmlElement(name = "AddOnChargeAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
        protected BigDecimal addOnChargeAmount;
        @XmlElement(name = "ChargeForLineItemNos", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
        protected String chargeForLineItemNos;

        /**
         * Gets the value of the addOnChargeName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAddOnChargeName() {
            return addOnChargeName;
        }

        /**
         * Sets the value of the addOnChargeName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAddOnChargeName(String value) {
            this.addOnChargeName = value;
        }

        /**
         * Gets the value of the addOnChargeCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAddOnChargeCode() {
            return addOnChargeCode;
        }

        /**
         * Sets the value of the addOnChargeCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAddOnChargeCode(String value) {
            this.addOnChargeCode = value;
        }

        /**
         * Gets the value of the addOnChargePercentage property.
         * 
         * @return
         *     possible object is
         *     {@link Object }
         *     
         */
        public Object getAddOnChargePercentage() {
            return addOnChargePercentage;
        }

        /**
         * Sets the value of the addOnChargePercentage property.
         * 
         * @param value
         *     allowed object is
         *     {@link Object }
         *     
         */
        public void setAddOnChargePercentage(Object value) {
            this.addOnChargePercentage = value;
        }

        /**
         * Gets the value of the addOnChargeableAmount property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getAddOnChargeableAmount() {
            return addOnChargeableAmount;
        }

        /**
         * Sets the value of the addOnChargeableAmount property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setAddOnChargeableAmount(BigDecimal value) {
            this.addOnChargeableAmount = value;
        }

        /**
         * Gets the value of the addOnChargeAmount property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getAddOnChargeAmount() {
            return addOnChargeAmount;
        }

        /**
         * Sets the value of the addOnChargeAmount property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setAddOnChargeAmount(BigDecimal value) {
            this.addOnChargeAmount = value;
        }

        /**
         * Gets the value of the chargeForLineItemNos property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getChargeForLineItemNos() {
            return chargeForLineItemNos;
        }

        /**
         * Sets the value of the chargeForLineItemNos property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setChargeForLineItemNos(String value) {
            this.chargeForLineItemNos = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class TotalAddOnChargeAmount {

        @XmlValue
        protected BigDecimal value;

        /**
         * Base used for numbers of type decimal(18,3)
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

    }

}
