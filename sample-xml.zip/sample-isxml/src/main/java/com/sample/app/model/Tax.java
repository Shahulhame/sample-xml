
package com.sample.app.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxRegistrationID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CountryCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CountryCode_ICAO" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SubdivisionCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxType"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxSubType" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxCategory" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxText" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxPercent" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxableAmount" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxAmount" maxOccurs="3" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxLevel" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxData" maxOccurs="10" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxBreakdown" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "taxRegistrationID",
    "countryCode",
    "countryCodeICAO",
    "subdivisionCode",
    "taxType",
    "taxSubType",
    "taxCategory",
    "taxText",
    "taxPercent",
    "taxableAmount",
    "taxAmount",
    "taxLevel",
    "taxData",
    "taxBreakdown"
})
@XmlRootElement(name = "Tax", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class Tax {

    @XmlElement(name = "TaxRegistrationID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String taxRegistrationID;
    @XmlElement(name = "CountryCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String countryCode;
    @XmlElement(name = "CountryCode_ICAO", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String countryCodeICAO;
    @XmlElement(name = "SubdivisionCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String subdivisionCode;
    @XmlElement(name = "TaxType", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    @XmlSchemaType(name = "string")
    protected TaxType taxType;
    @XmlElement(name = "TaxSubType", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String taxSubType;
    @XmlElement(name = "TaxCategory", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected TaxCategory taxCategory;
    @XmlElement(name = "TaxText", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String taxText;
    @XmlElement(name = "TaxPercent", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal taxPercent;
    @XmlElement(name = "TaxableAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal taxableAmount;
    @XmlElement(name = "TaxAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<TaxAmount> taxAmount;
    @XmlElement(name = "TaxLevel", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected TaxLevel taxLevel;
    @XmlElement(name = "TaxData", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<TaxData> taxData;
    @XmlElement(name = "TaxBreakdown", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<TaxBreakdown> taxBreakdown;

    /**
     * Gets the value of the taxRegistrationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxRegistrationID() {
        return taxRegistrationID;
    }

    /**
     * Sets the value of the taxRegistrationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxRegistrationID(String value) {
        this.taxRegistrationID = value;
    }

    /**
     * Gets the value of the countryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * Sets the value of the countryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryCode(String value) {
        this.countryCode = value;
    }

    /**
     * Gets the value of the countryCodeICAO property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryCodeICAO() {
        return countryCodeICAO;
    }

    /**
     * Sets the value of the countryCodeICAO property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryCodeICAO(String value) {
        this.countryCodeICAO = value;
    }

    /**
     * Gets the value of the subdivisionCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubdivisionCode() {
        return subdivisionCode;
    }

    /**
     * Sets the value of the subdivisionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubdivisionCode(String value) {
        this.subdivisionCode = value;
    }

    /**
     * Gets the value of the taxType property.
     * 
     * @return
     *     possible object is
     *     {@link TaxType }
     *     
     */
    public TaxType getTaxType() {
        return taxType;
    }

    /**
     * Sets the value of the taxType property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaxType }
     *     
     */
    public void setTaxType(TaxType value) {
        this.taxType = value;
    }

    /**
     * Gets the value of the taxSubType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxSubType() {
        return taxSubType;
    }

    /**
     * Sets the value of the taxSubType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxSubType(String value) {
        this.taxSubType = value;
    }

    /**
     * Gets the value of the taxCategory property.
     * 
     * @return
     *     possible object is
     *     {@link TaxCategory }
     *     
     */
    public TaxCategory getTaxCategory() {
        return taxCategory;
    }

    /**
     * Sets the value of the taxCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaxCategory }
     *     
     */
    public void setTaxCategory(TaxCategory value) {
        this.taxCategory = value;
    }

    /**
     * Gets the value of the taxText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxText() {
        return taxText;
    }

    /**
     * Sets the value of the taxText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxText(String value) {
        this.taxText = value;
    }

    /**
     * Gets the value of the taxPercent property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTaxPercent() {
        return taxPercent;
    }

    /**
     * Sets the value of the taxPercent property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTaxPercent(BigDecimal value) {
        this.taxPercent = value;
    }

    /**
     * Gets the value of the taxableAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTaxableAmount() {
        return taxableAmount;
    }

    /**
     * Sets the value of the taxableAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTaxableAmount(BigDecimal value) {
        this.taxableAmount = value;
    }

    /**
     * Gets the value of the taxAmount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the taxAmount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTaxAmount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TaxAmount }
     * 
     * 
     */
    public List<TaxAmount> getTaxAmount() {
        if (taxAmount == null) {
            taxAmount = new ArrayList<TaxAmount>();
        }
        return this.taxAmount;
    }

    /**
     * Gets the value of the taxLevel property.
     * 
     * @return
     *     possible object is
     *     {@link TaxLevel }
     *     
     */
    public TaxLevel getTaxLevel() {
        return taxLevel;
    }

    /**
     * Sets the value of the taxLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaxLevel }
     *     
     */
    public void setTaxLevel(TaxLevel value) {
        this.taxLevel = value;
    }

    /**
     * Gets the value of the taxData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the taxData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTaxData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TaxData }
     * 
     * 
     */
    public List<TaxData> getTaxData() {
        if (taxData == null) {
            taxData = new ArrayList<TaxData>();
        }
        return this.taxData;
    }

    /**
     * Gets the value of the taxBreakdown property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the taxBreakdown property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTaxBreakdown().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TaxBreakdown }
     * 
     * 
     */
    public List<TaxBreakdown> getTaxBreakdown() {
        if (taxBreakdown == null) {
            taxBreakdown = new ArrayList<TaxBreakdown>();
        }
        return this.taxBreakdown;
    }

}
