
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LocationCode_XXXX-Type-Values.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="LocationCode_XXXX-Type-Values">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="Origin"/>
 *     &lt;enumeration value="Destination"/>
 *     &lt;enumeration value="FirstPortOfCall"/>
 *     &lt;enumeration value="LastPortOfCall"/>
 *     &lt;enumeration value="Intermediate"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "LocationCode_XXXX-Type-Values", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum LocationCodeXXXXTypeValues {

    @XmlEnumValue("Origin")
    ORIGIN("Origin"),
    @XmlEnumValue("Destination")
    DESTINATION("Destination"),
    @XmlEnumValue("FirstPortOfCall")
    FIRST_PORT_OF_CALL("FirstPortOfCall"),
    @XmlEnumValue("LastPortOfCall")
    LAST_PORT_OF_CALL("LastPortOfCall"),
    @XmlEnumValue("Intermediate")
    INTERMEDIATE("Intermediate");
    private final String value;

    LocationCodeXXXXTypeValues(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static LocationCodeXXXXTypeValues fromValue(String v) {
        for (LocationCodeXXXXTypeValues c: LocationCodeXXXXTypeValues.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
