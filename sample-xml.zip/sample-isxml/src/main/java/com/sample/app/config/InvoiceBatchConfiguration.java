package com.sample.app.config;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.hibernate.annotations.Parent;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.support.ClassifierCompositeItemProcessor;
import org.springframework.batch.item.support.ClassifierCompositeItemWriter;
import org.springframework.batch.item.xml.StaxEventItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.classify.Classifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.transaction.PlatformTransactionManager;

import com.sample.app.listener.JobCompletionNotificationListener;
import com.sample.app.model.BaseModel;
import com.sample.app.model.TransmissionHeaderModel;
import com.sample.app.model.TransmissionSummary;
import com.sample.app.repository.entity.BaseEntity;
import com.sample.app.repository.entity.MiscBillingInvTransSummary;
import com.sample.app.repository.entity.TransmissionHeaderEntity;
import com.sample.app.writer.TransmissionHeaderWriter;
import com.sample.app.writer.TransmissionSummaryWriter;

@Configuration
@EnableBatchProcessing
@EntityScan("com.sgl.smartpra.batch.iata.invoice.app")
@EnableJpaRepositories(basePackages = "com.sgl.smartpra.batch.iata.invoice.app.repository")
@ComponentScan({ "com.sgl.smartpra.batch.iata.invoice.app" })
@EnableAutoConfiguration
public class InvoiceBatchConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	
	@Autowired
	EntityManagerFactory emf;
	
	@Autowired
	PlatformTransactionManager transactionManager;

	
	

	@Bean
    public Job importIataInvoiceJob(JobCompletionNotificationListener listener, Step importData) {
        return jobBuilderFactory
                .get("importIataInvoiceJob")
                .incrementer(new RunIdIncrementer())
                .listener(listener)
                .flow(importData)
                .end()
                .build();
    }

    
    @Bean
    public Step importData() throws ClassNotFoundException {
                 return stepBuilderFactory
        		.get("step1")
                .<BaseModel, BaseEntity>chunk(100)
                .reader(invoiceItemReader())
                .processor((ItemProcessor<? super BaseModel, ? extends BaseEntity>) invoiceItemProcessor())
                .writer(isxmlWriter(transmissonHeaderWriter(),transmissonSummaryWriter()))
                .transactionManager(transactionManager)
                .build();
    }
	
	
	
	@Bean
	public StaxEventItemReader<BaseModel> invoiceItemReader() throws ClassNotFoundException {

		XStreamMarshaller unmarshaller = new XStreamMarshaller();

		Map<String, Class> aliases = new HashMap<>();
		aliases.put("TransmissionHeader", TransmissionHeaderModel.class);
		aliases.put("TransmissionSummary", TransmissionSummary.class);

		unmarshaller.setAliases(aliases);

		StaxEventItemReader<BaseModel> reader = new StaxEventItemReader<>();

		reader.setResource(new ClassPathResource("/data/MXMLT-A8920180801_Isxxml.xml"));
		String[] fragmentNames = {"TransmissionHeader","TransmissionSummary"};
		reader.setFragmentRootElementNames(fragmentNames);
		reader.setUnmarshaller(unmarshaller);

		return reader;

	}
    


	@Bean
	public ClassifierCompositeItemProcessor<? super BaseModel, ? extends BaseEntity> invoiceItemProcessor() {
		ClassifierCompositeItemProcessor<BaseModel, BaseEntity> classifierCompositeItemProcessor = new ClassifierCompositeItemProcessor<>();
		classifierCompositeItemProcessor.setClassifier(classifiable -> classifiable.processor());
		return classifierCompositeItemProcessor;

	}
	
	@Bean
	public ItemWriter<BaseEntity> transmissonHeaderWriter() {
		return new TransmissionHeaderWriter<>();
	}
	
	@Bean
	public ItemWriter<BaseEntity> transmissonSummaryWriter() {
		return new TransmissionSummaryWriter<>();
	}
	
	@Bean
	public ClassifierCompositeItemWriter<BaseEntity> isxmlWriter(
			ItemWriter<BaseEntity> transmissonHeaderWriter,
			ItemWriter<BaseEntity> transmissonSummaryWriter
			){
		ClassifierCompositeItemWriter<BaseEntity> classifierCompositeItemWriter = new ClassifierCompositeItemWriter<>();
		classifierCompositeItemWriter.setClassifier(new Classifier<BaseEntity, ItemWriter<? super BaseEntity>>() {
			
			
			@Override
			public ItemWriter<BaseEntity> classify(BaseEntity classifiable) {
				if (classifiable  instanceof TransmissionHeaderEntity) {
					return transmissonHeaderWriter;
				} else if (classifiable instanceof MiscBillingInvTransSummary) {
					return transmissonSummaryWriter;
				}

				return null;
			}
		});
		return classifierCompositeItemWriter;
			

	}
}

	
