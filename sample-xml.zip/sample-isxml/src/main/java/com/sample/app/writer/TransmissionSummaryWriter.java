package com.sample.app.writer;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sample.app.repository.TransmissionSummaryRepository;
import com.sample.app.repository.entity.BaseEntity;
import com.sample.app.repository.entity.MiscBillingInvTransSummary;

@Component
public class TransmissionSummaryWriter<T extends BaseEntity> implements ItemWriter<BaseEntity> {

	@Autowired
	private TransmissionSummaryRepository transmissionSummaryRepository;

	@SuppressWarnings("unchecked")
	@Override
	public void write(List<? extends BaseEntity> items) throws Exception {
		System.out.println("Repository Values-->" + transmissionSummaryRepository);
		System.out.println("Inside Writer" + items);
		transmissionSummaryRepository.saveAll((List<MiscBillingInvTransSummary>)  items);

	}
}
