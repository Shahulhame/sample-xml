
package com.sample.app.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="FlightNo" type="{http://www.IATA.com/IATAAviationStandardDataTypes}AN08Base" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}FlightDateTime" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}FlightDirection" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}FlightTypeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}FlightZone" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SimulatorNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PassengerCount" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}BagCount" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "flightNo",
    "flightDateTime",
    "flightDirection",
    "flightTypeCode",
    "flightZone",
    "simulatorNo",
    "passengerCount",
    "bagCount"
})
@XmlRootElement(name = "FlightDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class FlightDetails {

    @XmlElement(name = "FlightNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String flightNo;
    @XmlElement(name = "FlightDateTime", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String flightDateTime;
    @XmlElement(name = "FlightDirection", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String flightDirection;
    @XmlElement(name = "FlightTypeCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String flightTypeCode;
    @XmlElement(name = "FlightZone", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String flightZone;
    @XmlElement(name = "SimulatorNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String simulatorNo;
    @XmlElement(name = "PassengerCount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<PassengerCount> passengerCount;
    @XmlElement(name = "BagCount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<BagCount> bagCount;

    /**
     * Gets the value of the flightNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlightNo() {
        return flightNo;
    }

    /**
     * Sets the value of the flightNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlightNo(String value) {
        this.flightNo = value;
    }

    /**
     * Gets the value of the flightDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlightDateTime() {
        return flightDateTime;
    }

    /**
     * Sets the value of the flightDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlightDateTime(String value) {
        this.flightDateTime = value;
    }

    /**
     * Gets the value of the flightDirection property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlightDirection() {
        return flightDirection;
    }

    /**
     * Sets the value of the flightDirection property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlightDirection(String value) {
        this.flightDirection = value;
    }

    /**
     * Gets the value of the flightTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlightTypeCode() {
        return flightTypeCode;
    }

    /**
     * Sets the value of the flightTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlightTypeCode(String value) {
        this.flightTypeCode = value;
    }

    /**
     * Gets the value of the flightZone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlightZone() {
        return flightZone;
    }

    /**
     * Sets the value of the flightZone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlightZone(String value) {
        this.flightZone = value;
    }

    /**
     * Gets the value of the simulatorNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSimulatorNo() {
        return simulatorNo;
    }

    /**
     * Sets the value of the simulatorNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSimulatorNo(String value) {
        this.simulatorNo = value;
    }

    /**
     * Gets the value of the passengerCount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the passengerCount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPassengerCount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PassengerCount }
     * 
     * 
     */
    public List<PassengerCount> getPassengerCount() {
        if (passengerCount == null) {
            passengerCount = new ArrayList<PassengerCount>();
        }
        return this.passengerCount;
    }

    /**
     * Gets the value of the bagCount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bagCount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBagCount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BagCount }
     * 
     * 
     */
    public List<BagCount> getBagCount() {
        if (bagCount == null) {
            bagCount = new ArrayList<BagCount>();
        }
        return this.bagCount;
    }

}
