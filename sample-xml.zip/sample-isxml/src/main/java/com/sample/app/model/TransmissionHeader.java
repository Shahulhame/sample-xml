package com.sample.app.model;
/*
package com.sgl.smartpra.batch.iata.invoice.app.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.springframework.batch.item.ItemProcessor;

import com.sgl.smartpra.batch.iata.invoice.app.processor.TransmissonHeaderItemProcessor;
import com.sgl.smartpra.batch.iata.invoice.app.repository.entity.MiscBillingInvTransHeaderEntity;

*//**
 * <p>
 * Java class for anonymous complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TransmissionDateTime"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Version"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TransmissionID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}IssuingOrganizationID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ReceivingOrganizationID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}BillingCategory" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TransmissionData" maxOccurs="20" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 *//*
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "transmissionDateTime", "version", "transmissionID", "issuingOrganizationID",
		"receivingOrganizationID", "billingCategory", "transmissionData" })
@XmlRootElement(name = "TransmissionHeader", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class TransmissionHeader extends BaseModel {

	@XmlElement(name = "TransmissionDateTime", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
	protected String transmissionDateTime;
	@XmlElement(name = "Version", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
	protected String version;
	@XmlElement(name = "TransmissionID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
	protected String transmissionID;
	@XmlElement(name = "IssuingOrganizationID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
	protected String issuingOrganizationID;
	@XmlElement(name = "ReceivingOrganizationID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
	protected String receivingOrganizationID;
	@XmlElement(name = "BillingCategory", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
	protected String billingCategory;
	@XmlElement(name = "TransmissionData", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
	protected List<TransmissionData> transmissionData;

	*//**
	 * Gets the value of the transmissionDateTime property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 *//*
	public String getTransmissionDateTime() {
		return transmissionDateTime;
	}

	*//**
	 * Sets the value of the transmissionDateTime property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 *//*
	public void setTransmissionDateTime(String value) {
		this.transmissionDateTime = value;
	}

	*//**
	 * Gets the value of the version property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 *//*
	public String getVersion() {
		return version;
	}

	*//**
	 * Sets the value of the version property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 *//*
	public void setVersion(String value) {
		this.version = value;
	}

	*//**
	 * Gets the value of the transmissionID property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 *//*
	public String getTransmissionID() {
		return transmissionID;
	}

	*//**
	 * Sets the value of the transmissionID property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 *//*
	public void setTransmissionID(String value) {
		this.transmissionID = value;
	}

	*//**
	 * Gets the value of the issuingOrganizationID property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 *//*
	public String getIssuingOrganizationID() {
		return issuingOrganizationID;
	}

	*//**
	 * Sets the value of the issuingOrganizationID property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 *//*
	public void setIssuingOrganizationID(String value) {
		this.issuingOrganizationID = value;
	}

	*//**
	 * Gets the value of the receivingOrganizationID property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 *//*
	public String getReceivingOrganizationID() {
		return receivingOrganizationID;
	}

	*//**
	 * Sets the value of the receivingOrganizationID property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 *//*
	public void setReceivingOrganizationID(String value) {
		this.receivingOrganizationID = value;
	}

	*//**
	 * Gets the value of the billingCategory property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 *//*
	public String getBillingCategory() {
		return billingCategory;
	}

	*//**
	 * Sets the value of the billingCategory property.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 *//*
	public void setBillingCategory(String value) {
		this.billingCategory = value;
	}

	*//**
	 * Gets the value of the transmissionData property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot.
	 * Therefore any modification you make to the returned list will be present
	 * inside the JAXB object. This is why there is not a <CODE>set</CODE> method
	 * for the transmissionData property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getTransmissionData().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list
	 * {@link TransmissionData }
	 * 
	 * 
	 *//*
	public List<TransmissionData> getTransmissionData() {
		if (transmissionData == null) {
			transmissionData = new ArrayList<TransmissionData>();
		}
		return this.transmissionData;
	}

	@Override
	public ItemProcessor<? extends TransmissionHeader, ? extends MiscBillingInvTransHeaderEntity> processor() {

		return new TransmissonHeaderItemProcessor();
	}

	@Override
	public String toString() {
		return "TransmissionHeader [transmissionDateTime=" + transmissionDateTime + ", version=" + version
				+ ", transmissionID=" + transmissionID + ", issuingOrganizationID=" + issuingOrganizationID
				+ ", receivingOrganizationID=" + receivingOrganizationID + ", billingCategory=" + billingCategory
				+ ", transmissionData=" + transmissionData + "]";
	}
	
	
}
*/