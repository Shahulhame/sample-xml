
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ChargeCodeCargo.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ChargeCodeCargo">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="Prepaid AirWaybill"/>
 *     &lt;enumeration value="Collect AirWaybill"/>
 *     &lt;enumeration value="Rejection Memo"/>
 *     &lt;enumeration value="Billing Memo"/>
 *     &lt;enumeration value="Credit Memo"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ChargeCodeCargo", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum ChargeCodeCargo {

    @XmlEnumValue("Prepaid AirWaybill")
    PREPAID_AIR_WAYBILL("Prepaid AirWaybill"),
    @XmlEnumValue("Collect AirWaybill")
    COLLECT_AIR_WAYBILL("Collect AirWaybill"),
    @XmlEnumValue("Rejection Memo")
    REJECTION_MEMO("Rejection Memo"),
    @XmlEnumValue("Billing Memo")
    BILLING_MEMO("Billing Memo"),
    @XmlEnumValue("Credit Memo")
    CREDIT_MEMO("Credit Memo");
    private final String value;

    ChargeCodeCargo(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ChargeCodeCargo fromValue(String v) {
        for (ChargeCodeCargo c: ChargeCodeCargo.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
