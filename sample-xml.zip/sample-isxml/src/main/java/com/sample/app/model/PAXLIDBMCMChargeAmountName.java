
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PAX-LID-BMCM-ChargeAmount-Name.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PAX-LID-BMCM-ChargeAmount-Name">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="GrossBilled"/>
 *     &lt;enumeration value="GrossCredited"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PAX-LID-BMCM-ChargeAmount-Name", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum PAXLIDBMCMChargeAmountName {

    @XmlEnumValue("GrossBilled")
    GROSS_BILLED("GrossBilled"),
    @XmlEnumValue("GrossCredited")
    GROSS_CREDITED("GrossCredited");
    private final String value;

    PAXLIDBMCMChargeAmountName(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PAXLIDBMCMChargeAmountName fromValue(String v) {
        for (PAXLIDBMCMChargeAmountName c: PAXLIDBMCMChargeAmountName.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
