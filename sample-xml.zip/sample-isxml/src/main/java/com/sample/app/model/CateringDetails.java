
package com.sample.app.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}MealType" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}InvoiceOpCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}InvoiceDbsDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ServiceFlightNbr" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ServiceFlightDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}BoardFlightDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}BoardFlightNbr" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Facility" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}MealCode" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "mealType",
    "invoiceOpCode",
    "invoiceDbsDate",
    "serviceFlightNbr",
    "serviceFlightDate",
    "boardFlightDate",
    "boardFlightNbr",
    "facility",
    "mealCode"
})
@XmlRootElement(name = "CateringDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class CateringDetails {

    @XmlElement(name = "MealType", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected MealType mealType;
    @XmlElement(name = "InvoiceOpCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String invoiceOpCode;
    @XmlElement(name = "InvoiceDbsDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String invoiceDbsDate;
    @XmlElement(name = "ServiceFlightNbr", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String serviceFlightNbr;
    @XmlElement(name = "ServiceFlightDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String serviceFlightDate;
    @XmlElement(name = "BoardFlightDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String boardFlightDate;
    @XmlElement(name = "BoardFlightNbr", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String boardFlightNbr;
    @XmlElement(name = "Facility", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String facility;
    @XmlElement(name = "MealCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String mealCode;

    /**
     * Gets the value of the mealType property.
     * 
     * @return
     *     possible object is
     *     {@link MealType }
     *     
     */
    public MealType getMealType() {
        return mealType;
    }

    /**
     * Sets the value of the mealType property.
     * 
     * @param value
     *     allowed object is
     *     {@link MealType }
     *     
     */
    public void setMealType(MealType value) {
        this.mealType = value;
    }

    /**
     * Gets the value of the invoiceOpCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvoiceOpCode() {
        return invoiceOpCode;
    }

    /**
     * Sets the value of the invoiceOpCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvoiceOpCode(String value) {
        this.invoiceOpCode = value;
    }

    /**
     * Gets the value of the invoiceDbsDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvoiceDbsDate() {
        return invoiceDbsDate;
    }

    /**
     * Sets the value of the invoiceDbsDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvoiceDbsDate(String value) {
        this.invoiceDbsDate = value;
    }

    /**
     * Gets the value of the serviceFlightNbr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceFlightNbr() {
        return serviceFlightNbr;
    }

    /**
     * Sets the value of the serviceFlightNbr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceFlightNbr(String value) {
        this.serviceFlightNbr = value;
    }

    /**
     * Gets the value of the serviceFlightDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceFlightDate() {
        return serviceFlightDate;
    }

    /**
     * Sets the value of the serviceFlightDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceFlightDate(String value) {
        this.serviceFlightDate = value;
    }

    /**
     * Gets the value of the boardFlightDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBoardFlightDate() {
        return boardFlightDate;
    }

    /**
     * Sets the value of the boardFlightDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBoardFlightDate(String value) {
        this.boardFlightDate = value;
    }

    /**
     * Gets the value of the boardFlightNbr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBoardFlightNbr() {
        return boardFlightNbr;
    }

    /**
     * Sets the value of the boardFlightNbr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBoardFlightNbr(String value) {
        this.boardFlightNbr = value;
    }

    /**
     * Gets the value of the facility property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFacility() {
        return facility;
    }

    /**
     * Sets the value of the facility property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFacility(String value) {
        this.facility = value;
    }

    /**
     * Gets the value of the mealCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMealCode() {
        return mealCode;
    }

    /**
     * Sets the value of the mealCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMealCode(String value) {
        this.mealCode = value;
    }

}
