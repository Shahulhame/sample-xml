
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ChargeBasis.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ChargeBasis">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="Aircraft"/>
 *     &lt;enumeration value="Passenger"/>
 *     &lt;enumeration value="Flight"/>
 *     &lt;enumeration value="Parking"/>
 *     &lt;enumeration value="Distance"/>
 *     &lt;enumeration value="Bag"/>
 *     &lt;enumeration value="Employee"/>
 *     &lt;enumeration value="Area"/>
 *     &lt;enumeration value="Desk-Gate"/>
 *     &lt;enumeration value="Consumption"/>
 *     &lt;enumeration value="Misc"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ChargeBasis", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum ChargeBasis {

    @XmlEnumValue("Aircraft")
    AIRCRAFT("Aircraft"),
    @XmlEnumValue("Passenger")
    PASSENGER("Passenger"),
    @XmlEnumValue("Flight")
    FLIGHT("Flight"),
    @XmlEnumValue("Parking")
    PARKING("Parking"),
    @XmlEnumValue("Distance")
    DISTANCE("Distance"),
    @XmlEnumValue("Bag")
    BAG("Bag"),
    @XmlEnumValue("Employee")
    EMPLOYEE("Employee"),
    @XmlEnumValue("Area")
    AREA("Area"),
    @XmlEnumValue("Desk-Gate")
    DESK_GATE("Desk-Gate"),
    @XmlEnumValue("Consumption")
    CONSUMPTION("Consumption"),
    @XmlEnumValue("Misc")
    MISC("Misc");
    private final String value;

    ChargeBasis(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ChargeBasis fromValue(String v) {
        for (ChargeBasis c: ChargeBasis.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
