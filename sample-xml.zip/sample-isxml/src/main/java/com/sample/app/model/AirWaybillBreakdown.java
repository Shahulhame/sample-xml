
package com.sample.app.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}BreakdownSerialNumber"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AWBDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}BillingCode"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AWBIssuingAirline"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AWBSerialNumber"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AWBCheckDigit"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ChargeAmount" maxOccurs="6" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Tax" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnCharges" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TotalNetAmount"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OriginAirportCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DestinationAirportCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}FromAirportCode"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ToAirportOrPointOfTransferCode"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DateOfCarriageOrTransfer"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CurrAdjustmentIndicator" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}BilledWeight" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisoReqSPA" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProratePercentage" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PartShipmentIndicator" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}KgLbIndicator" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CCAIndicator" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ReasonCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ISValidationFlag" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ReferenceField10AN" maxOccurs="4" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ReferenceField20AN" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AirlineOwnUse20AN" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProrateLadderBreakdown" maxOccurs="80" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Attachment" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "breakdownSerialNumber",
    "awbDate",
    "billingCode",
    "awbIssuingAirline",
    "awbSerialNumber",
    "awbCheckDigit",
    "chargeAmount",
    "tax",
    "addOnCharges",
    "totalNetAmount",
    "originAirportCode",
    "destinationAirportCode",
    "fromAirportCode",
    "toAirportOrPointOfTransferCode",
    "dateOfCarriageOrTransfer",
    "currAdjustmentIndicator",
    "billedWeight",
    "provisoReqSPA",
    "proratePercentage",
    "partShipmentIndicator",
    "kgLbIndicator",
    "ccaIndicator",
    "reasonCode",
    "isValidationFlag",
    "referenceField10AN",
    "referenceField20AN",
    "airlineOwnUse20AN",
    "prorateLadderBreakdown",
    "attachment"
})
@XmlRootElement(name = "AirWaybillBreakdown", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class AirWaybillBreakdown {

    @XmlElement(name = "BreakdownSerialNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigInteger breakdownSerialNumber;
    @XmlElement(name = "AWBDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String awbDate;
    @XmlElement(name = "BillingCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    @XmlSchemaType(name = "string")
    protected BillingCode billingCode;
    @XmlElement(name = "AWBIssuingAirline", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigInteger awbIssuingAirline;
    @XmlElement(name = "AWBSerialNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String awbSerialNumber;
    @XmlElement(name = "AWBCheckDigit", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigInteger awbCheckDigit;
    @XmlElement(name = "ChargeAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<ChargeAmount> chargeAmount;
    @XmlElement(name = "Tax", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<Tax> tax;
    @XmlElement(name = "AddOnCharges", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<AddOnCharges> addOnCharges;
    @XmlElement(name = "TotalNetAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigDecimal totalNetAmount;
    @XmlElement(name = "OriginAirportCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String originAirportCode;
    @XmlElement(name = "DestinationAirportCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String destinationAirportCode;
    @XmlElement(name = "FromAirportCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String fromAirportCode;
    @XmlElement(name = "ToAirportOrPointOfTransferCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String toAirportOrPointOfTransferCode;
    @XmlElement(name = "DateOfCarriageOrTransfer", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String dateOfCarriageOrTransfer;
    @XmlElement(name = "CurrAdjustmentIndicator", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String currAdjustmentIndicator;
    @XmlElement(name = "BilledWeight", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger billedWeight;
    @XmlElement(name = "ProvisoReqSPA", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected ProvisoReqSPA provisoReqSPA;
    @XmlElement(name = "ProratePercentage", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger proratePercentage;
    @XmlElement(name = "PartShipmentIndicator", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected PartShipmentIndicator partShipmentIndicator;
    @XmlElement(name = "KgLbIndicator", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected KgLbIndicator kgLbIndicator;
    @XmlElement(name = "CCAIndicator", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected BooleanFlag ccaIndicator;
    @XmlElement(name = "ReasonCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String reasonCode;
    @XmlElement(name = "ISValidationFlag", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String isValidationFlag;
    @XmlElement(name = "ReferenceField10AN", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<String> referenceField10AN;
    @XmlElement(name = "ReferenceField20AN", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String referenceField20AN;
    @XmlElement(name = "AirlineOwnUse20AN", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String airlineOwnUse20AN;
    @XmlElement(name = "ProrateLadderBreakdown", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<ProrateLadderBreakdown> prorateLadderBreakdown;
    @XmlElement(name = "Attachment", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<Attachment> attachment;

    /**
     * Gets the value of the breakdownSerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getBreakdownSerialNumber() {
        return breakdownSerialNumber;
    }

    /**
     * Sets the value of the breakdownSerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setBreakdownSerialNumber(BigInteger value) {
        this.breakdownSerialNumber = value;
    }

    /**
     * Gets the value of the awbDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAWBDate() {
        return awbDate;
    }

    /**
     * Sets the value of the awbDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAWBDate(String value) {
        this.awbDate = value;
    }

    /**
     * BillingCode
     * 
     * @return
     *     possible object is
     *     {@link BillingCode }
     *     
     */
    public BillingCode getBillingCode() {
        return billingCode;
    }

    /**
     * Sets the value of the billingCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link BillingCode }
     *     
     */
    public void setBillingCode(BillingCode value) {
        this.billingCode = value;
    }

    /**
     * Gets the value of the awbIssuingAirline property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAWBIssuingAirline() {
        return awbIssuingAirline;
    }

    /**
     * Sets the value of the awbIssuingAirline property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAWBIssuingAirline(BigInteger value) {
        this.awbIssuingAirline = value;
    }

    /**
     * Gets the value of the awbSerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAWBSerialNumber() {
        return awbSerialNumber;
    }

    /**
     * Sets the value of the awbSerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAWBSerialNumber(String value) {
        this.awbSerialNumber = value;
    }

    /**
     * Gets the value of the awbCheckDigit property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAWBCheckDigit() {
        return awbCheckDigit;
    }

    /**
     * Sets the value of the awbCheckDigit property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAWBCheckDigit(BigInteger value) {
        this.awbCheckDigit = value;
    }

    /**
     * Gets the value of the chargeAmount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the chargeAmount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getChargeAmount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ChargeAmount }
     * 
     * 
     */
    public List<ChargeAmount> getChargeAmount() {
        if (chargeAmount == null) {
            chargeAmount = new ArrayList<ChargeAmount>();
        }
        return this.chargeAmount;
    }

    /**
     * Gets the value of the tax property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tax property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTax().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Tax }
     * 
     * 
     */
    public List<Tax> getTax() {
        if (tax == null) {
            tax = new ArrayList<Tax>();
        }
        return this.tax;
    }

    /**
     * Gets the value of the addOnCharges property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addOnCharges property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddOnCharges().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AddOnCharges }
     * 
     * 
     */
    public List<AddOnCharges> getAddOnCharges() {
        if (addOnCharges == null) {
            addOnCharges = new ArrayList<AddOnCharges>();
        }
        return this.addOnCharges;
    }

    /**
     * Gets the value of the totalNetAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalNetAmount() {
        return totalNetAmount;
    }

    /**
     * Sets the value of the totalNetAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalNetAmount(BigDecimal value) {
        this.totalNetAmount = value;
    }

    /**
     * Gets the value of the originAirportCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginAirportCode() {
        return originAirportCode;
    }

    /**
     * Sets the value of the originAirportCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginAirportCode(String value) {
        this.originAirportCode = value;
    }

    /**
     * Gets the value of the destinationAirportCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationAirportCode() {
        return destinationAirportCode;
    }

    /**
     * Sets the value of the destinationAirportCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationAirportCode(String value) {
        this.destinationAirportCode = value;
    }

    /**
     * Gets the value of the fromAirportCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFromAirportCode() {
        return fromAirportCode;
    }

    /**
     * Sets the value of the fromAirportCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFromAirportCode(String value) {
        this.fromAirportCode = value;
    }

    /**
     * Gets the value of the toAirportOrPointOfTransferCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToAirportOrPointOfTransferCode() {
        return toAirportOrPointOfTransferCode;
    }

    /**
     * Sets the value of the toAirportOrPointOfTransferCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToAirportOrPointOfTransferCode(String value) {
        this.toAirportOrPointOfTransferCode = value;
    }

    /**
     * Gets the value of the dateOfCarriageOrTransfer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateOfCarriageOrTransfer() {
        return dateOfCarriageOrTransfer;
    }

    /**
     * Sets the value of the dateOfCarriageOrTransfer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateOfCarriageOrTransfer(String value) {
        this.dateOfCarriageOrTransfer = value;
    }

    /**
     * Gets the value of the currAdjustmentIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrAdjustmentIndicator() {
        return currAdjustmentIndicator;
    }

    /**
     * Sets the value of the currAdjustmentIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrAdjustmentIndicator(String value) {
        this.currAdjustmentIndicator = value;
    }

    /**
     * Gets the value of the billedWeight property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getBilledWeight() {
        return billedWeight;
    }

    /**
     * Sets the value of the billedWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setBilledWeight(BigInteger value) {
        this.billedWeight = value;
    }

    /**
     * Gets the value of the provisoReqSPA property.
     * 
     * @return
     *     possible object is
     *     {@link ProvisoReqSPA }
     *     
     */
    public ProvisoReqSPA getProvisoReqSPA() {
        return provisoReqSPA;
    }

    /**
     * Sets the value of the provisoReqSPA property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProvisoReqSPA }
     *     
     */
    public void setProvisoReqSPA(ProvisoReqSPA value) {
        this.provisoReqSPA = value;
    }

    /**
     * Gets the value of the proratePercentage property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getProratePercentage() {
        return proratePercentage;
    }

    /**
     * Sets the value of the proratePercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setProratePercentage(BigInteger value) {
        this.proratePercentage = value;
    }

    /**
     * Gets the value of the partShipmentIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link PartShipmentIndicator }
     *     
     */
    public PartShipmentIndicator getPartShipmentIndicator() {
        return partShipmentIndicator;
    }

    /**
     * Sets the value of the partShipmentIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartShipmentIndicator }
     *     
     */
    public void setPartShipmentIndicator(PartShipmentIndicator value) {
        this.partShipmentIndicator = value;
    }

    /**
     * Gets the value of the kgLbIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link KgLbIndicator }
     *     
     */
    public KgLbIndicator getKgLbIndicator() {
        return kgLbIndicator;
    }

    /**
     * Sets the value of the kgLbIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link KgLbIndicator }
     *     
     */
    public void setKgLbIndicator(KgLbIndicator value) {
        this.kgLbIndicator = value;
    }

    /**
     * Gets the value of the ccaIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link BooleanFlag }
     *     
     */
    public BooleanFlag getCCAIndicator() {
        return ccaIndicator;
    }

    /**
     * Sets the value of the ccaIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link BooleanFlag }
     *     
     */
    public void setCCAIndicator(BooleanFlag value) {
        this.ccaIndicator = value;
    }

    /**
     * Gets the value of the reasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonCode() {
        return reasonCode;
    }

    /**
     * Sets the value of the reasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonCode(String value) {
        this.reasonCode = value;
    }

    /**
     * Gets the value of the isValidationFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISValidationFlag() {
        return isValidationFlag;
    }

    /**
     * Sets the value of the isValidationFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISValidationFlag(String value) {
        this.isValidationFlag = value;
    }

    /**
     * Gets the value of the referenceField10AN property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the referenceField10AN property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReferenceField10AN().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getReferenceField10AN() {
        if (referenceField10AN == null) {
            referenceField10AN = new ArrayList<String>();
        }
        return this.referenceField10AN;
    }

    /**
     * Gets the value of the referenceField20AN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferenceField20AN() {
        return referenceField20AN;
    }

    /**
     * Sets the value of the referenceField20AN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferenceField20AN(String value) {
        this.referenceField20AN = value;
    }

    /**
     * Gets the value of the airlineOwnUse20AN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAirlineOwnUse20AN() {
        return airlineOwnUse20AN;
    }

    /**
     * Sets the value of the airlineOwnUse20AN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAirlineOwnUse20AN(String value) {
        this.airlineOwnUse20AN = value;
    }

    /**
     * Gets the value of the prorateLadderBreakdown property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the prorateLadderBreakdown property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProrateLadderBreakdown().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProrateLadderBreakdown }
     * 
     * 
     */
    public List<ProrateLadderBreakdown> getProrateLadderBreakdown() {
        if (prorateLadderBreakdown == null) {
            prorateLadderBreakdown = new ArrayList<ProrateLadderBreakdown>();
        }
        return this.prorateLadderBreakdown;
    }

    /**
     * Gets the value of the attachment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the attachment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAttachment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Attachment }
     * 
     * 
     */
    public List<Attachment> getAttachment() {
        if (attachment == null) {
            attachment = new ArrayList<Attachment>();
        }
        return this.attachment;
    }

}
