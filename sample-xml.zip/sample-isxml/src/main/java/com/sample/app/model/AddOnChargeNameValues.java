
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddOnChargeName-Values.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AddOnChargeName-Values">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN30Base">
 *     &lt;enumeration value="ISCAllowed"/>
 *     &lt;enumeration value="ISCAccepted"/>
 *     &lt;enumeration value="ISCDifference"/>
 *     &lt;enumeration value="OtherCommissionAllowed"/>
 *     &lt;enumeration value="OtherCommissionAccepted"/>
 *     &lt;enumeration value="OtherCommissionDifference"/>
 *     &lt;enumeration value="UATPAllowed"/>
 *     &lt;enumeration value="UATPAccepted"/>
 *     &lt;enumeration value="UATPDifference"/>
 *     &lt;enumeration value="HandlingFeeAllowed"/>
 *     &lt;enumeration value="HandlingFeeAccepted"/>
 *     &lt;enumeration value="HandlingFeeDifference"/>
 *     &lt;enumeration value="OtherChargesAllowed"/>
 *     &lt;enumeration value="OtherChargesAccepted"/>
 *     &lt;enumeration value="OtherChargesDifference"/>
 *     &lt;enumeration value="AmountSubjectToISCAllowed"/>
 *     &lt;enumeration value="AmountSubjectToISCAccepted"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "AddOnChargeName-Values", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum AddOnChargeNameValues {

    @XmlEnumValue("ISCAllowed")
    ISC_ALLOWED("ISCAllowed"),
    @XmlEnumValue("ISCAccepted")
    ISC_ACCEPTED("ISCAccepted"),
    @XmlEnumValue("ISCDifference")
    ISC_DIFFERENCE("ISCDifference"),
    @XmlEnumValue("OtherCommissionAllowed")
    OTHER_COMMISSION_ALLOWED("OtherCommissionAllowed"),
    @XmlEnumValue("OtherCommissionAccepted")
    OTHER_COMMISSION_ACCEPTED("OtherCommissionAccepted"),
    @XmlEnumValue("OtherCommissionDifference")
    OTHER_COMMISSION_DIFFERENCE("OtherCommissionDifference"),
    @XmlEnumValue("UATPAllowed")
    UATP_ALLOWED("UATPAllowed"),
    @XmlEnumValue("UATPAccepted")
    UATP_ACCEPTED("UATPAccepted"),
    @XmlEnumValue("UATPDifference")
    UATP_DIFFERENCE("UATPDifference"),
    @XmlEnumValue("HandlingFeeAllowed")
    HANDLING_FEE_ALLOWED("HandlingFeeAllowed"),
    @XmlEnumValue("HandlingFeeAccepted")
    HANDLING_FEE_ACCEPTED("HandlingFeeAccepted"),
    @XmlEnumValue("HandlingFeeDifference")
    HANDLING_FEE_DIFFERENCE("HandlingFeeDifference"),
    @XmlEnumValue("OtherChargesAllowed")
    OTHER_CHARGES_ALLOWED("OtherChargesAllowed"),
    @XmlEnumValue("OtherChargesAccepted")
    OTHER_CHARGES_ACCEPTED("OtherChargesAccepted"),
    @XmlEnumValue("OtherChargesDifference")
    OTHER_CHARGES_DIFFERENCE("OtherChargesDifference"),
    @XmlEnumValue("AmountSubjectToISCAllowed")
    AMOUNT_SUBJECT_TO_ISC_ALLOWED("AmountSubjectToISCAllowed"),
    @XmlEnumValue("AmountSubjectToISCAccepted")
    AMOUNT_SUBJECT_TO_ISC_ACCEPTED("AmountSubjectToISCAccepted");
    private final String value;

    AddOnChargeNameValues(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AddOnChargeNameValues fromValue(String v) {
        for (AddOnChargeNameValues c: AddOnChargeNameValues.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
