package com.sample.app.service;
/*package com.sgl.smartpra.batch.iata.invoice.app.service;


import org.springframework.context.annotation.Configuration;

import com.sgl.smartpra.batch.iata.invoice.app.entity.InboundFileLog;

@Configuration
public interface InboundFileLogService {

	public InboundFileLog createInboundFileLog(InboundFileLog inboundFileLog);
	
}
*/