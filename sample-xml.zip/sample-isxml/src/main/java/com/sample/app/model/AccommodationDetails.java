
package com.sample.app.model;

import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RoomCategory" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>AN04Base">
 *                 &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardDataTypes}A025Base" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="RoomType" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>AN04Base">
 *                 &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardDataTypes}A025Base" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BedType" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>AN04Base">
 *                 &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardDataTypes}A025Base" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="NumberOfBed" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}NumberOfBedAndGuestNo" minOccurs="0"/>
 *         &lt;element name="TypeOfStay" type="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base" minOccurs="0"/>
 *         &lt;element name="EmployeeType" type="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base" minOccurs="0"/>
 *         &lt;element name="VoucherCode" type="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base" minOccurs="0"/>
 *         &lt;element name="GuestNo" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}NumberOfBedAndGuestNo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "roomCategory",
    "roomType",
    "bedType",
    "numberOfBed",
    "typeOfStay",
    "employeeType",
    "voucherCode",
    "guestNo"
})
@XmlRootElement(name = "AccommodationDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class AccommodationDetails {

    @XmlElement(name = "RoomCategory", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected AccommodationDetails.RoomCategory roomCategory;
    @XmlElement(name = "RoomType", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected AccommodationDetails.RoomType roomType;
    @XmlElement(name = "BedType", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected AccommodationDetails.BedType bedType;
    @XmlElement(name = "NumberOfBed", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger numberOfBed;
    @XmlElement(name = "TypeOfStay", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String typeOfStay;
    @XmlElement(name = "EmployeeType", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String employeeType;
    @XmlElement(name = "VoucherCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String voucherCode;
    @XmlElement(name = "GuestNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger guestNo;

    /**
     * Gets the value of the roomCategory property.
     * 
     * @return
     *     possible object is
     *     {@link AccommodationDetails.RoomCategory }
     *     
     */
    public AccommodationDetails.RoomCategory getRoomCategory() {
        return roomCategory;
    }

    /**
     * Sets the value of the roomCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccommodationDetails.RoomCategory }
     *     
     */
    public void setRoomCategory(AccommodationDetails.RoomCategory value) {
        this.roomCategory = value;
    }

    /**
     * Gets the value of the roomType property.
     * 
     * @return
     *     possible object is
     *     {@link AccommodationDetails.RoomType }
     *     
     */
    public AccommodationDetails.RoomType getRoomType() {
        return roomType;
    }

    /**
     * Sets the value of the roomType property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccommodationDetails.RoomType }
     *     
     */
    public void setRoomType(AccommodationDetails.RoomType value) {
        this.roomType = value;
    }

    /**
     * Gets the value of the bedType property.
     * 
     * @return
     *     possible object is
     *     {@link AccommodationDetails.BedType }
     *     
     */
    public AccommodationDetails.BedType getBedType() {
        return bedType;
    }

    /**
     * Sets the value of the bedType property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccommodationDetails.BedType }
     *     
     */
    public void setBedType(AccommodationDetails.BedType value) {
        this.bedType = value;
    }

    /**
     * Gets the value of the numberOfBed property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNumberOfBed() {
        return numberOfBed;
    }

    /**
     * Sets the value of the numberOfBed property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNumberOfBed(BigInteger value) {
        this.numberOfBed = value;
    }

    /**
     * Gets the value of the typeOfStay property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfStay() {
        return typeOfStay;
    }

    /**
     * Sets the value of the typeOfStay property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfStay(String value) {
        this.typeOfStay = value;
    }

    /**
     * Gets the value of the employeeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeType() {
        return employeeType;
    }

    /**
     * Sets the value of the employeeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeType(String value) {
        this.employeeType = value;
    }

    /**
     * Gets the value of the voucherCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVoucherCode() {
        return voucherCode;
    }

    /**
     * Sets the value of the voucherCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVoucherCode(String value) {
        this.voucherCode = value;
    }

    /**
     * Gets the value of the guestNo property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getGuestNo() {
        return guestNo;
    }

    /**
     * Sets the value of the guestNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setGuestNo(BigInteger value) {
        this.guestNo = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>AN04Base">
     *       &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardDataTypes}A025Base" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class BedType {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Name")
        protected String name;

        /**
         * Base type for string min1 max4
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setName(String value) {
            this.name = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>AN04Base">
     *       &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardDataTypes}A025Base" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class RoomCategory {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Name")
        protected String name;

        /**
         * Base type for string min1 max4
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setName(String value) {
            this.name = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>AN04Base">
     *       &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardDataTypes}A025Base" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class RoomType {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Name")
        protected String name;

        /**
         * Base type for string min1 max4
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setName(String value) {
            this.name = value;
        }

    }

}
