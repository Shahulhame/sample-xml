
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BillingCategoryMISC.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="BillingCategoryMISC">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="Miscellaneous"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "BillingCategoryMISC", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum BillingCategoryMISC {

    @XmlEnumValue("Miscellaneous")
    MISCELLANEOUS("Miscellaneous");
    private final String value;

    BillingCategoryMISC(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static BillingCategoryMISC fromValue(String v) {
        for (BillingCategoryMISC c: BillingCategoryMISC.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
