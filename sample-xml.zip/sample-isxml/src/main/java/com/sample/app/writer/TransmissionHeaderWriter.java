package com.sample.app.writer;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sample.app.repository.TransmissionHeaderRepository;
import com.sample.app.repository.entity.BaseEntity;
import com.sample.app.repository.entity.TransmissionHeaderEntity;

@Component
public class TransmissionHeaderWriter<T extends BaseEntity> implements ItemWriter<BaseEntity> {

	@Autowired
	private TransmissionHeaderRepository transmissionHeaderRepository;

	@SuppressWarnings("unchecked")
	@Override
	public void write(List<? extends BaseEntity> items) throws Exception {
		System.out.println("Repository Values-->" + transmissionHeaderRepository);
		System.out.println("Inside Writer" + items);
		transmissionHeaderRepository.saveAll((List<TransmissionHeaderEntity>)  items);

	}
}
