
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CGO-LID-RM-TaxAmount-Name.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CGO-LID-RM-TaxAmount-Name">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="Billed"/>
 *     &lt;enumeration value="Accepted"/>
 *     &lt;enumeration value="Difference"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "CGO-LID-RM-TaxAmount-Name", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum CGOLIDRMTaxAmountName {

    @XmlEnumValue("Billed")
    BILLED("Billed"),
    @XmlEnumValue("Accepted")
    ACCEPTED("Accepted"),
    @XmlEnumValue("Difference")
    DIFFERENCE("Difference");
    private final String value;

    CGOLIDRMTaxAmountName(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static CGOLIDRMTaxAmountName fromValue(String v) {
        for (CGOLIDRMTaxAmountName c: CGOLIDRMTaxAmountName.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
