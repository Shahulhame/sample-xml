
package com.sample.app.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OrganizationID"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OrganizationDesignator" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}LocationID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OrganizationName1" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OrganizationName2" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxRegistrationID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AdditionalTaxRegistrationID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CompanyRegistrationID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ContactName" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ContactDetails" maxOccurs="10" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Address" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OrganizationData" maxOccurs="20" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "organizationID",
    "organizationDesignator",
    "locationID",
    "organizationName1",
    "organizationName2",
    "taxRegistrationID",
    "additionalTaxRegistrationID",
    "companyRegistrationID",
    "contactName",
    "contactDetails",
    "address",
    "organizationData"
})
@XmlRootElement(name = "SellerOrganization", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class SellerOrganization {

    @XmlElement(name = "OrganizationID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String organizationID;
    @XmlElement(name = "OrganizationDesignator", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String organizationDesignator;
    @XmlElement(name = "LocationID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String locationID;
    @XmlElement(name = "OrganizationName1", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String organizationName1;
    @XmlElement(name = "OrganizationName2", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String organizationName2;
    @XmlElement(name = "TaxRegistrationID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String taxRegistrationID;
    @XmlElement(name = "AdditionalTaxRegistrationID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String additionalTaxRegistrationID;
    @XmlElement(name = "CompanyRegistrationID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String companyRegistrationID;
    @XmlElement(name = "ContactName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String contactName;
    @XmlElement(name = "ContactDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<ContactDetails> contactDetails;
    @XmlElement(name = "Address", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected Address address;
    @XmlElement(name = "OrganizationData", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<OrganizationData> organizationData;

    /**
     * Gets the value of the organizationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganizationID() {
        return organizationID;
    }

    /**
     * Sets the value of the organizationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganizationID(String value) {
        this.organizationID = value;
    }

    /**
     * Gets the value of the organizationDesignator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganizationDesignator() {
        return organizationDesignator;
    }

    /**
     * Sets the value of the organizationDesignator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganizationDesignator(String value) {
        this.organizationDesignator = value;
    }

    /**
     * Gets the value of the locationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationID() {
        return locationID;
    }

    /**
     * Sets the value of the locationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationID(String value) {
        this.locationID = value;
    }

    /**
     * Gets the value of the organizationName1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganizationName1() {
        return organizationName1;
    }

    /**
     * Sets the value of the organizationName1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganizationName1(String value) {
        this.organizationName1 = value;
    }

    /**
     * Gets the value of the organizationName2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganizationName2() {
        return organizationName2;
    }

    /**
     * Sets the value of the organizationName2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganizationName2(String value) {
        this.organizationName2 = value;
    }

    /**
     * Gets the value of the taxRegistrationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxRegistrationID() {
        return taxRegistrationID;
    }

    /**
     * Sets the value of the taxRegistrationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxRegistrationID(String value) {
        this.taxRegistrationID = value;
    }

    /**
     * Gets the value of the additionalTaxRegistrationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalTaxRegistrationID() {
        return additionalTaxRegistrationID;
    }

    /**
     * Sets the value of the additionalTaxRegistrationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalTaxRegistrationID(String value) {
        this.additionalTaxRegistrationID = value;
    }

    /**
     * Gets the value of the companyRegistrationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompanyRegistrationID() {
        return companyRegistrationID;
    }

    /**
     * Sets the value of the companyRegistrationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompanyRegistrationID(String value) {
        this.companyRegistrationID = value;
    }

    /**
     * Gets the value of the contactName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * Sets the value of the contactName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactName(String value) {
        this.contactName = value;
    }

    /**
     * Gets the value of the contactDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the contactDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContactDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ContactDetails }
     * 
     * 
     */
    public List<ContactDetails> getContactDetails() {
        if (contactDetails == null) {
            contactDetails = new ArrayList<ContactDetails>();
        }
        return this.contactDetails;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link Address }
     *     
     */
    public Address getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link Address }
     *     
     */
    public void setAddress(Address value) {
        this.address = value;
    }

    /**
     * Gets the value of the organizationData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the organizationData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOrganizationData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OrganizationData }
     * 
     * 
     */
    public List<OrganizationData> getOrganizationData() {
        if (organizationData == null) {
            organizationData = new ArrayList<OrganizationData>();
        }
        return this.organizationData;
    }

}
