
package com.sample.app.model;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AbsorptionName"/>
 *         &lt;element name="AbsorptionAmount" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AbsorptionPercentage" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "absorptionName",
    "absorptionAmount",
    "absorptionPercentage"
})
@XmlRootElement(name = "AbsorptionDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class AbsorptionDetails {

    @XmlElement(name = "AbsorptionName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    @XmlSchemaType(name = "string")
    protected AbsorptionName absorptionName;
    @XmlElement(name = "AbsorptionAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal absorptionAmount;
    @XmlElement(name = "AbsorptionPercentage", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal absorptionPercentage;

    /**
     * Gets the value of the absorptionName property.
     * 
     * @return
     *     possible object is
     *     {@link AbsorptionName }
     *     
     */
    public AbsorptionName getAbsorptionName() {
        return absorptionName;
    }

    /**
     * Sets the value of the absorptionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link AbsorptionName }
     *     
     */
    public void setAbsorptionName(AbsorptionName value) {
        this.absorptionName = value;
    }

    /**
     * Gets the value of the absorptionAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAbsorptionAmount() {
        return absorptionAmount;
    }

    /**
     * Sets the value of the absorptionAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAbsorptionAmount(BigDecimal value) {
        this.absorptionAmount = value;
    }

    /**
     * Gets the value of the absorptionPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAbsorptionPercentage() {
        return absorptionPercentage;
    }

    /**
     * Sets the value of the absorptionPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAbsorptionPercentage(BigDecimal value) {
        this.absorptionPercentage = value;
    }

}
