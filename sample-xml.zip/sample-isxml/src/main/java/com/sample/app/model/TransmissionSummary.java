
package com.sample.app.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;

import org.springframework.batch.item.ItemProcessor;

import com.sample.app.processor.TransmissonSummaryItemProcessor;
import com.sample.app.repository.entity.BaseEntity;
import com.sample.app.repository.entity.MiscBillingInvTransSummary;

/**
 * <p>
 * Java class for anonymous complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}InvoiceCount"/>
 *         &lt;element name="TotalAmount" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
 *                 &lt;attribute name="CurrencyCode" use="required" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}CurrencyCodeBase" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="TotalAddOnChargeAmount" maxOccurs="unbounded" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
 *                 &lt;attribute name="CurrencyCode" use="required" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}CurrencyCodeBase" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="TotalTaxAmount" maxOccurs="unbounded" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
 *                 &lt;attribute name="CurrencyCode" use="required" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}CurrencyCodeBase" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="TotalVATAmount" maxOccurs="unbounded" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
 *                 &lt;attribute name="CurrencyCode" use="required" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}CurrencyCodeBase" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AttachmentCount" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "invoiceCount", "totalAmount", "totalAddOnChargeAmount", "totalTaxAmount",
		"totalVATAmount", "attachmentCount" })
@XmlRootElement(name = "TransmissionSummary", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class TransmissionSummary extends BaseModel implements Serializable {

	@XmlElement(name = "InvoiceCount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
	protected int invoiceCount;
	@XmlElement(name = "TotalAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
	protected List<TransmissionSummary.TotalAmount> totalAmount;
	@XmlElement(name = "TotalAddOnChargeAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
	protected List<TransmissionSummary.TotalAddOnChargeAmount> totalAddOnChargeAmount;
	@XmlElement(name = "TotalTaxAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
	protected List<TransmissionSummary.TotalTaxAmount> totalTaxAmount;
	@XmlElement(name = "TotalVATAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
	protected List<TransmissionSummary.TotalVATAmount> totalVATAmount;
	@XmlElement(name = "AttachmentCount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
	protected BigInteger attachmentCount;

	/**
	 * Gets the value of the invoiceCount property.
	 * 
	 */
	public int getInvoiceCount() {
		return invoiceCount;
	}

	/**
	 * Sets the value of the invoiceCount property.
	 * 
	 */
	public void setInvoiceCount(int value) {
		this.invoiceCount = value;
	}

	/**
	 * Gets the value of the totalAmount property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot.
	 * Therefore any modification you make to the returned list will be present
	 * inside the JAXB object. This is why there is not a <CODE>set</CODE> method
	 * for the totalAmount property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getTotalAmount().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list
	 * {@link TransmissionSummary.TotalAmount }
	 * 
	 * 
	 */
	public List<TransmissionSummary.TotalAmount> getTotalAmount() {
		if (totalAmount == null) {
			totalAmount = new ArrayList<TransmissionSummary.TotalAmount>();
		}
		return this.totalAmount;
	}

	/**
	 * Gets the value of the totalAddOnChargeAmount property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot.
	 * Therefore any modification you make to the returned list will be present
	 * inside the JAXB object. This is why there is not a <CODE>set</CODE> method
	 * for the totalAddOnChargeAmount property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getTotalAddOnChargeAmount().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list
	 * {@link TransmissionSummary.TotalAddOnChargeAmount }
	 * 
	 * 
	 */
	public List<TransmissionSummary.TotalAddOnChargeAmount> getTotalAddOnChargeAmount() {
		if (totalAddOnChargeAmount == null) {
			totalAddOnChargeAmount = new ArrayList<TransmissionSummary.TotalAddOnChargeAmount>();
		}
		return this.totalAddOnChargeAmount;
	}

	/**
	 * Gets the value of the totalTaxAmount property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot.
	 * Therefore any modification you make to the returned list will be present
	 * inside the JAXB object. This is why there is not a <CODE>set</CODE> method
	 * for the totalTaxAmount property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getTotalTaxAmount().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list
	 * {@link TransmissionSummary.TotalTaxAmount }
	 * 
	 * 
	 */
	public List<TransmissionSummary.TotalTaxAmount> getTotalTaxAmount() {
		if (totalTaxAmount == null) {
			totalTaxAmount = new ArrayList<TransmissionSummary.TotalTaxAmount>();
		}
		return this.totalTaxAmount;
	}

	/**
	 * Gets the value of the totalVATAmount property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot.
	 * Therefore any modification you make to the returned list will be present
	 * inside the JAXB object. This is why there is not a <CODE>set</CODE> method
	 * for the totalVATAmount property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getTotalVATAmount().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list
	 * {@link TransmissionSummary.TotalVATAmount }
	 * 
	 * 
	 */
	public List<TransmissionSummary.TotalVATAmount> getTotalVATAmount() {
		if (totalVATAmount == null) {
			totalVATAmount = new ArrayList<TransmissionSummary.TotalVATAmount>();
		}
		return this.totalVATAmount;
	}

	/**
	 * Gets the value of the attachmentCount property.
	 * 
	 * @return possible object is {@link BigInteger }
	 * 
	 */
	public BigInteger getAttachmentCount() {
		return attachmentCount;
	}

	/**
	 * Sets the value of the attachmentCount property.
	 * 
	 * @param value allowed object is {@link BigInteger }
	 * 
	 */
	public void setAttachmentCount(BigInteger value) {
		this.attachmentCount = value;
	}

	/**
	 * <p>
	 * Java class for anonymous complex type.
	 * 
	 * <p>
	 * The following schema fragment specifies the expected content contained within
	 * this class.
	 * 
	 * <pre>
	 * &lt;complexType>
	 *   &lt;simpleContent>
	 *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
	 *       &lt;attribute name="CurrencyCode" use="required" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}CurrencyCodeBase" />
	 *     &lt;/extension>
	 *   &lt;/simpleContent>
	 * &lt;/complexType>
	 * </pre>
	 * 
	 * 
	 */
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(name = "", propOrder = { "value" })
	public static class TotalAddOnChargeAmount {

		@XmlValue
		protected BigDecimal value;
		@XmlAttribute(name = "CurrencyCode", required = true)
		protected String currencyCode;

		/**
		 * Base used for numbers of type decimal(18,3)
		 * 
		 * @return possible object is {@link BigDecimal }
		 * 
		 */
		public BigDecimal getValue() {
			return value;
		}

		/**
		 * Sets the value of the value property.
		 * 
		 * @param value allowed object is {@link BigDecimal }
		 * 
		 */
		public void setValue(BigDecimal value) {
			this.value = value;
		}

		/**
		 * Gets the value of the currencyCode property.
		 * 
		 * @return possible object is {@link String }
		 * 
		 */
		public String getCurrencyCode() {
			return currencyCode;
		}

		/**
		 * Sets the value of the currencyCode property.
		 * 
		 * @param value allowed object is {@link String }
		 * 
		 */
		public void setCurrencyCode(String value) {
			this.currencyCode = value;
		}

	}

	/**
	 * <p>
	 * Java class for anonymous complex type.
	 * 
	 * <p>
	 * The following schema fragment specifies the expected content contained within
	 * this class.
	 * 
	 * <pre>
	 * &lt;complexType>
	 *   &lt;simpleContent>
	 *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
	 *       &lt;attribute name="CurrencyCode" use="required" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}CurrencyCodeBase" />
	 *     &lt;/extension>
	 *   &lt;/simpleContent>
	 * &lt;/complexType>
	 * </pre>
	 * 
	 * 
	 */
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(name = "", propOrder = { "value" })
	public static class TotalAmount {

		@XmlValue
		protected BigDecimal value;
		@XmlAttribute(name = "CurrencyCode", required = true)
		protected String currencyCode;

		/**
		 * Base used for numbers of type decimal(18,3)
		 * 
		 * @return possible object is {@link BigDecimal }
		 * 
		 */
		public BigDecimal getValue() {
			return value;
		}

		/**
		 * Sets the value of the value property.
		 * 
		 * @param value allowed object is {@link BigDecimal }
		 * 
		 */
		public void setValue(BigDecimal value) {
			this.value = value;
		}

		/**
		 * Gets the value of the currencyCode property.
		 * 
		 * @return possible object is {@link String }
		 * 
		 */
		public String getCurrencyCode() {
			return currencyCode;
		}

		/**
		 * Sets the value of the currencyCode property.
		 * 
		 * @param value allowed object is {@link String }
		 * 
		 */
		public void setCurrencyCode(String value) {
			this.currencyCode = value;
		}

	}

	/**
	 * <p>
	 * Java class for anonymous complex type.
	 * 
	 * <p>
	 * The following schema fragment specifies the expected content contained within
	 * this class.
	 * 
	 * <pre>
	 * &lt;complexType>
	 *   &lt;simpleContent>
	 *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
	 *       &lt;attribute name="CurrencyCode" use="required" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}CurrencyCodeBase" />
	 *     &lt;/extension>
	 *   &lt;/simpleContent>
	 * &lt;/complexType>
	 * </pre>
	 * 
	 * 
	 */
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(name = "", propOrder = { "value" })
	public static class TotalTaxAmount {

		@XmlValue
		protected BigDecimal value;
		@XmlAttribute(name = "CurrencyCode", required = true)
		protected String currencyCode;

		/**
		 * Base used for numbers of type decimal(18,3)
		 * 
		 * @return possible object is {@link BigDecimal }
		 * 
		 */
		public BigDecimal getValue() {
			return value;
		}

		/**
		 * Sets the value of the value property.
		 * 
		 * @param value allowed object is {@link BigDecimal }
		 * 
		 */
		public void setValue(BigDecimal value) {
			this.value = value;
		}

		/**
		 * Gets the value of the currencyCode property.
		 * 
		 * @return possible object is {@link String }
		 * 
		 */
		public String getCurrencyCode() {
			return currencyCode;
		}

		/**
		 * Sets the value of the currencyCode property.
		 * 
		 * @param value allowed object is {@link String }
		 * 
		 */
		public void setCurrencyCode(String value) {
			this.currencyCode = value;
		}

	}

	/**
	 * <p>
	 * Java class for anonymous complex type.
	 * 
	 * <p>
	 * The following schema fragment specifies the expected content contained within
	 * this class.
	 * 
	 * <pre>
	 * &lt;complexType>
	 *   &lt;simpleContent>
	 *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
	 *       &lt;attribute name="CurrencyCode" use="required" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}CurrencyCodeBase" />
	 *     &lt;/extension>
	 *   &lt;/simpleContent>
	 * &lt;/complexType>
	 * </pre>
	 * 
	 * 
	 */
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(name = "", propOrder = { "value" })
	public static class TotalVATAmount {

		@XmlValue
		protected BigDecimal value;
		@XmlAttribute(name = "CurrencyCode", required = true)
		protected String currencyCode;

		/**
		 * Base used for numbers of type decimal(18,3)
		 * 
		 * @return possible object is {@link BigDecimal }
		 * 
		 */
		public BigDecimal getValue() {
			return value;
		}

		/**
		 * Sets the value of the value property.
		 * 
		 * @param value allowed object is {@link BigDecimal }
		 * 
		 */
		public void setValue(BigDecimal value) {
			this.value = value;
		}

		/**
		 * Gets the value of the currencyCode property.
		 * 
		 * @return possible object is {@link String }
		 * 
		 */
		public String getCurrencyCode() {
			return currencyCode;
		}

		/**
		 * Sets the value of the currencyCode property.
		 * 
		 * @param value allowed object is {@link String }
		 * 
		 */
		public void setCurrencyCode(String value) {
			this.currencyCode = value;
		}

	}

	@Override
	public ItemProcessor<? extends TransmissionSummary, ? extends MiscBillingInvTransSummary> processor() {
		return new TransmissonSummaryItemProcessor();
	}

}
