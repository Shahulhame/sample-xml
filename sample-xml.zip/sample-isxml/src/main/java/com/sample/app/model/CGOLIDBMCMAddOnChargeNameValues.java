
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CGO-LID-BMCM-AddOnChargeName-Values.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CGO-LID-BMCM-AddOnChargeName-Values">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN30Base">
 *     &lt;enumeration value="ISCAllowed"/>
 *     &lt;enumeration value="OtherChargesAllowed"/>
 *     &lt;enumeration value="AmountSubjectToISCAllowed"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "CGO-LID-BMCM-AddOnChargeName-Values", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum CGOLIDBMCMAddOnChargeNameValues {

    @XmlEnumValue("ISCAllowed")
    ISC_ALLOWED("ISCAllowed"),
    @XmlEnumValue("OtherChargesAllowed")
    OTHER_CHARGES_ALLOWED("OtherChargesAllowed"),
    @XmlEnumValue("AmountSubjectToISCAllowed")
    AMOUNT_SUBJECT_TO_ISC_ALLOWED("AmountSubjectToISCAllowed");
    private final String value;

    CGOLIDBMCMAddOnChargeNameValues(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static CGOLIDBMCMAddOnChargeNameValues fromValue(String v) {
        for (CGOLIDBMCMAddOnChargeNameValues c: CGOLIDBMCMAddOnChargeNameValues.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
