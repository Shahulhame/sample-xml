
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TaxCategory.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TaxCategory">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="Standard"/>
 *     &lt;enumeration value="Zero"/>
 *     &lt;enumeration value="Higher"/>
 *     &lt;enumeration value="Lower"/>
 *     &lt;enumeration value="Exempt"/>
 *     &lt;enumeration value="OutofScope"/>
 *     &lt;enumeration value="Reverse Charge"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TaxCategory", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum TaxCategory {

    @XmlEnumValue("Standard")
    STANDARD("Standard"),
    @XmlEnumValue("Zero")
    ZERO("Zero"),
    @XmlEnumValue("Higher")
    HIGHER("Higher"),
    @XmlEnumValue("Lower")
    LOWER("Lower"),
    @XmlEnumValue("Exempt")
    EXEMPT("Exempt"),
    @XmlEnumValue("OutofScope")
    OUTOF_SCOPE("OutofScope"),
    @XmlEnumValue("Reverse Charge")
    REVERSE_CHARGE("Reverse Charge");
    private final String value;

    TaxCategory(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TaxCategory fromValue(String v) {
        for (TaxCategory c: TaxCategory.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
