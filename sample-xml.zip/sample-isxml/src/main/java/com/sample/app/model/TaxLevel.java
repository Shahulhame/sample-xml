
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TaxLevel.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TaxLevel">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="Invoice"/>
 *     &lt;enumeration value="LineItem"/>
 *     &lt;enumeration value="Detail"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TaxLevel", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum TaxLevel {

    @XmlEnumValue("Invoice")
    INVOICE("Invoice"),
    @XmlEnumValue("LineItem")
    LINE_ITEM("LineItem"),
    @XmlEnumValue("Detail")
    DETAIL("Detail");
    private final String value;

    TaxLevel(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TaxLevel fromValue(String v) {
        for (TaxLevel c: TaxLevel.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
