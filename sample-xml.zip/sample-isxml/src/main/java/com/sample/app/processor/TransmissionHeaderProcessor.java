package com.sample.app.processor;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.sample.app.model.TransmissionHeaderModel;
import com.sample.app.repository.entity.TransmissionHeaderEntity;

@Component
public class TransmissionHeaderProcessor implements ItemProcessor<TransmissionHeaderModel, TransmissionHeaderEntity> {

	@Override
	public TransmissionHeaderEntity process(TransmissionHeaderModel transmissionHeaderModel) throws Exception {
		System.out.println("Inside Processor");
		TransmissionHeaderEntity transmissionHeaderEntity = new TransmissionHeaderEntity();
		transmissionHeaderEntity.setTransmissionDateTime(transmissionHeaderModel.getTransmissionDateTime());
		transmissionHeaderEntity.setBillingCategory(transmissionHeaderModel.getBillingCategory());
		transmissionHeaderEntity.setIssuingOrganizationId(transmissionHeaderModel.getIssuingOrganizationID());
		transmissionHeaderEntity.setTransmissionId(transmissionHeaderModel.getTransmissionID());
		transmissionHeaderEntity.setVersion(transmissionHeaderModel.getVersion());
		transmissionHeaderEntity.setReceivingOrganizationId(transmissionHeaderModel.getReceivingOrganizationID());
		transmissionHeaderEntity.setLastUpdatedBy("shahul");
		transmissionHeaderEntity.setLastUpdatedDate(new Timestamp(new Date().getTime()));
		transmissionHeaderEntity.setCreatedBy("Shah");
		transmissionHeaderEntity.setCreatedDate(new Timestamp(new Date().getTime()));
		System.out.println("Inside Processor" + transmissionHeaderEntity);
		return transmissionHeaderEntity;
	}
}
