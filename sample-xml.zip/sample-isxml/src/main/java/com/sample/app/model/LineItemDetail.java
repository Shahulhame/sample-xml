
package com.sample.app.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DetailNumber"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}LineItemNumber"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}BatchSequenceNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}RecordSequenceWithinBatch" minOccurs="0"/>
 *         &lt;element name="Description" type="{http://www.IATA.com/IATAAviationStandardDataTypes}AN240Base" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProductID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}StartDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}EndDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}MinimumQuantityFlag" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Quantity" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}UnitPrice" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ChargeAmount" maxOccurs="6" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Tax" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnCharges" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TotalNetAmount" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ContractNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PoolNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ReceiptNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ReferenceNo" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Recipient" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}MishandlingType" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}MailDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AircraftDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}FlightDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}RouteDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ParkingDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}EmployeeDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AreaDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Desk-GateDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ConsumptionDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SettlementDetails" maxOccurs="10" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ServiceProviderDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AccommodationDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CarDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}UATPDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PassengerDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CateringDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}MiscDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CouponDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SamplingFormDDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AirWaybillDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}RejectionMemoDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}BillingMemoDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CreditMemoDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "detailNumber",
    "lineItemNumber",
    "batchSequenceNumber",
    "recordSequenceWithinBatch",
    "description",
    "productID",
    "startDate",
    "endDate",
    "minimumQuantityFlag",
    "quantity",
    "unitPrice",
    "chargeAmount",
    "tax",
    "addOnCharges",
    "totalNetAmount",
    "contractNo",
    "poolNo",
    "receiptNo",
    "referenceNo",
    "recipient",
    "mishandlingType",
    "mailDetails",
    "aircraftDetails",
    "flightDetails",
    "routeDetails",
    "parkingDetails",
    "employeeDetails",
    "areaDetails",
    "deskGateDetails",
    "consumptionDetails",
    "settlementDetails",
    "serviceProviderDetails",
    "accommodationDetails",
    "carDetails",
    "uatpDetails",
    "passengerDetails",
    "cateringDetails",
    "miscDetails",
    "couponDetails",
    "samplingFormDDetails",
    "airWaybillDetails",
    "rejectionMemoDetails",
    "billingMemoDetails",
    "creditMemoDetails"
})
@XmlRootElement(name = "LineItemDetail", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class LineItemDetail {

    @XmlElement(name = "DetailNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigInteger detailNumber;
    @XmlElement(name = "LineItemNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigInteger lineItemNumber;
    @XmlElement(name = "BatchSequenceNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger batchSequenceNumber;
    @XmlElement(name = "RecordSequenceWithinBatch", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger recordSequenceWithinBatch;
    @XmlElement(name = "Description", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String description;
    @XmlElement(name = "ProductID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String productID;
    @XmlElement(name = "StartDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String startDate;
    @XmlElement(name = "EndDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String endDate;
    @XmlElement(name = "MinimumQuantityFlag", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected MinimumQuantityFlag minimumQuantityFlag;
    @XmlElement(name = "Quantity", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected Quantity quantity;
    @XmlElement(name = "UnitPrice", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected UnitPrice unitPrice;
    @XmlElement(name = "ChargeAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<ChargeAmount> chargeAmount;
    @XmlElement(name = "Tax", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<Tax> tax;
    @XmlElement(name = "AddOnCharges", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<AddOnCharges> addOnCharges;
    @XmlElement(name = "TotalNetAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal totalNetAmount;
    @XmlElement(name = "ContractNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String contractNo;
    @XmlElement(name = "PoolNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String poolNo;
    @XmlElement(name = "ReceiptNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String receiptNo;
    @XmlElement(name = "ReferenceNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<ReferenceNo> referenceNo;
    @XmlElement(name = "Recipient", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String recipient;
    @XmlElement(name = "MishandlingType", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String mishandlingType;
    @XmlElement(name = "MailDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected MailDetails mailDetails;
    @XmlElement(name = "AircraftDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected AircraftDetails aircraftDetails;
    @XmlElement(name = "FlightDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected FlightDetails flightDetails;
    @XmlElement(name = "RouteDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<RouteDetails> routeDetails;
    @XmlElement(name = "ParkingDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected ParkingDetails parkingDetails;
    @XmlElement(name = "EmployeeDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<EmployeeDetails> employeeDetails;
    @XmlElement(name = "AreaDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected AreaDetails areaDetails;
    @XmlElement(name = "Desk-GateDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected DeskGateDetails deskGateDetails;
    @XmlElement(name = "ConsumptionDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected ConsumptionDetails consumptionDetails;
    @XmlElement(name = "SettlementDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<SettlementDetails> settlementDetails;
    @XmlElement(name = "ServiceProviderDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected ServiceProviderDetails serviceProviderDetails;
    @XmlElement(name = "AccommodationDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected AccommodationDetails accommodationDetails;
    @XmlElement(name = "CarDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected CarDetails carDetails;
    @XmlElement(name = "UATPDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected UATPDetails uatpDetails;
    @XmlElement(name = "PassengerDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<PassengerDetails> passengerDetails;
    @XmlElement(name = "CateringDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<CateringDetails> cateringDetails;
    @XmlElement(name = "MiscDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected MiscDetails miscDetails;
    @XmlElement(name = "CouponDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected CouponDetails couponDetails;
    @XmlElement(name = "SamplingFormDDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected SamplingFormDDetails samplingFormDDetails;
    @XmlElement(name = "AirWaybillDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected AirWaybillDetails airWaybillDetails;
    @XmlElement(name = "RejectionMemoDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected RejectionMemoDetails rejectionMemoDetails;
    @XmlElement(name = "BillingMemoDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BillingMemoDetails billingMemoDetails;
    @XmlElement(name = "CreditMemoDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected CreditMemoDetails creditMemoDetails;

    /**
     * Gets the value of the detailNumber property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDetailNumber() {
        return detailNumber;
    }

    /**
     * Sets the value of the detailNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDetailNumber(BigInteger value) {
        this.detailNumber = value;
    }

    /**
     * Gets the value of the lineItemNumber property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getLineItemNumber() {
        return lineItemNumber;
    }

    /**
     * Sets the value of the lineItemNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setLineItemNumber(BigInteger value) {
        this.lineItemNumber = value;
    }

    /**
     * Gets the value of the batchSequenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getBatchSequenceNumber() {
        return batchSequenceNumber;
    }

    /**
     * Sets the value of the batchSequenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setBatchSequenceNumber(BigInteger value) {
        this.batchSequenceNumber = value;
    }

    /**
     * Gets the value of the recordSequenceWithinBatch property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRecordSequenceWithinBatch() {
        return recordSequenceWithinBatch;
    }

    /**
     * Sets the value of the recordSequenceWithinBatch property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRecordSequenceWithinBatch(BigInteger value) {
        this.recordSequenceWithinBatch = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the productID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductID() {
        return productID;
    }

    /**
     * Sets the value of the productID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductID(String value) {
        this.productID = value;
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartDate(String value) {
        this.startDate = value;
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndDate(String value) {
        this.endDate = value;
    }

    /**
     * Gets the value of the minimumQuantityFlag property.
     * 
     * @return
     *     possible object is
     *     {@link MinimumQuantityFlag }
     *     
     */
    public MinimumQuantityFlag getMinimumQuantityFlag() {
        return minimumQuantityFlag;
    }

    /**
     * Sets the value of the minimumQuantityFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinimumQuantityFlag }
     *     
     */
    public void setMinimumQuantityFlag(MinimumQuantityFlag value) {
        this.minimumQuantityFlag = value;
    }

    /**
     * Gets the value of the quantity property.
     * 
     * @return
     *     possible object is
     *     {@link Quantity }
     *     
     */
    public Quantity getQuantity() {
        return quantity;
    }

    /**
     * Sets the value of the quantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Quantity }
     *     
     */
    public void setQuantity(Quantity value) {
        this.quantity = value;
    }

    /**
     * Gets the value of the unitPrice property.
     * 
     * @return
     *     possible object is
     *     {@link UnitPrice }
     *     
     */
    public UnitPrice getUnitPrice() {
        return unitPrice;
    }

    /**
     * Sets the value of the unitPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link UnitPrice }
     *     
     */
    public void setUnitPrice(UnitPrice value) {
        this.unitPrice = value;
    }

    /**
     * Gets the value of the chargeAmount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the chargeAmount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getChargeAmount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ChargeAmount }
     * 
     * 
     */
    public List<ChargeAmount> getChargeAmount() {
        if (chargeAmount == null) {
            chargeAmount = new ArrayList<ChargeAmount>();
        }
        return this.chargeAmount;
    }

    /**
     * Gets the value of the tax property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tax property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTax().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Tax }
     * 
     * 
     */
    public List<Tax> getTax() {
        if (tax == null) {
            tax = new ArrayList<Tax>();
        }
        return this.tax;
    }

    /**
     * Gets the value of the addOnCharges property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addOnCharges property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddOnCharges().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AddOnCharges }
     * 
     * 
     */
    public List<AddOnCharges> getAddOnCharges() {
        if (addOnCharges == null) {
            addOnCharges = new ArrayList<AddOnCharges>();
        }
        return this.addOnCharges;
    }

    /**
     * Gets the value of the totalNetAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalNetAmount() {
        return totalNetAmount;
    }

    /**
     * Sets the value of the totalNetAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalNetAmount(BigDecimal value) {
        this.totalNetAmount = value;
    }

    /**
     * Gets the value of the contractNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractNo() {
        return contractNo;
    }

    /**
     * Sets the value of the contractNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractNo(String value) {
        this.contractNo = value;
    }

    /**
     * Gets the value of the poolNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPoolNo() {
        return poolNo;
    }

    /**
     * Sets the value of the poolNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPoolNo(String value) {
        this.poolNo = value;
    }

    /**
     * Gets the value of the receiptNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptNo() {
        return receiptNo;
    }

    /**
     * Sets the value of the receiptNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptNo(String value) {
        this.receiptNo = value;
    }

    /**
     * Gets the value of the referenceNo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the referenceNo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReferenceNo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReferenceNo }
     * 
     * 
     */
    public List<ReferenceNo> getReferenceNo() {
        if (referenceNo == null) {
            referenceNo = new ArrayList<ReferenceNo>();
        }
        return this.referenceNo;
    }

    /**
     * Gets the value of the recipient property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecipient() {
        return recipient;
    }

    /**
     * Sets the value of the recipient property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecipient(String value) {
        this.recipient = value;
    }

    /**
     * Gets the value of the mishandlingType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMishandlingType() {
        return mishandlingType;
    }

    /**
     * Sets the value of the mishandlingType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMishandlingType(String value) {
        this.mishandlingType = value;
    }

    /**
     * Gets the value of the mailDetails property.
     * 
     * @return
     *     possible object is
     *     {@link MailDetails }
     *     
     */
    public MailDetails getMailDetails() {
        return mailDetails;
    }

    /**
     * Sets the value of the mailDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link MailDetails }
     *     
     */
    public void setMailDetails(MailDetails value) {
        this.mailDetails = value;
    }

    /**
     * Gets the value of the aircraftDetails property.
     * 
     * @return
     *     possible object is
     *     {@link AircraftDetails }
     *     
     */
    public AircraftDetails getAircraftDetails() {
        return aircraftDetails;
    }

    /**
     * Sets the value of the aircraftDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link AircraftDetails }
     *     
     */
    public void setAircraftDetails(AircraftDetails value) {
        this.aircraftDetails = value;
    }

    /**
     * Gets the value of the flightDetails property.
     * 
     * @return
     *     possible object is
     *     {@link FlightDetails }
     *     
     */
    public FlightDetails getFlightDetails() {
        return flightDetails;
    }

    /**
     * Sets the value of the flightDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link FlightDetails }
     *     
     */
    public void setFlightDetails(FlightDetails value) {
        this.flightDetails = value;
    }

    /**
     * Gets the value of the routeDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the routeDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRouteDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RouteDetails }
     * 
     * 
     */
    public List<RouteDetails> getRouteDetails() {
        if (routeDetails == null) {
            routeDetails = new ArrayList<RouteDetails>();
        }
        return this.routeDetails;
    }

    /**
     * Gets the value of the parkingDetails property.
     * 
     * @return
     *     possible object is
     *     {@link ParkingDetails }
     *     
     */
    public ParkingDetails getParkingDetails() {
        return parkingDetails;
    }

    /**
     * Sets the value of the parkingDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link ParkingDetails }
     *     
     */
    public void setParkingDetails(ParkingDetails value) {
        this.parkingDetails = value;
    }

    /**
     * Gets the value of the employeeDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the employeeDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEmployeeDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EmployeeDetails }
     * 
     * 
     */
    public List<EmployeeDetails> getEmployeeDetails() {
        if (employeeDetails == null) {
            employeeDetails = new ArrayList<EmployeeDetails>();
        }
        return this.employeeDetails;
    }

    /**
     * Gets the value of the areaDetails property.
     * 
     * @return
     *     possible object is
     *     {@link AreaDetails }
     *     
     */
    public AreaDetails getAreaDetails() {
        return areaDetails;
    }

    /**
     * Sets the value of the areaDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link AreaDetails }
     *     
     */
    public void setAreaDetails(AreaDetails value) {
        this.areaDetails = value;
    }

    /**
     * Gets the value of the deskGateDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DeskGateDetails }
     *     
     */
    public DeskGateDetails getDeskGateDetails() {
        return deskGateDetails;
    }

    /**
     * Sets the value of the deskGateDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeskGateDetails }
     *     
     */
    public void setDeskGateDetails(DeskGateDetails value) {
        this.deskGateDetails = value;
    }

    /**
     * Gets the value of the consumptionDetails property.
     * 
     * @return
     *     possible object is
     *     {@link ConsumptionDetails }
     *     
     */
    public ConsumptionDetails getConsumptionDetails() {
        return consumptionDetails;
    }

    /**
     * Sets the value of the consumptionDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsumptionDetails }
     *     
     */
    public void setConsumptionDetails(ConsumptionDetails value) {
        this.consumptionDetails = value;
    }

    /**
     * Gets the value of the settlementDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the settlementDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSettlementDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SettlementDetails }
     * 
     * 
     */
    public List<SettlementDetails> getSettlementDetails() {
        if (settlementDetails == null) {
            settlementDetails = new ArrayList<SettlementDetails>();
        }
        return this.settlementDetails;
    }

    /**
     * Gets the value of the serviceProviderDetails property.
     * 
     * @return
     *     possible object is
     *     {@link ServiceProviderDetails }
     *     
     */
    public ServiceProviderDetails getServiceProviderDetails() {
        return serviceProviderDetails;
    }

    /**
     * Sets the value of the serviceProviderDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link ServiceProviderDetails }
     *     
     */
    public void setServiceProviderDetails(ServiceProviderDetails value) {
        this.serviceProviderDetails = value;
    }

    /**
     * Gets the value of the accommodationDetails property.
     * 
     * @return
     *     possible object is
     *     {@link AccommodationDetails }
     *     
     */
    public AccommodationDetails getAccommodationDetails() {
        return accommodationDetails;
    }

    /**
     * Sets the value of the accommodationDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccommodationDetails }
     *     
     */
    public void setAccommodationDetails(AccommodationDetails value) {
        this.accommodationDetails = value;
    }

    /**
     * Gets the value of the carDetails property.
     * 
     * @return
     *     possible object is
     *     {@link CarDetails }
     *     
     */
    public CarDetails getCarDetails() {
        return carDetails;
    }

    /**
     * Sets the value of the carDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link CarDetails }
     *     
     */
    public void setCarDetails(CarDetails value) {
        this.carDetails = value;
    }

    /**
     * Gets the value of the uatpDetails property.
     * 
     * @return
     *     possible object is
     *     {@link UATPDetails }
     *     
     */
    public UATPDetails getUATPDetails() {
        return uatpDetails;
    }

    /**
     * Sets the value of the uatpDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link UATPDetails }
     *     
     */
    public void setUATPDetails(UATPDetails value) {
        this.uatpDetails = value;
    }

    /**
     * Gets the value of the passengerDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the passengerDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPassengerDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PassengerDetails }
     * 
     * 
     */
    public List<PassengerDetails> getPassengerDetails() {
        if (passengerDetails == null) {
            passengerDetails = new ArrayList<PassengerDetails>();
        }
        return this.passengerDetails;
    }

    /**
     * Gets the value of the cateringDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cateringDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCateringDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CateringDetails }
     * 
     * 
     */
    public List<CateringDetails> getCateringDetails() {
        if (cateringDetails == null) {
            cateringDetails = new ArrayList<CateringDetails>();
        }
        return this.cateringDetails;
    }

    /**
     * Gets the value of the miscDetails property.
     * 
     * @return
     *     possible object is
     *     {@link MiscDetails }
     *     
     */
    public MiscDetails getMiscDetails() {
        return miscDetails;
    }

    /**
     * Sets the value of the miscDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link MiscDetails }
     *     
     */
    public void setMiscDetails(MiscDetails value) {
        this.miscDetails = value;
    }

    /**
     * Gets the value of the couponDetails property.
     * 
     * @return
     *     possible object is
     *     {@link CouponDetails }
     *     
     */
    public CouponDetails getCouponDetails() {
        return couponDetails;
    }

    /**
     * Sets the value of the couponDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link CouponDetails }
     *     
     */
    public void setCouponDetails(CouponDetails value) {
        this.couponDetails = value;
    }

    /**
     * Gets the value of the samplingFormDDetails property.
     * 
     * @return
     *     possible object is
     *     {@link SamplingFormDDetails }
     *     
     */
    public SamplingFormDDetails getSamplingFormDDetails() {
        return samplingFormDDetails;
    }

    /**
     * Sets the value of the samplingFormDDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link SamplingFormDDetails }
     *     
     */
    public void setSamplingFormDDetails(SamplingFormDDetails value) {
        this.samplingFormDDetails = value;
    }

    /**
     * Gets the value of the airWaybillDetails property.
     * 
     * @return
     *     possible object is
     *     {@link AirWaybillDetails }
     *     
     */
    public AirWaybillDetails getAirWaybillDetails() {
        return airWaybillDetails;
    }

    /**
     * Sets the value of the airWaybillDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link AirWaybillDetails }
     *     
     */
    public void setAirWaybillDetails(AirWaybillDetails value) {
        this.airWaybillDetails = value;
    }

    /**
     * Gets the value of the rejectionMemoDetails property.
     * 
     * @return
     *     possible object is
     *     {@link RejectionMemoDetails }
     *     
     */
    public RejectionMemoDetails getRejectionMemoDetails() {
        return rejectionMemoDetails;
    }

    /**
     * Sets the value of the rejectionMemoDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link RejectionMemoDetails }
     *     
     */
    public void setRejectionMemoDetails(RejectionMemoDetails value) {
        this.rejectionMemoDetails = value;
    }

    /**
     * Gets the value of the billingMemoDetails property.
     * 
     * @return
     *     possible object is
     *     {@link BillingMemoDetails }
     *     
     */
    public BillingMemoDetails getBillingMemoDetails() {
        return billingMemoDetails;
    }

    /**
     * Sets the value of the billingMemoDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link BillingMemoDetails }
     *     
     */
    public void setBillingMemoDetails(BillingMemoDetails value) {
        this.billingMemoDetails = value;
    }

    /**
     * Gets the value of the creditMemoDetails property.
     * 
     * @return
     *     possible object is
     *     {@link CreditMemoDetails }
     *     
     */
    public CreditMemoDetails getCreditMemoDetails() {
        return creditMemoDetails;
    }

    /**
     * Sets the value of the creditMemoDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditMemoDetails }
     *     
     */
    public void setCreditMemoDetails(CreditMemoDetails value) {
        this.creditMemoDetails = value;
    }

}
