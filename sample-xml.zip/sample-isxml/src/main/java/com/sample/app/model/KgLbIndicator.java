
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for KgLbIndicator.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="KgLbIndicator">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}A01Base">
 *     &lt;enumeration value="K"/>
 *     &lt;enumeration value="L"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "KgLbIndicator", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum KgLbIndicator {

    K,
    L;

    public String value() {
        return name();
    }

    public static KgLbIndicator fromValue(String v) {
        return valueOf(v);
    }

}
