
package com.sample.app.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}StaffID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}StaffName" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}StaffForename" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}StaffSurname" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PassNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PassIssueDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PassExpiryDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}IssueDescription" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "staffID",
    "staffName",
    "staffForename",
    "staffSurname",
    "passNo",
    "passIssueDate",
    "passExpiryDate",
    "issueDescription"
})
@XmlRootElement(name = "EmployeeDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class EmployeeDetails {

    @XmlElement(name = "StaffID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String staffID;
    @XmlElement(name = "StaffName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String staffName;
    @XmlElement(name = "StaffForename", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String staffForename;
    @XmlElement(name = "StaffSurname", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String staffSurname;
    @XmlElement(name = "PassNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String passNo;
    @XmlElement(name = "PassIssueDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String passIssueDate;
    @XmlElement(name = "PassExpiryDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String passExpiryDate;
    @XmlElement(name = "IssueDescription", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String issueDescription;

    /**
     * Gets the value of the staffID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStaffID() {
        return staffID;
    }

    /**
     * Sets the value of the staffID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStaffID(String value) {
        this.staffID = value;
    }

    /**
     * Gets the value of the staffName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStaffName() {
        return staffName;
    }

    /**
     * Sets the value of the staffName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStaffName(String value) {
        this.staffName = value;
    }

    /**
     * Gets the value of the staffForename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStaffForename() {
        return staffForename;
    }

    /**
     * Sets the value of the staffForename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStaffForename(String value) {
        this.staffForename = value;
    }

    /**
     * Gets the value of the staffSurname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStaffSurname() {
        return staffSurname;
    }

    /**
     * Sets the value of the staffSurname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStaffSurname(String value) {
        this.staffSurname = value;
    }

    /**
     * Gets the value of the passNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPassNo() {
        return passNo;
    }

    /**
     * Sets the value of the passNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassNo(String value) {
        this.passNo = value;
    }

    /**
     * Gets the value of the passIssueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPassIssueDate() {
        return passIssueDate;
    }

    /**
     * Sets the value of the passIssueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassIssueDate(String value) {
        this.passIssueDate = value;
    }

    /**
     * Gets the value of the passExpiryDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPassExpiryDate() {
        return passExpiryDate;
    }

    /**
     * Sets the value of the passExpiryDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassExpiryDate(String value) {
        this.passExpiryDate = value;
    }

    /**
     * Gets the value of the issueDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssueDescription() {
        return issueDescription;
    }

    /**
     * Sets the value of the issueDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssueDescription(String value) {
        this.issueDescription = value;
    }

}
