
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CGO-ChargeAmount-Name.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CGO-ChargeAmount-Name">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="WeightBilled"/>
 *     &lt;enumeration value="WeightAccepted"/>
 *     &lt;enumeration value="WeightDifference"/>
 *     &lt;enumeration value="WeightCredited"/>
 *     &lt;enumeration value="ValuationBilled"/>
 *     &lt;enumeration value="ValuationAccepted"/>
 *     &lt;enumeration value="ValuationDifference"/>
 *     &lt;enumeration value="ValuationCredited"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "CGO-ChargeAmount-Name", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum CGOChargeAmountName {

    @XmlEnumValue("WeightBilled")
    WEIGHT_BILLED("WeightBilled"),
    @XmlEnumValue("WeightAccepted")
    WEIGHT_ACCEPTED("WeightAccepted"),
    @XmlEnumValue("WeightDifference")
    WEIGHT_DIFFERENCE("WeightDifference"),
    @XmlEnumValue("WeightCredited")
    WEIGHT_CREDITED("WeightCredited"),
    @XmlEnumValue("ValuationBilled")
    VALUATION_BILLED("ValuationBilled"),
    @XmlEnumValue("ValuationAccepted")
    VALUATION_ACCEPTED("ValuationAccepted"),
    @XmlEnumValue("ValuationDifference")
    VALUATION_DIFFERENCE("ValuationDifference"),
    @XmlEnumValue("ValuationCredited")
    VALUATION_CREDITED("ValuationCredited");
    private final String value;

    CGOChargeAmountName(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static CGOChargeAmountName fromValue(String v) {
        for (CGOChargeAmountName c: CGOChargeAmountName.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
