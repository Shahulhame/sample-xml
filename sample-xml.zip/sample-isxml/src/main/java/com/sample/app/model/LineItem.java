
package com.sample.app.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}LineItemNumber"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}POLineItemNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ChargeCode"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ChargeBasis" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ChargeCodeType" minOccurs="0"/>
 *         &lt;element name="Description" type="{http://www.IATA.com/IATAAviationStandardDataTypes}AN240Base" minOccurs="0"/>
 *         &lt;element name="RejectionReasonCode" type="{http://www.IATA.com/IATAAviationStandardDataTypes}AN02Base" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProductID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}StartDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}EndDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}LocationCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}LocationCode_ICAO" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}LocationName" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}MinimumQuantityFlag" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Quantity" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}UnitPrice" minOccurs="0"/>
 *         &lt;element name="ChargeAmount" maxOccurs="2">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
 *                 &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}LineItemChargeAmount-Name" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Tax" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnCharges" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="TotalTaxAmount" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base" minOccurs="0"/>
 *         &lt;element name="TotalVATAmount" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base" minOccurs="0"/>
 *         &lt;element name="TotalAddOnChargeAmount" type="{http://www.IATA.com/IATAAviationStandardDataTypes}D183Base" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TotalNetAmount" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TotalAmountAfterSamplingConstant" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OriginalLineItemNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DetailCount" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}LineItemData" maxOccurs="10" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "lineItemNumber",
    "poLineItemNumber",
    "chargeCode",
    "chargeBasis",
    "chargeCodeType",
    "description",
    "rejectionReasonCode",
    "productID",
    "startDate",
    "endDate",
    "locationCode",
    "locationCodeICAO",
    "locationName",
    "minimumQuantityFlag",
    "quantity",
    "unitPrice",
    "chargeAmount",
    "tax",
    "addOnCharges",
    "totalTaxAmount",
    "totalVATAmount",
    "totalAddOnChargeAmount",
    "totalNetAmount",
    "totalAmountAfterSamplingConstant",
    "originalLineItemNumber",
    "detailCount",
    "lineItemData"
})
@XmlRootElement(name = "LineItem", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class LineItem {

    @XmlElement(name = "LineItemNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigInteger lineItemNumber;
    @XmlElement(name = "POLineItemNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger poLineItemNumber;
    @XmlElement(name = "ChargeCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String chargeCode;
    @XmlElement(name = "ChargeBasis", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected ChargeBasis chargeBasis;
    @XmlElement(name = "ChargeCodeType", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String chargeCodeType;
    @XmlElement(name = "Description", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String description;
    @XmlElement(name = "RejectionReasonCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String rejectionReasonCode;
    @XmlElement(name = "ProductID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String productID;
    @XmlElement(name = "StartDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String startDate;
    @XmlElement(name = "EndDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String endDate;
    @XmlElement(name = "LocationCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String locationCode;
    @XmlElement(name = "LocationCode_ICAO", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String locationCodeICAO;
    @XmlElement(name = "LocationName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String locationName;
    @XmlElement(name = "MinimumQuantityFlag", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected MinimumQuantityFlag minimumQuantityFlag;
    @XmlElement(name = "Quantity", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected Quantity quantity;
    @XmlElement(name = "UnitPrice", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected UnitPrice unitPrice;
    @XmlElement(name = "ChargeAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected List<LineItem.ChargeAmount> chargeAmount;
    @XmlElement(name = "Tax", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<Tax> tax;
    @XmlElement(name = "AddOnCharges", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<AddOnCharges> addOnCharges;
    @XmlElement(name = "TotalTaxAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal totalTaxAmount;
    @XmlElement(name = "TotalVATAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal totalVATAmount;
    @XmlElement(name = "TotalAddOnChargeAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal totalAddOnChargeAmount;
    @XmlElement(name = "TotalNetAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal totalNetAmount;
    @XmlElement(name = "TotalAmountAfterSamplingConstant", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal totalAmountAfterSamplingConstant;
    @XmlElement(name = "OriginalLineItemNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger originalLineItemNumber;
    @XmlElement(name = "DetailCount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger detailCount;
    @XmlElement(name = "LineItemData", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<LineItemData> lineItemData;

    /**
     * Gets the value of the lineItemNumber property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getLineItemNumber() {
        return lineItemNumber;
    }

    /**
     * Sets the value of the lineItemNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setLineItemNumber(BigInteger value) {
        this.lineItemNumber = value;
    }

    /**
     * Gets the value of the poLineItemNumber property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPOLineItemNumber() {
        return poLineItemNumber;
    }

    /**
     * Sets the value of the poLineItemNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPOLineItemNumber(BigInteger value) {
        this.poLineItemNumber = value;
    }

    /**
     * Gets the value of the chargeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChargeCode() {
        return chargeCode;
    }

    /**
     * Sets the value of the chargeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChargeCode(String value) {
        this.chargeCode = value;
    }

    /**
     * Gets the value of the chargeBasis property.
     * 
     * @return
     *     possible object is
     *     {@link ChargeBasis }
     *     
     */
    public ChargeBasis getChargeBasis() {
        return chargeBasis;
    }

    /**
     * Sets the value of the chargeBasis property.
     * 
     * @param value
     *     allowed object is
     *     {@link ChargeBasis }
     *     
     */
    public void setChargeBasis(ChargeBasis value) {
        this.chargeBasis = value;
    }

    /**
     * Gets the value of the chargeCodeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChargeCodeType() {
        return chargeCodeType;
    }

    /**
     * Sets the value of the chargeCodeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChargeCodeType(String value) {
        this.chargeCodeType = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the rejectionReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRejectionReasonCode() {
        return rejectionReasonCode;
    }

    /**
     * Sets the value of the rejectionReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRejectionReasonCode(String value) {
        this.rejectionReasonCode = value;
    }

    /**
     * Gets the value of the productID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductID() {
        return productID;
    }

    /**
     * Sets the value of the productID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductID(String value) {
        this.productID = value;
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartDate(String value) {
        this.startDate = value;
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndDate(String value) {
        this.endDate = value;
    }

    /**
     * Gets the value of the locationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationCode() {
        return locationCode;
    }

    /**
     * Sets the value of the locationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationCode(String value) {
        this.locationCode = value;
    }

    /**
     * Gets the value of the locationCodeICAO property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationCodeICAO() {
        return locationCodeICAO;
    }

    /**
     * Sets the value of the locationCodeICAO property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationCodeICAO(String value) {
        this.locationCodeICAO = value;
    }

    /**
     * Gets the value of the locationName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationName() {
        return locationName;
    }

    /**
     * Sets the value of the locationName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationName(String value) {
        this.locationName = value;
    }

    /**
     * Gets the value of the minimumQuantityFlag property.
     * 
     * @return
     *     possible object is
     *     {@link MinimumQuantityFlag }
     *     
     */
    public MinimumQuantityFlag getMinimumQuantityFlag() {
        return minimumQuantityFlag;
    }

    /**
     * Sets the value of the minimumQuantityFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinimumQuantityFlag }
     *     
     */
    public void setMinimumQuantityFlag(MinimumQuantityFlag value) {
        this.minimumQuantityFlag = value;
    }

    /**
     * Gets the value of the quantity property.
     * 
     * @return
     *     possible object is
     *     {@link Quantity }
     *     
     */
    public Quantity getQuantity() {
        return quantity;
    }

    /**
     * Sets the value of the quantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Quantity }
     *     
     */
    public void setQuantity(Quantity value) {
        this.quantity = value;
    }

    /**
     * Gets the value of the unitPrice property.
     * 
     * @return
     *     possible object is
     *     {@link UnitPrice }
     *     
     */
    public UnitPrice getUnitPrice() {
        return unitPrice;
    }

    /**
     * Sets the value of the unitPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link UnitPrice }
     *     
     */
    public void setUnitPrice(UnitPrice value) {
        this.unitPrice = value;
    }

    /**
     * Gets the value of the chargeAmount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the chargeAmount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getChargeAmount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LineItem.ChargeAmount }
     * 
     * 
     */
    public List<LineItem.ChargeAmount> getChargeAmount() {
        if (chargeAmount == null) {
            chargeAmount = new ArrayList<LineItem.ChargeAmount>();
        }
        return this.chargeAmount;
    }

    /**
     * Gets the value of the tax property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tax property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTax().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Tax }
     * 
     * 
     */
    public List<Tax> getTax() {
        if (tax == null) {
            tax = new ArrayList<Tax>();
        }
        return this.tax;
    }

    /**
     * Gets the value of the addOnCharges property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addOnCharges property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddOnCharges().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AddOnCharges }
     * 
     * 
     */
    public List<AddOnCharges> getAddOnCharges() {
        if (addOnCharges == null) {
            addOnCharges = new ArrayList<AddOnCharges>();
        }
        return this.addOnCharges;
    }

    /**
     * Gets the value of the totalTaxAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalTaxAmount() {
        return totalTaxAmount;
    }

    /**
     * Sets the value of the totalTaxAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalTaxAmount(BigDecimal value) {
        this.totalTaxAmount = value;
    }

    /**
     * Gets the value of the totalVATAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalVATAmount() {
        return totalVATAmount;
    }

    /**
     * Sets the value of the totalVATAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalVATAmount(BigDecimal value) {
        this.totalVATAmount = value;
    }

    /**
     * Gets the value of the totalAddOnChargeAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalAddOnChargeAmount() {
        return totalAddOnChargeAmount;
    }

    /**
     * Sets the value of the totalAddOnChargeAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalAddOnChargeAmount(BigDecimal value) {
        this.totalAddOnChargeAmount = value;
    }

    /**
     * Gets the value of the totalNetAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalNetAmount() {
        return totalNetAmount;
    }

    /**
     * Sets the value of the totalNetAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalNetAmount(BigDecimal value) {
        this.totalNetAmount = value;
    }

    /**
     * Gets the value of the totalAmountAfterSamplingConstant property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalAmountAfterSamplingConstant() {
        return totalAmountAfterSamplingConstant;
    }

    /**
     * Sets the value of the totalAmountAfterSamplingConstant property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalAmountAfterSamplingConstant(BigDecimal value) {
        this.totalAmountAfterSamplingConstant = value;
    }

    /**
     * Gets the value of the originalLineItemNumber property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getOriginalLineItemNumber() {
        return originalLineItemNumber;
    }

    /**
     * Sets the value of the originalLineItemNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setOriginalLineItemNumber(BigInteger value) {
        this.originalLineItemNumber = value;
    }

    /**
     * Gets the value of the detailCount property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDetailCount() {
        return detailCount;
    }

    /**
     * Sets the value of the detailCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDetailCount(BigInteger value) {
        this.detailCount = value;
    }

    /**
     * Gets the value of the lineItemData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the lineItemData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLineItemData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LineItemData }
     * 
     * 
     */
    public List<LineItemData> getLineItemData() {
        if (lineItemData == null) {
            lineItemData = new ArrayList<LineItemData>();
        }
        return this.lineItemData;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.IATA.com/IATAAviationStandardDataTypes>D183Base">
     *       &lt;attribute name="Name" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}LineItemChargeAmount-Name" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class ChargeAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "Name")
        protected LineItemChargeAmountName name;

        /**
         * Base used for numbers of type decimal(18,3)
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link LineItemChargeAmountName }
         *     
         */
        public LineItemChargeAmountName getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param value
         *     allowed object is
         *     {@link LineItemChargeAmountName }
         *     
         */
        public void setName(LineItemChargeAmountName value) {
            this.name = value;
        }

    }

}
