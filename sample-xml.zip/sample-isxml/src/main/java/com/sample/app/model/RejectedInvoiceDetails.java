
package com.sample.app.model;

import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}RejectionStage"/>
 *         &lt;element name="InvoiceNumber" type="{http://www.IATA.com/IATAAviationStandardDataTypes}AN10Base"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SettlementMonthPeriod"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "rejectionStage",
    "invoiceNumber",
    "settlementMonthPeriod"
})
@XmlRootElement(name = "RejectedInvoiceDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class RejectedInvoiceDetails {

    @XmlElement(name = "RejectionStage", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigInteger rejectionStage;
    @XmlElement(name = "InvoiceNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String invoiceNumber;
    @XmlElement(name = "SettlementMonthPeriod", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String settlementMonthPeriod;

    /**
     * Gets the value of the rejectionStage property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRejectionStage() {
        return rejectionStage;
    }

    /**
     * Sets the value of the rejectionStage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRejectionStage(BigInteger value) {
        this.rejectionStage = value;
    }

    /**
     * Gets the value of the invoiceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    /**
     * Sets the value of the invoiceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvoiceNumber(String value) {
        this.invoiceNumber = value;
    }

    /**
     * Gets the value of the settlementMonthPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSettlementMonthPeriod() {
        return settlementMonthPeriod;
    }

    /**
     * Sets the value of the settlementMonthPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSettlementMonthPeriod(String value) {
        this.settlementMonthPeriod = value;
    }

}
