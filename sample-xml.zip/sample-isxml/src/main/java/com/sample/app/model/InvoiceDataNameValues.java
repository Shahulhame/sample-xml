
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for InvoiceData-Name-Values.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="InvoiceData-Name-Values">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN30Base">
 *     &lt;enumeration value="SalesOrderNumber"/>
 *     &lt;enumeration value="SubmitUserID"/>
 *     &lt;enumeration value="PreviousInvoiceNumber"/>
 *     &lt;enumeration value="CustomerAccountNo"/>
 *     &lt;enumeration value="BuyerReference"/>
 *     &lt;enumeration value="CustomerAddressID"/>
 *     &lt;enumeration value="InvoiceTitle"/>
 *     &lt;enumeration value="PeriodFromDate"/>
 *     &lt;enumeration value="PeriodToDate"/>
 *     &lt;enumeration value="TestStatus"/>
 *     &lt;enumeration value="DocumentStatus"/>
 *     &lt;enumeration value="BuyerLanguage"/>
 *     &lt;enumeration value="PODate"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "InvoiceData-Name-Values", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum InvoiceDataNameValues {

    @XmlEnumValue("SalesOrderNumber")
    SALES_ORDER_NUMBER("SalesOrderNumber"),
    @XmlEnumValue("SubmitUserID")
    SUBMIT_USER_ID("SubmitUserID"),
    @XmlEnumValue("PreviousInvoiceNumber")
    PREVIOUS_INVOICE_NUMBER("PreviousInvoiceNumber"),
    @XmlEnumValue("CustomerAccountNo")
    CUSTOMER_ACCOUNT_NO("CustomerAccountNo"),
    @XmlEnumValue("BuyerReference")
    BUYER_REFERENCE("BuyerReference"),
    @XmlEnumValue("CustomerAddressID")
    CUSTOMER_ADDRESS_ID("CustomerAddressID"),
    @XmlEnumValue("InvoiceTitle")
    INVOICE_TITLE("InvoiceTitle"),
    @XmlEnumValue("PeriodFromDate")
    PERIOD_FROM_DATE("PeriodFromDate"),
    @XmlEnumValue("PeriodToDate")
    PERIOD_TO_DATE("PeriodToDate"),
    @XmlEnumValue("TestStatus")
    TEST_STATUS("TestStatus"),
    @XmlEnumValue("DocumentStatus")
    DOCUMENT_STATUS("DocumentStatus"),
    @XmlEnumValue("BuyerLanguage")
    BUYER_LANGUAGE("BuyerLanguage"),
    @XmlEnumValue("PODate")
    PO_DATE("PODate");
    private final String value;

    InvoiceDataNameValues(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static InvoiceDataNameValues fromValue(String v) {
        for (InvoiceDataNameValues c: InvoiceDataNameValues.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
