
package com.sample.app.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DigitalSignatureFlag"/>
 *         &lt;element name="SuspendedFlag" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}SuspendedFlag" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ISValidationFlag" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}RejectionFlag" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}RejectedInvoiceDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CorrespondenceFlag" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CorrespondenceDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProvisionalBillingMonth" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "digitalSignatureFlag",
    "suspendedFlag",
    "isValidationFlag",
    "rejectionFlag",
    "rejectedInvoiceDetails",
    "correspondenceFlag",
    "correspondenceDetails",
    "provisionalBillingMonth"
})
@XmlRootElement(name = "ISDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class ISDetails {

    @XmlElement(name = "DigitalSignatureFlag", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    @XmlSchemaType(name = "string")
    protected DigitalSignatureFlag digitalSignatureFlag;
    @XmlElement(name = "SuspendedFlag", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected SuspendedFlag suspendedFlag;
    @XmlElement(name = "ISValidationFlag", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String isValidationFlag;
    @XmlElement(name = "RejectionFlag", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected RejectionFlag rejectionFlag;
    @XmlElement(name = "RejectedInvoiceDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected RejectedInvoiceDetails rejectedInvoiceDetails;
    @XmlElement(name = "CorrespondenceFlag", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected CorrespondenceFlag correspondenceFlag;
    @XmlElement(name = "CorrespondenceDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected CorrespondenceDetails correspondenceDetails;
    @XmlElement(name = "ProvisionalBillingMonth", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String provisionalBillingMonth;

    /**
     * Gets the value of the digitalSignatureFlag property.
     * 
     * @return
     *     possible object is
     *     {@link DigitalSignatureFlag }
     *     
     */
    public DigitalSignatureFlag getDigitalSignatureFlag() {
        return digitalSignatureFlag;
    }

    /**
     * Sets the value of the digitalSignatureFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link DigitalSignatureFlag }
     *     
     */
    public void setDigitalSignatureFlag(DigitalSignatureFlag value) {
        this.digitalSignatureFlag = value;
    }

    /**
     * Gets the value of the suspendedFlag property.
     * 
     * @return
     *     possible object is
     *     {@link SuspendedFlag }
     *     
     */
    public SuspendedFlag getSuspendedFlag() {
        return suspendedFlag;
    }

    /**
     * Sets the value of the suspendedFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link SuspendedFlag }
     *     
     */
    public void setSuspendedFlag(SuspendedFlag value) {
        this.suspendedFlag = value;
    }

    /**
     * This will indicate if there is a Time Limit or a Minimum Amount validation Error.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISValidationFlag() {
        return isValidationFlag;
    }

    /**
     * Sets the value of the isValidationFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISValidationFlag(String value) {
        this.isValidationFlag = value;
    }

    /**
     * Gets the value of the rejectionFlag property.
     * 
     * @return
     *     possible object is
     *     {@link RejectionFlag }
     *     
     */
    public RejectionFlag getRejectionFlag() {
        return rejectionFlag;
    }

    /**
     * Sets the value of the rejectionFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link RejectionFlag }
     *     
     */
    public void setRejectionFlag(RejectionFlag value) {
        this.rejectionFlag = value;
    }

    /**
     * Gets the value of the rejectedInvoiceDetails property.
     * 
     * @return
     *     possible object is
     *     {@link RejectedInvoiceDetails }
     *     
     */
    public RejectedInvoiceDetails getRejectedInvoiceDetails() {
        return rejectedInvoiceDetails;
    }

    /**
     * Sets the value of the rejectedInvoiceDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link RejectedInvoiceDetails }
     *     
     */
    public void setRejectedInvoiceDetails(RejectedInvoiceDetails value) {
        this.rejectedInvoiceDetails = value;
    }

    /**
     * Gets the value of the correspondenceFlag property.
     * 
     * @return
     *     possible object is
     *     {@link CorrespondenceFlag }
     *     
     */
    public CorrespondenceFlag getCorrespondenceFlag() {
        return correspondenceFlag;
    }

    /**
     * Sets the value of the correspondenceFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link CorrespondenceFlag }
     *     
     */
    public void setCorrespondenceFlag(CorrespondenceFlag value) {
        this.correspondenceFlag = value;
    }

    /**
     * Gets the value of the correspondenceDetails property.
     * 
     * @return
     *     possible object is
     *     {@link CorrespondenceDetails }
     *     
     */
    public CorrespondenceDetails getCorrespondenceDetails() {
        return correspondenceDetails;
    }

    /**
     * Sets the value of the correspondenceDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link CorrespondenceDetails }
     *     
     */
    public void setCorrespondenceDetails(CorrespondenceDetails value) {
        this.correspondenceDetails = value;
    }

    /**
     * Gets the value of the provisionalBillingMonth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvisionalBillingMonth() {
        return provisionalBillingMonth;
    }

    /**
     * Sets the value of the provisionalBillingMonth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvisionalBillingMonth(String value) {
        this.provisionalBillingMonth = value;
    }

}
