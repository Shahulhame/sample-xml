
package com.sample.app.model;

import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AttachmentIndicatorOriginal" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AttachmentIndicatorValidated" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}NumberOfAttachments" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AttachmentID" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Description" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}FileSize" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "attachmentIndicatorOriginal",
    "attachmentIndicatorValidated",
    "numberOfAttachments",
    "attachmentID",
    "description",
    "fileSize"
})
@XmlRootElement(name = "Attachment", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class Attachment {

    @XmlElement(name = "AttachmentIndicatorOriginal", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected AttachmentIndicatorOriginalFlag attachmentIndicatorOriginal;
    @XmlElement(name = "AttachmentIndicatorValidated", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String attachmentIndicatorValidated;
    @XmlElement(name = "NumberOfAttachments", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger numberOfAttachments;
    @XmlElement(name = "AttachmentID", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String attachmentID;
    @XmlElement(name = "Description", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String description;
    @XmlElement(name = "FileSize", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger fileSize;

    /**
     * Gets the value of the attachmentIndicatorOriginal property.
     * 
     * @return
     *     possible object is
     *     {@link AttachmentIndicatorOriginalFlag }
     *     
     */
    public AttachmentIndicatorOriginalFlag getAttachmentIndicatorOriginal() {
        return attachmentIndicatorOriginal;
    }

    /**
     * Sets the value of the attachmentIndicatorOriginal property.
     * 
     * @param value
     *     allowed object is
     *     {@link AttachmentIndicatorOriginalFlag }
     *     
     */
    public void setAttachmentIndicatorOriginal(AttachmentIndicatorOriginalFlag value) {
        this.attachmentIndicatorOriginal = value;
    }

    /**
     * Gets the value of the attachmentIndicatorValidated property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttachmentIndicatorValidated() {
        return attachmentIndicatorValidated;
    }

    /**
     * Sets the value of the attachmentIndicatorValidated property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttachmentIndicatorValidated(String value) {
        this.attachmentIndicatorValidated = value;
    }

    /**
     * Gets the value of the numberOfAttachments property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNumberOfAttachments() {
        return numberOfAttachments;
    }

    /**
     * Sets the value of the numberOfAttachments property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNumberOfAttachments(BigInteger value) {
        this.numberOfAttachments = value;
    }

    /**
     * Gets the value of the attachmentID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttachmentID() {
        return attachmentID;
    }

    /**
     * Sets the value of the attachmentID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttachmentID(String value) {
        this.attachmentID = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the fileSize property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getFileSize() {
        return fileSize;
    }

    /**
     * Sets the value of the fileSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setFileSize(BigInteger value) {
        this.fileSize = value;
    }

}
