
package com.sample.app.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}BreakdownSerialNumber"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TicketIssuingAirline"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CouponNumber"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TicketDocNumber"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CheckDigit"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ChargeAmount" maxOccurs="6" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Tax" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnCharges" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TotalNetAmount"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}FromAirportCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ToAirportCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}NFPReasonCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AgreementIndicatorSupplied" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AgreementIndicatorValidated" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OriginalPMI" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ValidatedPMI" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SettlementAuthorizationCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ISValidationFlag" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CurrAdjustmentIndicator" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ElectronicTicketIndicator" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AirlineFlightDesignator" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}FlightNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}FlightDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CabinClass" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProrateMethodology" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ReasonCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ReferenceField10AN" maxOccurs="4" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ReferenceField20AN" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AirlineOwnUse20AN" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ProrateSlipBreakdown" maxOccurs="50" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Attachment" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "breakdownSerialNumber",
    "ticketIssuingAirline",
    "couponNumber",
    "ticketDocNumber",
    "checkDigit",
    "chargeAmount",
    "tax",
    "addOnCharges",
    "totalNetAmount",
    "fromAirportCode",
    "toAirportCode",
    "nfpReasonCode",
    "agreementIndicatorSupplied",
    "agreementIndicatorValidated",
    "originalPMI",
    "validatedPMI",
    "settlementAuthorizationCode",
    "isValidationFlag",
    "currAdjustmentIndicator",
    "electronicTicketIndicator",
    "airlineFlightDesignator",
    "flightNo",
    "flightDate",
    "cabinClass",
    "prorateMethodology",
    "reasonCode",
    "referenceField10AN",
    "referenceField20AN",
    "airlineOwnUse20AN",
    "prorateSlipBreakdown",
    "attachment"
})
@XmlRootElement(name = "BMCMCouponBreakdown", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class BMCMCouponBreakdown {

    @XmlElement(name = "BreakdownSerialNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigInteger breakdownSerialNumber;
    @XmlElement(name = "TicketIssuingAirline", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigInteger ticketIssuingAirline;
    @XmlElement(name = "CouponNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigInteger couponNumber;
    @XmlElement(name = "TicketDocNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigInteger ticketDocNumber;
    @XmlElement(name = "CheckDigit", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigInteger checkDigit;
    @XmlElement(name = "ChargeAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<ChargeAmount> chargeAmount;
    @XmlElement(name = "Tax", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<Tax> tax;
    @XmlElement(name = "AddOnCharges", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<AddOnCharges> addOnCharges;
    @XmlElement(name = "TotalNetAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigDecimal totalNetAmount;
    @XmlElement(name = "FromAirportCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String fromAirportCode;
    @XmlElement(name = "ToAirportCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String toAirportCode;
    @XmlElement(name = "NFPReasonCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String nfpReasonCode;
    @XmlElement(name = "AgreementIndicatorSupplied", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String agreementIndicatorSupplied;
    @XmlElement(name = "AgreementIndicatorValidated", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String agreementIndicatorValidated;
    @XmlElement(name = "OriginalPMI", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String originalPMI;
    @XmlElement(name = "ValidatedPMI", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String validatedPMI;
    @XmlElement(name = "SettlementAuthorizationCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String settlementAuthorizationCode;
    @XmlElement(name = "ISValidationFlag", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String isValidationFlag;
    @XmlElement(name = "CurrAdjustmentIndicator", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String currAdjustmentIndicator;
    @XmlElement(name = "ElectronicTicketIndicator", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected ElectronicTicketIndicator electronicTicketIndicator;
    @XmlElement(name = "AirlineFlightDesignator", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String airlineFlightDesignator;
    @XmlElement(name = "FlightNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger flightNo;
    @XmlElement(name = "FlightDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String flightDate;
    @XmlElement(name = "CabinClass", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String cabinClass;
    @XmlElement(name = "ProrateMethodology", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String prorateMethodology;
    @XmlElement(name = "ReasonCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String reasonCode;
    @XmlElement(name = "ReferenceField10AN", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<String> referenceField10AN;
    @XmlElement(name = "ReferenceField20AN", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String referenceField20AN;
    @XmlElement(name = "AirlineOwnUse20AN", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String airlineOwnUse20AN;
    @XmlElement(name = "ProrateSlipBreakdown", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<String> prorateSlipBreakdown;
    @XmlElement(name = "Attachment", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<Attachment> attachment;

    /**
     * Gets the value of the breakdownSerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getBreakdownSerialNumber() {
        return breakdownSerialNumber;
    }

    /**
     * Sets the value of the breakdownSerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setBreakdownSerialNumber(BigInteger value) {
        this.breakdownSerialNumber = value;
    }

    /**
     * Gets the value of the ticketIssuingAirline property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getTicketIssuingAirline() {
        return ticketIssuingAirline;
    }

    /**
     * Sets the value of the ticketIssuingAirline property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setTicketIssuingAirline(BigInteger value) {
        this.ticketIssuingAirline = value;
    }

    /**
     * Gets the value of the couponNumber property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCouponNumber() {
        return couponNumber;
    }

    /**
     * Sets the value of the couponNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCouponNumber(BigInteger value) {
        this.couponNumber = value;
    }

    /**
     * Gets the value of the ticketDocNumber property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getTicketDocNumber() {
        return ticketDocNumber;
    }

    /**
     * Sets the value of the ticketDocNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setTicketDocNumber(BigInteger value) {
        this.ticketDocNumber = value;
    }

    /**
     * Gets the value of the checkDigit property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCheckDigit() {
        return checkDigit;
    }

    /**
     * Sets the value of the checkDigit property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCheckDigit(BigInteger value) {
        this.checkDigit = value;
    }

    /**
     * Gets the value of the chargeAmount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the chargeAmount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getChargeAmount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ChargeAmount }
     * 
     * 
     */
    public List<ChargeAmount> getChargeAmount() {
        if (chargeAmount == null) {
            chargeAmount = new ArrayList<ChargeAmount>();
        }
        return this.chargeAmount;
    }

    /**
     * Gets the value of the tax property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tax property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTax().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Tax }
     * 
     * 
     */
    public List<Tax> getTax() {
        if (tax == null) {
            tax = new ArrayList<Tax>();
        }
        return this.tax;
    }

    /**
     * Gets the value of the addOnCharges property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addOnCharges property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddOnCharges().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AddOnCharges }
     * 
     * 
     */
    public List<AddOnCharges> getAddOnCharges() {
        if (addOnCharges == null) {
            addOnCharges = new ArrayList<AddOnCharges>();
        }
        return this.addOnCharges;
    }

    /**
     * Gets the value of the totalNetAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalNetAmount() {
        return totalNetAmount;
    }

    /**
     * Sets the value of the totalNetAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalNetAmount(BigDecimal value) {
        this.totalNetAmount = value;
    }

    /**
     * Gets the value of the fromAirportCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFromAirportCode() {
        return fromAirportCode;
    }

    /**
     * Sets the value of the fromAirportCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFromAirportCode(String value) {
        this.fromAirportCode = value;
    }

    /**
     * Gets the value of the toAirportCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToAirportCode() {
        return toAirportCode;
    }

    /**
     * Sets the value of the toAirportCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToAirportCode(String value) {
        this.toAirportCode = value;
    }

    /**
     * Gets the value of the nfpReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNFPReasonCode() {
        return nfpReasonCode;
    }

    /**
     * Sets the value of the nfpReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNFPReasonCode(String value) {
        this.nfpReasonCode = value;
    }

    /**
     * Gets the value of the agreementIndicatorSupplied property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgreementIndicatorSupplied() {
        return agreementIndicatorSupplied;
    }

    /**
     * Sets the value of the agreementIndicatorSupplied property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgreementIndicatorSupplied(String value) {
        this.agreementIndicatorSupplied = value;
    }

    /**
     * Gets the value of the agreementIndicatorValidated property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgreementIndicatorValidated() {
        return agreementIndicatorValidated;
    }

    /**
     * Sets the value of the agreementIndicatorValidated property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgreementIndicatorValidated(String value) {
        this.agreementIndicatorValidated = value;
    }

    /**
     * Gets the value of the originalPMI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalPMI() {
        return originalPMI;
    }

    /**
     * Sets the value of the originalPMI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalPMI(String value) {
        this.originalPMI = value;
    }

    /**
     * Gets the value of the validatedPMI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidatedPMI() {
        return validatedPMI;
    }

    /**
     * Sets the value of the validatedPMI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidatedPMI(String value) {
        this.validatedPMI = value;
    }

    /**
     * Gets the value of the settlementAuthorizationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSettlementAuthorizationCode() {
        return settlementAuthorizationCode;
    }

    /**
     * Sets the value of the settlementAuthorizationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSettlementAuthorizationCode(String value) {
        this.settlementAuthorizationCode = value;
    }

    /**
     * Gets the value of the isValidationFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISValidationFlag() {
        return isValidationFlag;
    }

    /**
     * Sets the value of the isValidationFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISValidationFlag(String value) {
        this.isValidationFlag = value;
    }

    /**
     * Gets the value of the currAdjustmentIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrAdjustmentIndicator() {
        return currAdjustmentIndicator;
    }

    /**
     * Sets the value of the currAdjustmentIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrAdjustmentIndicator(String value) {
        this.currAdjustmentIndicator = value;
    }

    /**
     * Gets the value of the electronicTicketIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link ElectronicTicketIndicator }
     *     
     */
    public ElectronicTicketIndicator getElectronicTicketIndicator() {
        return electronicTicketIndicator;
    }

    /**
     * Sets the value of the electronicTicketIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link ElectronicTicketIndicator }
     *     
     */
    public void setElectronicTicketIndicator(ElectronicTicketIndicator value) {
        this.electronicTicketIndicator = value;
    }

    /**
     * Gets the value of the airlineFlightDesignator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAirlineFlightDesignator() {
        return airlineFlightDesignator;
    }

    /**
     * Sets the value of the airlineFlightDesignator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAirlineFlightDesignator(String value) {
        this.airlineFlightDesignator = value;
    }

    /**
     * Gets the value of the flightNo property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getFlightNo() {
        return flightNo;
    }

    /**
     * Sets the value of the flightNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setFlightNo(BigInteger value) {
        this.flightNo = value;
    }

    /**
     * Gets the value of the flightDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlightDate() {
        return flightDate;
    }

    /**
     * Sets the value of the flightDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlightDate(String value) {
        this.flightDate = value;
    }

    /**
     * Gets the value of the cabinClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCabinClass() {
        return cabinClass;
    }

    /**
     * Sets the value of the cabinClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCabinClass(String value) {
        this.cabinClass = value;
    }

    /**
     * Gets the value of the prorateMethodology property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProrateMethodology() {
        return prorateMethodology;
    }

    /**
     * Sets the value of the prorateMethodology property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProrateMethodology(String value) {
        this.prorateMethodology = value;
    }

    /**
     * Gets the value of the reasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonCode() {
        return reasonCode;
    }

    /**
     * Sets the value of the reasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonCode(String value) {
        this.reasonCode = value;
    }

    /**
     * Gets the value of the referenceField10AN property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the referenceField10AN property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReferenceField10AN().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getReferenceField10AN() {
        if (referenceField10AN == null) {
            referenceField10AN = new ArrayList<String>();
        }
        return this.referenceField10AN;
    }

    /**
     * Gets the value of the referenceField20AN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferenceField20AN() {
        return referenceField20AN;
    }

    /**
     * Sets the value of the referenceField20AN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferenceField20AN(String value) {
        this.referenceField20AN = value;
    }

    /**
     * Gets the value of the airlineOwnUse20AN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAirlineOwnUse20AN() {
        return airlineOwnUse20AN;
    }

    /**
     * Sets the value of the airlineOwnUse20AN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAirlineOwnUse20AN(String value) {
        this.airlineOwnUse20AN = value;
    }

    /**
     * Gets the value of the prorateSlipBreakdown property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the prorateSlipBreakdown property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProrateSlipBreakdown().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getProrateSlipBreakdown() {
        if (prorateSlipBreakdown == null) {
            prorateSlipBreakdown = new ArrayList<String>();
        }
        return this.prorateSlipBreakdown;
    }

    /**
     * Gets the value of the attachment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the attachment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAttachment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Attachment }
     * 
     * 
     */
    public List<Attachment> getAttachment() {
        if (attachment == null) {
            attachment = new ArrayList<Attachment>();
        }
        return this.attachment;
    }

}
