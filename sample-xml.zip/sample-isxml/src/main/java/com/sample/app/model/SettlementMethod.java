
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SettlementMethod.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SettlementMethod">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN01Base">
 *     &lt;enumeration value="I"/>
 *     &lt;enumeration value="A"/>
 *     &lt;enumeration value="B"/>
 *     &lt;enumeration value="R"/>
 *     &lt;enumeration value="M"/>
 *     &lt;enumeration value="P"/>
 *     &lt;enumeration value="S"/>
 *     &lt;enumeration value="X"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "SettlementMethod", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum SettlementMethod {

    I,
    A,
    B,
    R,
    M,
    P,
    S,
    X;

    public String value() {
        return name();
    }

    public static SettlementMethod fromValue(String v) {
        return valueOf(v);
    }

}
