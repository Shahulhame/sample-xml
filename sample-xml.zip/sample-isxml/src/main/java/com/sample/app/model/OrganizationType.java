
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OrganizationType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="OrganizationType">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="ShipTo"/>
 *     &lt;enumeration value="RemitTo"/>
 *     &lt;enumeration value="Corporate"/>
 *     &lt;enumeration value="Affiliate"/>
 *     &lt;enumeration value="ServiceProvider"/>
 *     &lt;enumeration value="ServiceReceiver"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "OrganizationType", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum OrganizationType {

    @XmlEnumValue("ShipTo")
    SHIP_TO("ShipTo"),
    @XmlEnumValue("RemitTo")
    REMIT_TO("RemitTo"),
    @XmlEnumValue("Corporate")
    CORPORATE("Corporate"),
    @XmlEnumValue("Affiliate")
    AFFILIATE("Affiliate"),
    @XmlEnumValue("ServiceProvider")
    SERVICE_PROVIDER("ServiceProvider"),
    @XmlEnumValue("ServiceReceiver")
    SERVICE_RECEIVER("ServiceReceiver");
    private final String value;

    OrganizationType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static OrganizationType fromValue(String v) {
        for (OrganizationType c: OrganizationType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
