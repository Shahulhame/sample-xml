
package com.sample.app.model;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SignedForCurrencyCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SignedForAmount" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DailyExchangeRate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OriginalInvoiceNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OriginalInvoiceDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}RejectedCommissions" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}RejectedInvoiceNo" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}RejectedInvoiceDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}RejectionReasonCode" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "signedForCurrencyCode",
    "signedForAmount",
    "dailyExchangeRate",
    "originalInvoiceNumber",
    "originalInvoiceDate",
    "rejectedCommissions",
    "rejectedInvoiceNo",
    "rejectedInvoiceDate",
    "rejectionReasonCode"
})
@XmlRootElement(name = "UATPDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class UATPDetails {

    @XmlElement(name = "SignedForCurrencyCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String signedForCurrencyCode;
    @XmlElement(name = "SignedForAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal signedForAmount;
    @XmlElement(name = "DailyExchangeRate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal dailyExchangeRate;
    @XmlElement(name = "OriginalInvoiceNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String originalInvoiceNumber;
    @XmlElement(name = "OriginalInvoiceDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String originalInvoiceDate;
    @XmlElement(name = "RejectedCommissions", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal rejectedCommissions;
    @XmlElement(name = "RejectedInvoiceNo", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String rejectedInvoiceNo;
    @XmlElement(name = "RejectedInvoiceDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String rejectedInvoiceDate;
    @XmlElement(name = "RejectionReasonCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String rejectionReasonCode;

    /**
     * Gets the value of the signedForCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignedForCurrencyCode() {
        return signedForCurrencyCode;
    }

    /**
     * Sets the value of the signedForCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignedForCurrencyCode(String value) {
        this.signedForCurrencyCode = value;
    }

    /**
     * Gets the value of the signedForAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSignedForAmount() {
        return signedForAmount;
    }

    /**
     * Sets the value of the signedForAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSignedForAmount(BigDecimal value) {
        this.signedForAmount = value;
    }

    /**
     * Gets the value of the dailyExchangeRate property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDailyExchangeRate() {
        return dailyExchangeRate;
    }

    /**
     * Sets the value of the dailyExchangeRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDailyExchangeRate(BigDecimal value) {
        this.dailyExchangeRate = value;
    }

    /**
     * Gets the value of the originalInvoiceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalInvoiceNumber() {
        return originalInvoiceNumber;
    }

    /**
     * Sets the value of the originalInvoiceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalInvoiceNumber(String value) {
        this.originalInvoiceNumber = value;
    }

    /**
     * Gets the value of the originalInvoiceDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalInvoiceDate() {
        return originalInvoiceDate;
    }

    /**
     * Sets the value of the originalInvoiceDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalInvoiceDate(String value) {
        this.originalInvoiceDate = value;
    }

    /**
     * Gets the value of the rejectedCommissions property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getRejectedCommissions() {
        return rejectedCommissions;
    }

    /**
     * Sets the value of the rejectedCommissions property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setRejectedCommissions(BigDecimal value) {
        this.rejectedCommissions = value;
    }

    /**
     * Gets the value of the rejectedInvoiceNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRejectedInvoiceNo() {
        return rejectedInvoiceNo;
    }

    /**
     * Sets the value of the rejectedInvoiceNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRejectedInvoiceNo(String value) {
        this.rejectedInvoiceNo = value;
    }

    /**
     * Gets the value of the rejectedInvoiceDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRejectedInvoiceDate() {
        return rejectedInvoiceDate;
    }

    /**
     * Sets the value of the rejectedInvoiceDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRejectedInvoiceDate(String value) {
        this.rejectedInvoiceDate = value;
    }

    /**
     * Gets the value of the rejectionReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRejectionReasonCode() {
        return rejectionReasonCode;
    }

    /**
     * Sets the value of the rejectionReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRejectionReasonCode(String value) {
        this.rejectionReasonCode = value;
    }

}
