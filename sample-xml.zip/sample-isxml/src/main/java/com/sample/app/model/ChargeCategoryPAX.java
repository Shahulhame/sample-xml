
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ChargeCategoryPAX.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ChargeCategoryPAX">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="Pax Non Sample"/>
 *     &lt;enumeration value="Pax Sample Form AB"/>
 *     &lt;enumeration value="Pax Sample Form DE"/>
 *     &lt;enumeration value="Pax Sample Form F"/>
 *     &lt;enumeration value="Pax Sample Form XF"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ChargeCategoryPAX", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum ChargeCategoryPAX {

    @XmlEnumValue("Pax Non Sample")
    PAX_NON_SAMPLE("Pax Non Sample"),
    @XmlEnumValue("Pax Sample Form AB")
    PAX_SAMPLE_FORM_AB("Pax Sample Form AB"),
    @XmlEnumValue("Pax Sample Form DE")
    PAX_SAMPLE_FORM_DE("Pax Sample Form DE"),
    @XmlEnumValue("Pax Sample Form F")
    PAX_SAMPLE_FORM_F("Pax Sample Form F"),
    @XmlEnumValue("Pax Sample Form XF")
    PAX_SAMPLE_FORM_XF("Pax Sample Form XF");
    private final String value;

    ChargeCategoryPAX(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ChargeCategoryPAX fromValue(String v) {
        for (ChargeCategoryPAX c: ChargeCategoryPAX.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
