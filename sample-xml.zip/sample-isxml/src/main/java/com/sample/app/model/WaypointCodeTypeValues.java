
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WaypointCode-Type-Values.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="WaypointCode-Type-Values">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="Entry"/>
 *     &lt;enumeration value="Exit"/>
 *     &lt;enumeration value="Intermediate"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "WaypointCode-Type-Values", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum WaypointCodeTypeValues {

    @XmlEnumValue("Entry")
    ENTRY("Entry"),
    @XmlEnumValue("Exit")
    EXIT("Exit"),
    @XmlEnumValue("Intermediate")
    INTERMEDIATE("Intermediate");
    private final String value;

    WaypointCodeTypeValues(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static WaypointCodeTypeValues fromValue(String v) {
        for (WaypointCodeTypeValues c: WaypointCodeTypeValues.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
