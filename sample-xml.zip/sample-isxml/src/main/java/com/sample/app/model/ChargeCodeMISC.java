
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ChargeCodeMISC.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ChargeCodeMISC">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="Approach"/>
 *     &lt;enumeration value="Communication"/>
 *     &lt;enumeration value="En-Route"/>
 *     &lt;enumeration value="Fees"/>
 *     &lt;enumeration value="Lighting"/>
 *     &lt;enumeration value="Meteorology"/>
 *     &lt;enumeration value="Oceanic"/>
 *     &lt;enumeration value="Over-flight"/>
 *     &lt;enumeration value="Parking"/>
 *     &lt;enumeration value="Passenger Services"/>
 *     &lt;enumeration value="Runway Charges"/>
 *     &lt;enumeration value="Security"/>
 *     &lt;enumeration value="Block Space"/>
 *     &lt;enumeration value="Code Share"/>
 *     &lt;enumeration value="Commission"/>
 *     &lt;enumeration value="Storage"/>
 *     &lt;enumeration value="ULD Demurrage"/>
 *     &lt;enumeration value="Handling LM"/>
 *     &lt;enumeration value="Lease"/>
 *     &lt;enumeration value="Loans"/>
 *     &lt;enumeration value="MRO Maintenance"/>
 *     &lt;enumeration value="MRO Repairs and Overhaul"/>
 *     &lt;enumeration value="Sales and Purchase"/>
 *     &lt;enumeration value="Pool"/>
 *     &lt;enumeration value="Rent"/>
 *     &lt;enumeration value="Assessment"/>
 *     &lt;enumeration value="BSP"/>
 *     &lt;enumeration value="CASS"/>
 *     &lt;enumeration value="CDA"/>
 *     &lt;enumeration value="Fees"/>
 *     &lt;enumeration value="FF Miles"/>
 *     &lt;enumeration value="Publication"/>
 *     &lt;enumeration value="Meetings and Conferences"/>
 *     &lt;enumeration value="Training"/>
 *     &lt;enumeration value="GDS"/>
 *     &lt;enumeration value="Aviation Fuel"/>
 *     &lt;enumeration value="Motor Fuel"/>
 *     &lt;enumeration value="Baggage"/>
 *     &lt;enumeration value="Baggage Delivery"/>
 *     &lt;enumeration value="Cargo Handling"/>
 *     &lt;enumeration value="Catering"/>
 *     &lt;enumeration value="Cleaning"/>
 *     &lt;enumeration value="Crew Accommodation"/>
 *     &lt;enumeration value="Crew Transportation"/>
 *     &lt;enumeration value="Customs Service Charge"/>
 *     &lt;enumeration value="Deicing"/>
 *     &lt;enumeration value="Departure Stamps"/>
 *     &lt;enumeration value="Immigration Fines"/>
 *     &lt;enumeration value="Lounge"/>
 *     &lt;enumeration value="Mishandling Baggage"/>
 *     &lt;enumeration value="Mishandling Passenger"/>
 *     &lt;enumeration value="Passenger Handling"/>
 *     &lt;enumeration value="Passenger Transportation"/>
 *     &lt;enumeration value="Passenger Security"/>
 *     &lt;enumeration value="Ramp Handling"/>
 *     &lt;enumeration value="Rent Equipment"/>
 *     &lt;enumeration value="Stand"/>
 *     &lt;enumeration value="STPC"/>
 *     &lt;enumeration value="Application Charges"/>
 *     &lt;enumeration value="Communication Charges"/>
 *     &lt;enumeration value="Financial Charges"/>
 *     &lt;enumeration value="Adjustments"/>
 *     &lt;enumeration value="Deposit"/>
 *     &lt;enumeration value="Interest"/>
 *     &lt;enumeration value="Legal"/>
 *     &lt;enumeration value="Penalty"/>
 *     &lt;enumeration value="Taxes"/>
 *     &lt;enumeration value="Block Space"/>
 *     &lt;enumeration value="Joint Venture"/>
 *     &lt;enumeration value="Promotion"/>
 *     &lt;enumeration value="Rent"/>
 *     &lt;enumeration value="Misc"/>
 *     &lt;enumeration value="Mail"/>
 *     &lt;enumeration value="Fees"/>
 *     &lt;enumeration value="Misc"/>
 *     &lt;enumeration value="GSA Contract"/>
 *     &lt;enumeration value="Utilities"/>
 *     &lt;enumeration value="Hotel"/>
 *     &lt;enumeration value="Limousine"/>
 *     &lt;enumeration value="Trucking"/>
 *     &lt;enumeration value="Pass and ID"/>
 *     &lt;enumeration value="FastTrack"/>
 *     &lt;enumeration value="Space Rental"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ChargeCodeMISC", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum ChargeCodeMISC {

    @XmlEnumValue("Approach")
    APPROACH("Approach"),
    @XmlEnumValue("Communication")
    COMMUNICATION("Communication"),
    @XmlEnumValue("En-Route")
    EN_ROUTE("En-Route"),
    @XmlEnumValue("Fees")
    FEES("Fees"),
    @XmlEnumValue("Lighting")
    LIGHTING("Lighting"),
    @XmlEnumValue("Meteorology")
    METEOROLOGY("Meteorology"),
    @XmlEnumValue("Oceanic")
    OCEANIC("Oceanic"),
    @XmlEnumValue("Over-flight")
    OVER_FLIGHT("Over-flight"),
    @XmlEnumValue("Parking")
    PARKING("Parking"),
    @XmlEnumValue("Passenger Services")
    PASSENGER_SERVICES("Passenger Services"),
    @XmlEnumValue("Runway Charges")
    RUNWAY_CHARGES("Runway Charges"),
    @XmlEnumValue("Security")
    SECURITY("Security"),
    @XmlEnumValue("Block Space")
    BLOCK_SPACE("Block Space"),
    @XmlEnumValue("Code Share")
    CODE_SHARE("Code Share"),
    @XmlEnumValue("Commission")
    COMMISSION("Commission"),
    @XmlEnumValue("Storage")
    STORAGE("Storage"),
    @XmlEnumValue("ULD Demurrage")
    ULD_DEMURRAGE("ULD Demurrage"),
    @XmlEnumValue("Handling LM")
    HANDLING_LM("Handling LM"),
    @XmlEnumValue("Lease")
    LEASE("Lease"),
    @XmlEnumValue("Loans")
    LOANS("Loans"),
    @XmlEnumValue("MRO Maintenance")
    MRO_MAINTENANCE("MRO Maintenance"),
    @XmlEnumValue("MRO Repairs and Overhaul")
    MRO_REPAIRS_AND_OVERHAUL("MRO Repairs and Overhaul"),
    @XmlEnumValue("Sales and Purchase")
    SALES_AND_PURCHASE("Sales and Purchase"),
    @XmlEnumValue("Pool")
    POOL("Pool"),
    @XmlEnumValue("Rent")
    RENT("Rent"),
    @XmlEnumValue("Assessment")
    ASSESSMENT("Assessment"),
    BSP("BSP"),
    CASS("CASS"),
    CDA("CDA"),
    @XmlEnumValue("FF Miles")
    FF_MILES("FF Miles"),
    @XmlEnumValue("Publication")
    PUBLICATION("Publication"),
    @XmlEnumValue("Meetings and Conferences")
    MEETINGS_AND_CONFERENCES("Meetings and Conferences"),
    @XmlEnumValue("Training")
    TRAINING("Training"),
    GDS("GDS"),
    @XmlEnumValue("Aviation Fuel")
    AVIATION_FUEL("Aviation Fuel"),
    @XmlEnumValue("Motor Fuel")
    MOTOR_FUEL("Motor Fuel"),
    @XmlEnumValue("Baggage")
    BAGGAGE("Baggage"),
    @XmlEnumValue("Baggage Delivery")
    BAGGAGE_DELIVERY("Baggage Delivery"),
    @XmlEnumValue("Cargo Handling")
    CARGO_HANDLING("Cargo Handling"),
    @XmlEnumValue("Catering")
    CATERING("Catering"),
    @XmlEnumValue("Cleaning")
    CLEANING("Cleaning"),
    @XmlEnumValue("Crew Accommodation")
    CREW_ACCOMMODATION("Crew Accommodation"),
    @XmlEnumValue("Crew Transportation")
    CREW_TRANSPORTATION("Crew Transportation"),
    @XmlEnumValue("Customs Service Charge")
    CUSTOMS_SERVICE_CHARGE("Customs Service Charge"),
    @XmlEnumValue("Deicing")
    DEICING("Deicing"),
    @XmlEnumValue("Departure Stamps")
    DEPARTURE_STAMPS("Departure Stamps"),
    @XmlEnumValue("Immigration Fines")
    IMMIGRATION_FINES("Immigration Fines"),
    @XmlEnumValue("Lounge")
    LOUNGE("Lounge"),
    @XmlEnumValue("Mishandling Baggage")
    MISHANDLING_BAGGAGE("Mishandling Baggage"),
    @XmlEnumValue("Mishandling Passenger")
    MISHANDLING_PASSENGER("Mishandling Passenger"),
    @XmlEnumValue("Passenger Handling")
    PASSENGER_HANDLING("Passenger Handling"),
    @XmlEnumValue("Passenger Transportation")
    PASSENGER_TRANSPORTATION("Passenger Transportation"),
    @XmlEnumValue("Passenger Security")
    PASSENGER_SECURITY("Passenger Security"),
    @XmlEnumValue("Ramp Handling")
    RAMP_HANDLING("Ramp Handling"),
    @XmlEnumValue("Rent Equipment")
    RENT_EQUIPMENT("Rent Equipment"),
    @XmlEnumValue("Stand")
    STAND("Stand"),
    STPC("STPC"),
    @XmlEnumValue("Application Charges")
    APPLICATION_CHARGES("Application Charges"),
    @XmlEnumValue("Communication Charges")
    COMMUNICATION_CHARGES("Communication Charges"),
    @XmlEnumValue("Financial Charges")
    FINANCIAL_CHARGES("Financial Charges"),
    @XmlEnumValue("Adjustments")
    ADJUSTMENTS("Adjustments"),
    @XmlEnumValue("Deposit")
    DEPOSIT("Deposit"),
    @XmlEnumValue("Interest")
    INTEREST("Interest"),
    @XmlEnumValue("Legal")
    LEGAL("Legal"),
    @XmlEnumValue("Penalty")
    PENALTY("Penalty"),
    @XmlEnumValue("Taxes")
    TAXES("Taxes"),
    @XmlEnumValue("Joint Venture")
    JOINT_VENTURE("Joint Venture"),
    @XmlEnumValue("Promotion")
    PROMOTION("Promotion"),
    @XmlEnumValue("Misc")
    MISC("Misc"),
    @XmlEnumValue("Mail")
    MAIL("Mail"),
    @XmlEnumValue("GSA Contract")
    GSA_CONTRACT("GSA Contract"),
    @XmlEnumValue("Utilities")
    UTILITIES("Utilities"),
    @XmlEnumValue("Hotel")
    HOTEL("Hotel"),
    @XmlEnumValue("Limousine")
    LIMOUSINE("Limousine"),
    @XmlEnumValue("Trucking")
    TRUCKING("Trucking"),
    @XmlEnumValue("Pass and ID")
    PASS_AND_ID("Pass and ID"),
    @XmlEnumValue("FastTrack")
    FAST_TRACK("FastTrack"),
    @XmlEnumValue("Space Rental")
    SPACE_RENTAL("Space Rental");
    private final String value;

    ChargeCodeMISC(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ChargeCodeMISC fromValue(String v) {
        for (ChargeCodeMISC c: ChargeCodeMISC.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
