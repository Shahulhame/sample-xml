
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UOMCodeBaseTemp.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="UOMCodeBaseTemp">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN03Base">
 *     &lt;enumeration value="CEL"/>
 *     &lt;enumeration value="FAH"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "UOMCodeBaseTemp", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum UOMCodeBaseTemp {

    CEL,
    FAH;

    public String value() {
        return name();
    }

    public static UOMCodeBaseTemp fromValue(String v) {
        return valueOf(v);
    }

}
