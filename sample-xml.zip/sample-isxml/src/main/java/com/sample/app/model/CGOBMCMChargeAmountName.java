
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CGO-BMCM-ChargeAmount-Name.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CGO-BMCM-ChargeAmount-Name">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="WeightBilled"/>
 *     &lt;enumeration value="WeightCredited"/>
 *     &lt;enumeration value="ValuationBilled"/>
 *     &lt;enumeration value="ValuationCredited"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "CGO-BMCM-ChargeAmount-Name", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum CGOBMCMChargeAmountName {

    @XmlEnumValue("WeightBilled")
    WEIGHT_BILLED("WeightBilled"),
    @XmlEnumValue("WeightCredited")
    WEIGHT_CREDITED("WeightCredited"),
    @XmlEnumValue("ValuationBilled")
    VALUATION_BILLED("ValuationBilled"),
    @XmlEnumValue("ValuationCredited")
    VALUATION_CREDITED("ValuationCredited");
    private final String value;

    CGOBMCMChargeAmountName(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static CGOBMCMChargeAmountName fromValue(String v) {
        for (CGOBMCMChargeAmountName c: CGOBMCMChargeAmountName.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
