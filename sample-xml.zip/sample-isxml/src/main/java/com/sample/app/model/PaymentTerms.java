
package com.sample.app.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CurrencyCode"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ClearanceCurrencyCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ExchangeRate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SettlementMonthPeriod" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SettlementMethod" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PaymentTermsType" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Description" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DateBasis" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DiscountPercent" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DiscountDueDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}DiscountDueDays" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}NetDueDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}NetDueDays" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PaymentData" maxOccurs="20" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CHAgreementIndicator" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "currencyCode",
    "clearanceCurrencyCode",
    "exchangeRate",
    "settlementMonthPeriod",
    "settlementMethod",
    "paymentTermsType",
    "description",
    "dateBasis",
    "discountPercent",
    "discountDueDate",
    "discountDueDays",
    "netDueDate",
    "netDueDays",
    "paymentData",
    "chAgreementIndicator"
})
@XmlRootElement(name = "PaymentTerms", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class PaymentTerms {

    @XmlElement(name = "CurrencyCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String currencyCode;
    @XmlElement(name = "ClearanceCurrencyCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String clearanceCurrencyCode;
    @XmlElement(name = "ExchangeRate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal exchangeRate;
    @XmlElement(name = "SettlementMonthPeriod", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String settlementMonthPeriod;
    @XmlElement(name = "SettlementMethod", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected SettlementMethod settlementMethod;
    @XmlElement(name = "PaymentTermsType", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String paymentTermsType;
    @XmlElement(name = "Description", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String description;
    @XmlElement(name = "DateBasis", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    @XmlSchemaType(name = "string")
    protected DateBasis dateBasis;
    @XmlElement(name = "DiscountPercent", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal discountPercent;
    @XmlElement(name = "DiscountDueDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String discountDueDate;
    @XmlElement(name = "DiscountDueDays", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger discountDueDays;
    @XmlElement(name = "NetDueDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String netDueDate;
    @XmlElement(name = "NetDueDays", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger netDueDays;
    @XmlElement(name = "PaymentData", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<PaymentData> paymentData;
    @XmlElement(name = "CHAgreementIndicator", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String chAgreementIndicator;

    /**
     * Gets the value of the currencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCode() {
        return currencyCode;
    }

    /**
     * Sets the value of the currencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCode(String value) {
        this.currencyCode = value;
    }

    /**
     * Gets the value of the clearanceCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClearanceCurrencyCode() {
        return clearanceCurrencyCode;
    }

    /**
     * Sets the value of the clearanceCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClearanceCurrencyCode(String value) {
        this.clearanceCurrencyCode = value;
    }

    /**
     * Gets the value of the exchangeRate property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getExchangeRate() {
        return exchangeRate;
    }

    /**
     * Sets the value of the exchangeRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setExchangeRate(BigDecimal value) {
        this.exchangeRate = value;
    }

    /**
     * Gets the value of the settlementMonthPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSettlementMonthPeriod() {
        return settlementMonthPeriod;
    }

    /**
     * Sets the value of the settlementMonthPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSettlementMonthPeriod(String value) {
        this.settlementMonthPeriod = value;
    }

    /**
     * Gets the value of the settlementMethod property.
     * 
     * @return
     *     possible object is
     *     {@link SettlementMethod }
     *     
     */
    public SettlementMethod getSettlementMethod() {
        return settlementMethod;
    }

    /**
     * Sets the value of the settlementMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link SettlementMethod }
     *     
     */
    public void setSettlementMethod(SettlementMethod value) {
        this.settlementMethod = value;
    }

    /**
     * Gets the value of the paymentTermsType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentTermsType() {
        return paymentTermsType;
    }

    /**
     * Sets the value of the paymentTermsType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentTermsType(String value) {
        this.paymentTermsType = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the dateBasis property.
     * 
     * @return
     *     possible object is
     *     {@link DateBasis }
     *     
     */
    public DateBasis getDateBasis() {
        return dateBasis;
    }

    /**
     * Sets the value of the dateBasis property.
     * 
     * @param value
     *     allowed object is
     *     {@link DateBasis }
     *     
     */
    public void setDateBasis(DateBasis value) {
        this.dateBasis = value;
    }

    /**
     * Gets the value of the discountPercent property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDiscountPercent() {
        return discountPercent;
    }

    /**
     * Sets the value of the discountPercent property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDiscountPercent(BigDecimal value) {
        this.discountPercent = value;
    }

    /**
     * Gets the value of the discountDueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDiscountDueDate() {
        return discountDueDate;
    }

    /**
     * Sets the value of the discountDueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDiscountDueDate(String value) {
        this.discountDueDate = value;
    }

    /**
     * Gets the value of the discountDueDays property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDiscountDueDays() {
        return discountDueDays;
    }

    /**
     * Sets the value of the discountDueDays property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDiscountDueDays(BigInteger value) {
        this.discountDueDays = value;
    }

    /**
     * Gets the value of the netDueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetDueDate() {
        return netDueDate;
    }

    /**
     * Sets the value of the netDueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetDueDate(String value) {
        this.netDueDate = value;
    }

    /**
     * Gets the value of the netDueDays property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNetDueDays() {
        return netDueDays;
    }

    /**
     * Sets the value of the netDueDays property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNetDueDays(BigInteger value) {
        this.netDueDays = value;
    }

    /**
     * Gets the value of the paymentData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the paymentData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPaymentData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PaymentData }
     * 
     * 
     */
    public List<PaymentData> getPaymentData() {
        if (paymentData == null) {
            paymentData = new ArrayList<PaymentData>();
        }
        return this.paymentData;
    }

    /**
     * Gets the value of the chAgreementIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCHAgreementIndicator() {
        return chAgreementIndicator;
    }

    /**
     * Sets the value of the chAgreementIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCHAgreementIndicator(String value) {
        this.chAgreementIndicator = value;
    }

}
