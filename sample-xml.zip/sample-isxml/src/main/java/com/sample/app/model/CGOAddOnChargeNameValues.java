
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CGO-AddOnChargeName-Values.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CGO-AddOnChargeName-Values">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN30Base">
 *     &lt;enumeration value="ISCAllowed"/>
 *     &lt;enumeration value="OtherChargesAllowed"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "CGO-AddOnChargeName-Values", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum CGOAddOnChargeNameValues {

    @XmlEnumValue("ISCAllowed")
    ISC_ALLOWED("ISCAllowed"),
    @XmlEnumValue("OtherChargesAllowed")
    OTHER_CHARGES_ALLOWED("OtherChargesAllowed");
    private final String value;

    CGOAddOnChargeNameValues(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static CGOAddOnChargeNameValues fromValue(String v) {
        for (CGOAddOnChargeNameValues c: CGOAddOnChargeNameValues.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
