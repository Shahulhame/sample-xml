package com.sample.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sample.app.repository.entity.MiscBillingInvTransSummary;

@Repository
public interface TransmissionSummaryRepository extends JpaRepository<MiscBillingInvTransSummary, Integer> {

}
