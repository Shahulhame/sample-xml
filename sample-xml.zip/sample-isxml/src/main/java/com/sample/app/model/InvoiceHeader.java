
package com.sample.app.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}InvoiceNumber"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}InvoiceDate"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}InvoiceType"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxInvoiceNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}TaxPointDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}LocationCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}LocationCode_ICAO" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}LocationName" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ChargeCategory"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SellerOrganization"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}BuyerOrganization"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OtherOrganization" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PaymentTerms"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ISDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PONumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}InvoiceData" maxOccurs="20" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Notes" maxOccurs="10" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Attachment" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Layout" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}InvoiceTemplateLanguage" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "invoiceNumber",
    "invoiceDate",
    "invoiceType",
    "taxInvoiceNumber",
    "taxPointDate",
    "locationCode",
    "locationCodeICAO",
    "locationName",
    "chargeCategory",
    "sellerOrganization",
    "buyerOrganization",
    "otherOrganization",
    "paymentTerms",
    "isDetails",
    "poNumber",
    "invoiceData",
    "notes",
    "attachment",
    "layout",
    "invoiceTemplateLanguage"
})
@XmlRootElement(name = "InvoiceHeader", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class InvoiceHeader {

    @XmlElement(name = "InvoiceNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String invoiceNumber;
    @XmlElement(name = "InvoiceDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String invoiceDate;
    @XmlElement(name = "InvoiceType", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    @XmlSchemaType(name = "string")
    protected InvoiceType invoiceType;
    @XmlElement(name = "TaxInvoiceNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String taxInvoiceNumber;
    @XmlElement(name = "TaxPointDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String taxPointDate;
    @XmlElement(name = "LocationCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String locationCode;
    @XmlElement(name = "LocationCode_ICAO", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String locationCodeICAO;
    @XmlElement(name = "LocationName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String locationName;
    @XmlElement(name = "ChargeCategory", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String chargeCategory;
    @XmlElement(name = "SellerOrganization", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected SellerOrganization sellerOrganization;
    @XmlElement(name = "BuyerOrganization", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BuyerOrganization buyerOrganization;
    @XmlElement(name = "OtherOrganization", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<OtherOrganization> otherOrganization;
    @XmlElement(name = "PaymentTerms", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected PaymentTerms paymentTerms;
    @XmlElement(name = "ISDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected ISDetails isDetails;
    @XmlElement(name = "PONumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String poNumber;
    @XmlElement(name = "InvoiceData", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<InvoiceData> invoiceData;
    @XmlElement(name = "Notes", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<Notes> notes;
    @XmlElement(name = "Attachment", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<Attachment> attachment;
    @XmlElement(name = "Layout", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected Layout layout;
    @XmlElement(name = "InvoiceTemplateLanguage", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String invoiceTemplateLanguage;

    /**
     * Gets the value of the invoiceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    /**
     * Sets the value of the invoiceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvoiceNumber(String value) {
        this.invoiceNumber = value;
    }

    /**
     * Gets the value of the invoiceDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvoiceDate() {
        return invoiceDate;
    }

    /**
     * Sets the value of the invoiceDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvoiceDate(String value) {
        this.invoiceDate = value;
    }

    /**
     * Gets the value of the invoiceType property.
     * 
     * @return
     *     possible object is
     *     {@link InvoiceType }
     *     
     */
    public InvoiceType getInvoiceType() {
        return invoiceType;
    }

    /**
     * Sets the value of the invoiceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link InvoiceType }
     *     
     */
    public void setInvoiceType(InvoiceType value) {
        this.invoiceType = value;
    }

    /**
     * Gets the value of the taxInvoiceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxInvoiceNumber() {
        return taxInvoiceNumber;
    }

    /**
     * Sets the value of the taxInvoiceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxInvoiceNumber(String value) {
        this.taxInvoiceNumber = value;
    }

    /**
     * Gets the value of the taxPointDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxPointDate() {
        return taxPointDate;
    }

    /**
     * Sets the value of the taxPointDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxPointDate(String value) {
        this.taxPointDate = value;
    }

    /**
     * Gets the value of the locationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationCode() {
        return locationCode;
    }

    /**
     * Sets the value of the locationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationCode(String value) {
        this.locationCode = value;
    }

    /**
     * Gets the value of the locationCodeICAO property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationCodeICAO() {
        return locationCodeICAO;
    }

    /**
     * Sets the value of the locationCodeICAO property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationCodeICAO(String value) {
        this.locationCodeICAO = value;
    }

    /**
     * Gets the value of the locationName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationName() {
        return locationName;
    }

    /**
     * Sets the value of the locationName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationName(String value) {
        this.locationName = value;
    }

    /**
     * Gets the value of the chargeCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChargeCategory() {
        return chargeCategory;
    }

    /**
     * Sets the value of the chargeCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChargeCategory(String value) {
        this.chargeCategory = value;
    }

    /**
     * Gets the value of the sellerOrganization property.
     * 
     * @return
     *     possible object is
     *     {@link SellerOrganization }
     *     
     */
    public SellerOrganization getSellerOrganization() {
        return sellerOrganization;
    }

    /**
     * Sets the value of the sellerOrganization property.
     * 
     * @param value
     *     allowed object is
     *     {@link SellerOrganization }
     *     
     */
    public void setSellerOrganization(SellerOrganization value) {
        this.sellerOrganization = value;
    }

    /**
     * Gets the value of the buyerOrganization property.
     * 
     * @return
     *     possible object is
     *     {@link BuyerOrganization }
     *     
     */
    public BuyerOrganization getBuyerOrganization() {
        return buyerOrganization;
    }

    /**
     * Sets the value of the buyerOrganization property.
     * 
     * @param value
     *     allowed object is
     *     {@link BuyerOrganization }
     *     
     */
    public void setBuyerOrganization(BuyerOrganization value) {
        this.buyerOrganization = value;
    }

    /**
     * Gets the value of the otherOrganization property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the otherOrganization property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOtherOrganization().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OtherOrganization }
     * 
     * 
     */
    public List<OtherOrganization> getOtherOrganization() {
        if (otherOrganization == null) {
            otherOrganization = new ArrayList<OtherOrganization>();
        }
        return this.otherOrganization;
    }

    /**
     * Gets the value of the paymentTerms property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentTerms }
     *     
     */
    public PaymentTerms getPaymentTerms() {
        return paymentTerms;
    }

    /**
     * Sets the value of the paymentTerms property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentTerms }
     *     
     */
    public void setPaymentTerms(PaymentTerms value) {
        this.paymentTerms = value;
    }

    /**
     * Gets the value of the isDetails property.
     * 
     * @return
     *     possible object is
     *     {@link ISDetails }
     *     
     */
    public ISDetails getISDetails() {
        return isDetails;
    }

    /**
     * Sets the value of the isDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link ISDetails }
     *     
     */
    public void setISDetails(ISDetails value) {
        this.isDetails = value;
    }

    /**
     * Gets the value of the poNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPONumber() {
        return poNumber;
    }

    /**
     * Sets the value of the poNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPONumber(String value) {
        this.poNumber = value;
    }

    /**
     * Gets the value of the invoiceData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the invoiceData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvoiceData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvoiceData }
     * 
     * 
     */
    public List<InvoiceData> getInvoiceData() {
        if (invoiceData == null) {
            invoiceData = new ArrayList<InvoiceData>();
        }
        return this.invoiceData;
    }

    /**
     * Gets the value of the notes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the notes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNotes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Notes }
     * 
     * 
     */
    public List<Notes> getNotes() {
        if (notes == null) {
            notes = new ArrayList<Notes>();
        }
        return this.notes;
    }

    /**
     * Gets the value of the attachment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the attachment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAttachment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Attachment }
     * 
     * 
     */
    public List<Attachment> getAttachment() {
        if (attachment == null) {
            attachment = new ArrayList<Attachment>();
        }
        return this.attachment;
    }

    /**
     * Gets the value of the layout property.
     * 
     * @return
     *     possible object is
     *     {@link Layout }
     *     
     */
    public Layout getLayout() {
        return layout;
    }

    /**
     * Sets the value of the layout property.
     * 
     * @param value
     *     allowed object is
     *     {@link Layout }
     *     
     */
    public void setLayout(Layout value) {
        this.layout = value;
    }

    /**
     * Gets the value of the invoiceTemplateLanguage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvoiceTemplateLanguage() {
        return invoiceTemplateLanguage;
    }

    /**
     * Sets the value of the invoiceTemplateLanguage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvoiceTemplateLanguage(String value) {
        this.invoiceTemplateLanguage = value;
    }

}
