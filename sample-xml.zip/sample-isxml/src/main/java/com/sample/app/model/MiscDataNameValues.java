
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MiscData-Name-Values.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="MiscData-Name-Values">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN30Base">
 *     &lt;enumeration value="AircraftVisitNo"/>
 *     &lt;enumeration value="BookingNumber"/>
 *     &lt;enumeration value="ConsumedUnits"/>
 *     &lt;enumeration value="DocketNumber"/>
 *     &lt;enumeration value="EndEstimate"/>
 *     &lt;enumeration value="EndReading"/>
 *     &lt;enumeration value="FlightID"/>
 *     &lt;enumeration value="LinkFlightDateTime"/>
 *     &lt;enumeration value="LinkFlightNo"/>
 *     &lt;enumeration value="MeterID"/>
 *     &lt;enumeration value="MeterLocationName"/>
 *     &lt;enumeration value="MoreDescription"/>
 *     &lt;enumeration value="OffStandDateTime"/>
 *     &lt;enumeration value="OnStandDateTime"/>
 *     &lt;enumeration value="PassHotstampNo"/>
 *     &lt;enumeration value="PassType"/>
 *     &lt;enumeration value="StandNo"/>
 *     &lt;enumeration value="StartEstimate"/>
 *     &lt;enumeration value="StartReading"/>
 *     &lt;enumeration value="SupplyType"/>
 *     &lt;enumeration value="VehicleRegistrationNo"/>
 *     &lt;enumeration value="MTOWSource"/>
 *     &lt;enumeration value="ContractNumber"/>
 *     &lt;enumeration value="ContractStartDate"/>
 *     &lt;enumeration value="ContractEndDate"/>
 *     &lt;enumeration value="PriceDate"/>
 *     &lt;enumeration value="ICAO_AnnexNo"/>
 *     &lt;enumeration value="SalesOrderNumber"/>
 *     &lt;enumeration value="LinkStandNo"/>
 *     &lt;enumeration value="LinkOnStandDateTime"/>
 *     &lt;enumeration value="ParkingDuration"/>
 *     &lt;enumeration value="EquipmentNo"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "MiscData-Name-Values", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum MiscDataNameValues {

    @XmlEnumValue("AircraftVisitNo")
    AIRCRAFT_VISIT_NO("AircraftVisitNo"),
    @XmlEnumValue("BookingNumber")
    BOOKING_NUMBER("BookingNumber"),
    @XmlEnumValue("ConsumedUnits")
    CONSUMED_UNITS("ConsumedUnits"),
    @XmlEnumValue("DocketNumber")
    DOCKET_NUMBER("DocketNumber"),
    @XmlEnumValue("EndEstimate")
    END_ESTIMATE("EndEstimate"),
    @XmlEnumValue("EndReading")
    END_READING("EndReading"),
    @XmlEnumValue("FlightID")
    FLIGHT_ID("FlightID"),
    @XmlEnumValue("LinkFlightDateTime")
    LINK_FLIGHT_DATE_TIME("LinkFlightDateTime"),
    @XmlEnumValue("LinkFlightNo")
    LINK_FLIGHT_NO("LinkFlightNo"),
    @XmlEnumValue("MeterID")
    METER_ID("MeterID"),
    @XmlEnumValue("MeterLocationName")
    METER_LOCATION_NAME("MeterLocationName"),
    @XmlEnumValue("MoreDescription")
    MORE_DESCRIPTION("MoreDescription"),
    @XmlEnumValue("OffStandDateTime")
    OFF_STAND_DATE_TIME("OffStandDateTime"),
    @XmlEnumValue("OnStandDateTime")
    ON_STAND_DATE_TIME("OnStandDateTime"),
    @XmlEnumValue("PassHotstampNo")
    PASS_HOTSTAMP_NO("PassHotstampNo"),
    @XmlEnumValue("PassType")
    PASS_TYPE("PassType"),
    @XmlEnumValue("StandNo")
    STAND_NO("StandNo"),
    @XmlEnumValue("StartEstimate")
    START_ESTIMATE("StartEstimate"),
    @XmlEnumValue("StartReading")
    START_READING("StartReading"),
    @XmlEnumValue("SupplyType")
    SUPPLY_TYPE("SupplyType"),
    @XmlEnumValue("VehicleRegistrationNo")
    VEHICLE_REGISTRATION_NO("VehicleRegistrationNo"),
    @XmlEnumValue("MTOWSource")
    MTOW_SOURCE("MTOWSource"),
    @XmlEnumValue("ContractNumber")
    CONTRACT_NUMBER("ContractNumber"),
    @XmlEnumValue("ContractStartDate")
    CONTRACT_START_DATE("ContractStartDate"),
    @XmlEnumValue("ContractEndDate")
    CONTRACT_END_DATE("ContractEndDate"),
    @XmlEnumValue("PriceDate")
    PRICE_DATE("PriceDate"),
    @XmlEnumValue("ICAO_AnnexNo")
    ICAO_ANNEX_NO("ICAO_AnnexNo"),
    @XmlEnumValue("SalesOrderNumber")
    SALES_ORDER_NUMBER("SalesOrderNumber"),
    @XmlEnumValue("LinkStandNo")
    LINK_STAND_NO("LinkStandNo"),
    @XmlEnumValue("LinkOnStandDateTime")
    LINK_ON_STAND_DATE_TIME("LinkOnStandDateTime"),
    @XmlEnumValue("ParkingDuration")
    PARKING_DURATION("ParkingDuration"),
    @XmlEnumValue("EquipmentNo")
    EQUIPMENT_NO("EquipmentNo");
    private final String value;

    MiscDataNameValues(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static MiscDataNameValues fromValue(String v) {
        for (MiscDataNameValues c: MiscDataNameValues.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
