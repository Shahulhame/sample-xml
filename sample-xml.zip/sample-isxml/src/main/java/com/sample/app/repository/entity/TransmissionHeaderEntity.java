package com.sample.app.repository.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.springframework.batch.item.ItemWriter;
import org.springframework.context.annotation.Bean;
import org.springframework.lang.NonNull;

import com.sample.app.writer.TransmissionHeaderWriter;

/**
 * The persistent class for the misc_billing_inv_trans_header database table.
 * 
 */

@SuppressWarnings("serial")
@Entity
@Table(name = "misc_billing_inv_trans_header")
@NamedQuery(name = "TransmissionHeaderEntity.findAll", query = "SELECT m FROM TransmissionHeaderEntity m")
public class TransmissionHeaderEntity extends BaseEntity implements Serializable {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "trans_hdr_autoid", nullable = false)
	private int transHdrAutoid;

	@NonNull
	@Column(name = "transmission_date_time", nullable = false)
	private String transmissionDateTime;

	@Column(name = "billing_category")
	private String billingCategory;

	@Column(name = "inbound_file_log_id")
	private int inboundFileLogId;

	@Column(name = "issuing_organization_id")
	private String issuingOrganizationId;

	@Column(name = "receiving_organization_id")
	private String receivingOrganizationId;

	@Column(name = "trans_version")
	private String version;

	@Column(name = "transmission_id")
	private String transmissionId;

	public TransmissionHeaderEntity() {
	}

	public int getTransHdrAutoid() {
		return this.transHdrAutoid;
	}

	public void setTransHdrAutoid(int transHdrAutoid) {
		this.transHdrAutoid = transHdrAutoid;
	}

	public String getBillingCategory() {
		return this.billingCategory;
	}

	public void setBillingCategory(String billingCategory) {
		this.billingCategory = billingCategory;
	}

	public int getInboundFileLogId() {
		return this.inboundFileLogId;
	}

	public void setInboundFileLogId(int inboundFileLogId) {
		this.inboundFileLogId = inboundFileLogId;
	}

	public String getIssuingOrganizationId() {
		return this.issuingOrganizationId;
	}

	public void setIssuingOrganizationId(String issuingOrganizationId) {
		this.issuingOrganizationId = issuingOrganizationId;
	}

	public String getReceivingOrganizationId() {
		return this.receivingOrganizationId;
	}

	public void setReceivingOrganizationId(String receivingOrganizationId) {
		this.receivingOrganizationId = receivingOrganizationId;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getTransmissionDateTime() {
		return this.transmissionDateTime;
	}

	public void setTransmissionDateTime(String transmissionDateTime) {
		this.transmissionDateTime = transmissionDateTime;
	}

	public String getTransmissionId() {
		return this.transmissionId;
	}

	public void setTransmissionId(String transmissionId) {
		this.transmissionId = transmissionId;
	}

	@Override
	public String toString() {
		return "TransmissionHeaderEntity [transHdrAutoid=" + transHdrAutoid + ", transmissionDateTime="
				+ transmissionDateTime + ", billingCategory=" + billingCategory + ", inboundFileLogId="
				+ inboundFileLogId + ", issuingOrganizationId=" + issuingOrganizationId + ", receivingOrganizationId="
				+ receivingOrganizationId + ", version=" + version + ", transmissionId=" + transmissionId + "]";
	}
	
	
	



}