package com.sample.app.processor;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import com.sample.app.repository.entity.BaseEntity;

public class BaseProcessor implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void process(BaseEntity transmissionHeaderEntity) {

		//transmissionHeaderEntity.setInboundFileId(2);
		transmissionHeaderEntity.setLastUpdatedBy("shahul");
		transmissionHeaderEntity.setLastUpdatedDate(new Timestamp(new Date().getTime()));

	}
}
