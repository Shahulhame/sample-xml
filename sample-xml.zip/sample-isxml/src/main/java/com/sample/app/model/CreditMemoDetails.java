
package com.sample.app.model;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CreditMemoNumber"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ReasonCode"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ReasonDescription" maxOccurs="50" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CorrespondenceRefNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}OurRef" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}YourInvoiceNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}YourInvoiceBillingDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}LinkedFIMNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}LinkedFIMCouponNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}Attachment" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AirlineOwnUse20AN" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}ISValidationFlag" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}BMCMCouponBreakdown" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AirWaybillBreakdown" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "creditMemoNumber",
    "reasonCode",
    "reasonDescription",
    "correspondenceRefNumber",
    "ourRef",
    "yourInvoiceNumber",
    "yourInvoiceBillingDate",
    "linkedFIMNumber",
    "linkedFIMCouponNumber",
    "attachment",
    "airlineOwnUse20AN",
    "isValidationFlag",
    "bmcmCouponBreakdown",
    "airWaybillBreakdown"
})
@XmlRootElement(name = "CreditMemoDetails", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class CreditMemoDetails {

    @XmlElement(name = "CreditMemoNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String creditMemoNumber;
    @XmlElement(name = "ReasonCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String reasonCode;
    @XmlElement(name = "ReasonDescription", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<String> reasonDescription;
    @XmlElement(name = "CorrespondenceRefNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger correspondenceRefNumber;
    @XmlElement(name = "OurRef", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String ourRef;
    @XmlElement(name = "YourInvoiceNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String yourInvoiceNumber;
    @XmlElement(name = "YourInvoiceBillingDate", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String yourInvoiceBillingDate;
    @XmlElement(name = "LinkedFIMNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger linkedFIMNumber;
    @XmlElement(name = "LinkedFIMCouponNumber", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigInteger linkedFIMCouponNumber;
    @XmlElement(name = "Attachment", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected Attachment attachment;
    @XmlElement(name = "AirlineOwnUse20AN", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String airlineOwnUse20AN;
    @XmlElement(name = "ISValidationFlag", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String isValidationFlag;
    @XmlElement(name = "BMCMCouponBreakdown", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<BMCMCouponBreakdown> bmcmCouponBreakdown;
    @XmlElement(name = "AirWaybillBreakdown", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected List<AirWaybillBreakdown> airWaybillBreakdown;

    /**
     * Gets the value of the creditMemoNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditMemoNumber() {
        return creditMemoNumber;
    }

    /**
     * Sets the value of the creditMemoNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditMemoNumber(String value) {
        this.creditMemoNumber = value;
    }

    /**
     * Gets the value of the reasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonCode() {
        return reasonCode;
    }

    /**
     * Sets the value of the reasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonCode(String value) {
        this.reasonCode = value;
    }

    /**
     * Gets the value of the reasonDescription property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reasonDescription property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReasonDescription().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getReasonDescription() {
        if (reasonDescription == null) {
            reasonDescription = new ArrayList<String>();
        }
        return this.reasonDescription;
    }

    /**
     * Gets the value of the correspondenceRefNumber property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCorrespondenceRefNumber() {
        return correspondenceRefNumber;
    }

    /**
     * Sets the value of the correspondenceRefNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCorrespondenceRefNumber(BigInteger value) {
        this.correspondenceRefNumber = value;
    }

    /**
     * Gets the value of the ourRef property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOurRef() {
        return ourRef;
    }

    /**
     * Sets the value of the ourRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOurRef(String value) {
        this.ourRef = value;
    }

    /**
     * Gets the value of the yourInvoiceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYourInvoiceNumber() {
        return yourInvoiceNumber;
    }

    /**
     * Sets the value of the yourInvoiceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYourInvoiceNumber(String value) {
        this.yourInvoiceNumber = value;
    }

    /**
     * Gets the value of the yourInvoiceBillingDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYourInvoiceBillingDate() {
        return yourInvoiceBillingDate;
    }

    /**
     * Sets the value of the yourInvoiceBillingDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYourInvoiceBillingDate(String value) {
        this.yourInvoiceBillingDate = value;
    }

    /**
     * Gets the value of the linkedFIMNumber property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getLinkedFIMNumber() {
        return linkedFIMNumber;
    }

    /**
     * Sets the value of the linkedFIMNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setLinkedFIMNumber(BigInteger value) {
        this.linkedFIMNumber = value;
    }

    /**
     * Gets the value of the linkedFIMCouponNumber property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getLinkedFIMCouponNumber() {
        return linkedFIMCouponNumber;
    }

    /**
     * Sets the value of the linkedFIMCouponNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setLinkedFIMCouponNumber(BigInteger value) {
        this.linkedFIMCouponNumber = value;
    }

    /**
     * Gets the value of the attachment property.
     * 
     * @return
     *     possible object is
     *     {@link Attachment }
     *     
     */
    public Attachment getAttachment() {
        return attachment;
    }

    /**
     * Sets the value of the attachment property.
     * 
     * @param value
     *     allowed object is
     *     {@link Attachment }
     *     
     */
    public void setAttachment(Attachment value) {
        this.attachment = value;
    }

    /**
     * Gets the value of the airlineOwnUse20AN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAirlineOwnUse20AN() {
        return airlineOwnUse20AN;
    }

    /**
     * Sets the value of the airlineOwnUse20AN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAirlineOwnUse20AN(String value) {
        this.airlineOwnUse20AN = value;
    }

    /**
     * Gets the value of the isValidationFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISValidationFlag() {
        return isValidationFlag;
    }

    /**
     * Sets the value of the isValidationFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISValidationFlag(String value) {
        this.isValidationFlag = value;
    }

    /**
     * Gets the value of the bmcmCouponBreakdown property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bmcmCouponBreakdown property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBMCMCouponBreakdown().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BMCMCouponBreakdown }
     * 
     * 
     */
    public List<BMCMCouponBreakdown> getBMCMCouponBreakdown() {
        if (bmcmCouponBreakdown == null) {
            bmcmCouponBreakdown = new ArrayList<BMCMCouponBreakdown>();
        }
        return this.bmcmCouponBreakdown;
    }

    /**
     * Gets the value of the airWaybillBreakdown property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the airWaybillBreakdown property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAirWaybillBreakdown().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AirWaybillBreakdown }
     * 
     * 
     */
    public List<AirWaybillBreakdown> getAirWaybillBreakdown() {
        if (airWaybillBreakdown == null) {
            airWaybillBreakdown = new ArrayList<AirWaybillBreakdown>();
        }
        return this.airWaybillBreakdown;
    }

}
