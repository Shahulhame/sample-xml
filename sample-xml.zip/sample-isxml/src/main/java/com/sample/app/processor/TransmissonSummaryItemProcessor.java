package com.sample.app.processor;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sample.app.model.TransmissionSummary;
import com.sample.app.repository.entity.MiscBillingInvTransSummary;
import com.sample.app.repository.entity.TransmissionHeaderEntity;

@Component
public class TransmissonSummaryItemProcessor implements ItemProcessor<TransmissionSummary, MiscBillingInvTransSummary> {

	@Override
	public MiscBillingInvTransSummary process(TransmissionSummary item) throws Exception {
		System.out.println("Inside TransmissonSummary Processor");
		MiscBillingInvTransSummary miscBillingInvTransSummary = new MiscBillingInvTransSummary();
		miscBillingInvTransSummary.setInvoiceCount(item.getInvoiceCount());
		miscBillingInvTransSummary.setLastUpdatedBy("shahul");
		miscBillingInvTransSummary.setLastUpdatedDate(new Timestamp(new Date().getTime()));
		miscBillingInvTransSummary.setCreatedBy("Shah");
		miscBillingInvTransSummary.setCreatedDate(new Timestamp(new Date().getTime()));

		return miscBillingInvTransSummary;
	}

}
