
package com.sample.app.model;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnChargeName"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnChargeCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnChargePercentage" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnChargeableAmount" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddOnChargeAmount"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "addOnChargeName",
    "addOnChargeCode",
    "addOnChargePercentage",
    "addOnChargeableAmount",
    "addOnChargeAmount"
})
@XmlRootElement(name = "AddOnCharges", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
public class AddOnCharges {

    @XmlElement(name = "AddOnChargeName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String addOnChargeName;
    @XmlElement(name = "AddOnChargeCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String addOnChargeCode;
    @XmlElement(name = "AddOnChargePercentage", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected Object addOnChargePercentage;
    @XmlElement(name = "AddOnChargeableAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected BigDecimal addOnChargeableAmount;
    @XmlElement(name = "AddOnChargeAmount", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected BigDecimal addOnChargeAmount;

    /**
     * Gets the value of the addOnChargeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddOnChargeName() {
        return addOnChargeName;
    }

    /**
     * Sets the value of the addOnChargeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddOnChargeName(String value) {
        this.addOnChargeName = value;
    }

    /**
     * Gets the value of the addOnChargeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddOnChargeCode() {
        return addOnChargeCode;
    }

    /**
     * Sets the value of the addOnChargeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddOnChargeCode(String value) {
        this.addOnChargeCode = value;
    }

    /**
     * Gets the value of the addOnChargePercentage property.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getAddOnChargePercentage() {
        return addOnChargePercentage;
    }

    /**
     * Sets the value of the addOnChargePercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setAddOnChargePercentage(Object value) {
        this.addOnChargePercentage = value;
    }

    /**
     * Gets the value of the addOnChargeableAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAddOnChargeableAmount() {
        return addOnChargeableAmount;
    }

    /**
     * Sets the value of the addOnChargeableAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAddOnChargeableAmount(BigDecimal value) {
        this.addOnChargeableAmount = value;
    }

    /**
     * Gets the value of the addOnChargeAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAddOnChargeAmount() {
        return addOnChargeAmount;
    }

    /**
     * Sets the value of the addOnChargeAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAddOnChargeAmount(BigDecimal value) {
        this.addOnChargeAmount = value;
    }

}
