
package com.sample.app.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ChargeCategoryMISC.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ChargeCategoryMISC">
 *   &lt;restriction base="{http://www.IATA.com/IATAAviationStandardDataTypes}AN25Base">
 *     &lt;enumeration value="Airport"/>
 *     &lt;enumeration value="ATC"/>
 *     &lt;enumeration value="Cargo"/>
 *     &lt;enumeration value="Engineering"/>
 *     &lt;enumeration value="Flight Ops"/>
 *     &lt;enumeration value="Ground Handling"/>
 *     &lt;enumeration value="IT Services"/>
 *     &lt;enumeration value="Mail"/>
 *     &lt;enumeration value="Finance"/>
 *     &lt;enumeration value="Partner Alliance"/>
 *     &lt;enumeration value="Property"/>
 *     &lt;enumeration value="Service Provider"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ChargeCategoryMISC", namespace = "http://www.IATA.com/IATAAviationStandardMainDictionary")
@XmlEnum
public enum ChargeCategoryMISC {

    @XmlEnumValue("Airport")
    AIRPORT("Airport"),
    ATC("ATC"),
    @XmlEnumValue("Cargo")
    CARGO("Cargo"),
    @XmlEnumValue("Engineering")
    ENGINEERING("Engineering"),
    @XmlEnumValue("Flight Ops")
    FLIGHT_OPS("Flight Ops"),
    @XmlEnumValue("Ground Handling")
    GROUND_HANDLING("Ground Handling"),
    @XmlEnumValue("IT Services")
    IT_SERVICES("IT Services"),
    @XmlEnumValue("Mail")
    MAIL("Mail"),
    @XmlEnumValue("Finance")
    FINANCE("Finance"),
    @XmlEnumValue("Partner Alliance")
    PARTNER_ALLIANCE("Partner Alliance"),
    @XmlEnumValue("Property")
    PROPERTY("Property"),
    @XmlEnumValue("Service Provider")
    SERVICE_PROVIDER("Service Provider");
    private final String value;

    ChargeCategoryMISC(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ChargeCategoryMISC fromValue(String v) {
        for (ChargeCategoryMISC c: ChargeCategoryMISC.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
