
package com.sample.app.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * Description: Base address type
 * Definition: Structured as well as unstructured Address information are supported. In case of unstructured information, the address information is simply populated into the lines AddressLine1, AddressLine2, AddressLine3, CityName, SubdivisionName, CountryName, PostalCode.
 * 
 * <p>Java class for AddressBase complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddressBase">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddressLine1" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddressLine2" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}AddressLine3" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CityName" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SubdivisionCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}SubdivisionName" minOccurs="0"/>
 *         &lt;element name="CountryCode" type="{http://www.IATA.com/IATAAviationStandardMainDictionary}CountryCode"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CountryCode_ICAO" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}CountryName" minOccurs="0"/>
 *         &lt;element ref="{http://www.IATA.com/IATAAviationInvoiceStandard}PostalCode" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddressBase", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", propOrder = {
    "addressLine1",
    "addressLine2",
    "addressLine3",
    "cityName",
    "subdivisionCode",
    "subdivisionName",
    "countryCode",
    "countryCodeICAO",
    "countryName",
    "postalCode"
})
@XmlSeeAlso({
    Address.class
})
public class AddressBase {

    @XmlElement(name = "AddressLine1", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String addressLine1;
    @XmlElement(name = "AddressLine2", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String addressLine2;
    @XmlElement(name = "AddressLine3", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String addressLine3;
    @XmlElement(name = "CityName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String cityName;
    @XmlElement(name = "SubdivisionCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String subdivisionCode;
    @XmlElement(name = "SubdivisionName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String subdivisionName;
    @XmlElement(name = "CountryCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard", required = true)
    protected String countryCode;
    @XmlElement(name = "CountryCode_ICAO", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String countryCodeICAO;
    @XmlElement(name = "CountryName", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String countryName;
    @XmlElement(name = "PostalCode", namespace = "http://www.IATA.com/IATAAviationInvoiceStandard")
    protected String postalCode;

    /**
     * Gets the value of the addressLine1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressLine1() {
        return addressLine1;
    }

    /**
     * Sets the value of the addressLine1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressLine1(String value) {
        this.addressLine1 = value;
    }

    /**
     * Gets the value of the addressLine2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressLine2() {
        return addressLine2;
    }

    /**
     * Sets the value of the addressLine2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressLine2(String value) {
        this.addressLine2 = value;
    }

    /**
     * Gets the value of the addressLine3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressLine3() {
        return addressLine3;
    }

    /**
     * Sets the value of the addressLine3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressLine3(String value) {
        this.addressLine3 = value;
    }

    /**
     * Gets the value of the cityName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * Sets the value of the cityName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCityName(String value) {
        this.cityName = value;
    }

    /**
     * Gets the value of the subdivisionCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubdivisionCode() {
        return subdivisionCode;
    }

    /**
     * Sets the value of the subdivisionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubdivisionCode(String value) {
        this.subdivisionCode = value;
    }

    /**
     * Gets the value of the subdivisionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubdivisionName() {
        return subdivisionName;
    }

    /**
     * Sets the value of the subdivisionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubdivisionName(String value) {
        this.subdivisionName = value;
    }

    /**
     * Gets the value of the countryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * Sets the value of the countryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryCode(String value) {
        this.countryCode = value;
    }

    /**
     * Gets the value of the countryCodeICAO property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryCodeICAO() {
        return countryCodeICAO;
    }

    /**
     * Sets the value of the countryCodeICAO property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryCodeICAO(String value) {
        this.countryCodeICAO = value;
    }

    /**
     * Gets the value of the countryName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryName() {
        return countryName;
    }

    /**
     * Sets the value of the countryName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryName(String value) {
        this.countryName = value;
    }

    /**
     * Gets the value of the postalCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * Sets the value of the postalCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostalCode(String value) {
        this.postalCode = value;
    }

}
